from pathlib import Path
from functools import wraps
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
import calendar
import os
import secrets
import uuid

from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    session,
    flash,
    abort
)

from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from database import get_db, init_db

BASE_DIR = Path(__file__).resolve().parent
EXERCISE_IMAGE_DIR = BASE_DIR / "static" / "exercises"
EXERCISE_IMAGE_DIR.mkdir(parents=True, exist_ok=True)
EXERCISE_IMAGE_EXTENSIONS = {"jpg", "jpeg", "png", "webp"}
MAX_EXERCISE_IMAGE_BYTES = 8 * 1024 * 1024

PROFILE_IMAGE_DIR = BASE_DIR / "static" / "profile_pictures"
PROFILE_IMAGE_DIR.mkdir(parents=True, exist_ok=True)
PROFILE_IMAGE_EXTENSIONS = {"jpg", "jpeg", "png", "webp"}
MAX_PROFILE_IMAGE_BYTES = 5 * 1024 * 1024

app = Flask(__name__)
app.secret_key = os.getenv(
    "FLASK_SECRET_KEY",
    "academia-projeto-escolar-chave-local"
)
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(minutes=60)
app.config["SESSION_REFRESH_EACH_REQUEST"] = True
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"


@app.before_request
def enforce_session_timeout():
    user_id = session.get("user_id")
    if not user_id:
        return None

    now = datetime.now().timestamp()
    last_activity = session.get("last_activity")

    if last_activity is not None:
        try:
            inactive_seconds = now - float(last_activity)
        except (TypeError, ValueError):
            inactive_seconds = 0

        if inactive_seconds >= 60 * 60:
            session.clear()
            flash("Sua sessão expirou. Entre novamente.")
            return redirect(url_for("login"))

    session.permanent = True
    session["last_activity"] = now
    return None


def add_months(start_date, months):
    month = start_date.month - 1 + months
    year = start_date.year + month // 12
    month = month % 12 + 1

    day = min(
        start_date.day,
        calendar.monthrange(year, month)[1]
    )

    return date(year, month, day)


def calculate_plan_end_date(start_date, plan):
    duration_days = int(plan["duration_days"] or 0) if "duration_days" in plan.keys() else 0
    duration_months = int(plan["duration_months"] or 0)

    if duration_days > 0:
        return start_date + timedelta(days=duration_days)

    return add_months(start_date, max(duration_months, 1))


def plan_discount_is_active(plan, reference_date=None):
    reference_date = reference_date or date.today()
    percent = float(plan["discount_percent"] or 0) if "discount_percent" in plan.keys() else 0

    if percent <= 0:
        return False

    start_value = plan["discount_start"] if "discount_start" in plan.keys() else None
    end_value = plan["discount_end"] if "discount_end" in plan.keys() else None

    try:
        start_date = date.fromisoformat(start_value) if start_value else None
        end_date = date.fromisoformat(end_value) if end_value else None
    except ValueError:
        return False

    if start_date and reference_date < start_date:
        return False

    if end_date and reference_date > end_date:
        return False

    return True


def effective_plan_price_cents(plan, reference_date=None):
    price_cents = int(plan["price_cents"] or 0)

    if not plan_discount_is_active(plan, reference_date):
        return price_cents

    discount_percent = Decimal(str(plan["discount_percent"] or 0))
    discounted = Decimal(price_cents) * (Decimal("1") - discount_percent / Decimal("100"))
    return max(0, int(discounted.quantize(Decimal("1"), rounding=ROUND_HALF_UP)))


def plan_view_data(plan, reference_date=None):
    item = dict(plan)
    duration_days = int(item.get("duration_days") or 0)
    duration_months = int(item.get("duration_months") or 0)

    if duration_days > 0:
        item["duration_value"] = duration_days
        item["duration_unit"] = "DAYS"
        item["duration_label"] = f"{duration_days} dia" if duration_days == 1 else f"{duration_days} dias"
    else:
        months = max(duration_months, 1)
        item["duration_value"] = months
        item["duration_unit"] = "MONTHS"
        item["duration_label"] = f"{months} mês" if months == 1 else f"{months} meses"

    item["discount_active"] = plan_discount_is_active(plan, reference_date)
    item["effective_price_cents"] = effective_plan_price_cents(plan, reference_date)
    return item


def format_money(cents):
    if cents is None:
        cents = 0

    value = cents / 100

    return (
        f"R$ {value:,.2f}"
        .replace(",", "X")
        .replace(".", ",")
        .replace("X", ".")
    )


app.jinja_env.filters["money"] = format_money


def current_user():
    user_id = session.get("user_id")

    if not user_id:
        return None

    conn = get_db()

    user = conn.execute(
        """
        SELECT
            users.*,
            roles.code AS role_code,
            roles.name AS role_name
        FROM users
        JOIN roles
            ON roles.id = users.role_id
        WHERE users.id = ?
        """,
        (user_id,)
    ).fetchone()

    conn.close()

    return user


@app.context_processor
def inject_current_user():
    user = current_user()
    return {
        "current_user": user,
        "notification_unread_count": notification_unread_count(user) if user else 0
    }


def login_required(function):
    @wraps(function)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))

        user = current_user()

        if not user or not user["active"]:
            session.clear()
            return redirect(url_for("login"))

        return function(*args, **kwargs)

    return wrapper


def require_roles(*roles):
    def decorator(function):
        @wraps(function)
        def wrapper(*args, **kwargs):
            user = current_user()

            if not user:
                return redirect(url_for("login"))

            if not user["active"]:
                session.clear()
                return redirect(url_for("login"))

            if user["role_code"] not in roles:
                abort(403)

            return function(*args, **kwargs)

        return wrapper

    return decorator


def require_employee_types(*types):
    def decorator(function):
        @wraps(function)
        def wrapper(*args, **kwargs):
            user = current_user()

            if not user:
                return redirect(url_for("login"))

            if not user["active"]:
                session.clear()
                return redirect(url_for("login"))

            if user["role_code"] != "EMPLOYEE":
                abort(403)

            if user["employee_type"] not in types:
                abort(403)

            return function(*args, **kwargs)

        return wrapper

    return decorator




GROUP_TYPE_LABELS = {
    "RUNNING": "Corrida",
    "SWIMMING": "Natação",
    "CYCLING": "Ciclismo",
}

GROUP_TYPE_ICONS = {
    "RUNNING": "🏃",
    "SWIMMING": "🏊",
    "CYCLING": "🚴",
}


def student_group_membership_count(conn, user_id):
    row = conn.execute(
        """
        SELECT COUNT(*) AS total
        FROM activity_group_members AS members
        JOIN activity_groups AS groups ON groups.id = members.group_id
        WHERE members.user_id = ?
          AND groups.active = 1
        """,
        (user_id,)
    ).fetchone()
    return int(row["total"] or 0)


def student_group_admin_count(conn, user_id):
    row = conn.execute(
        """
        SELECT COUNT(*) AS total
        FROM activity_groups
        WHERE created_by = ?
          AND active = 1
        """,
        (user_id,)
    ).fetchone()
    return int(row["total"] or 0)


def student_group_membership(conn, group_id, user_id):
    return conn.execute(
        """
        SELECT members.*
        FROM activity_group_members AS members
        JOIN activity_groups AS groups ON groups.id = members.group_id
        WHERE members.group_id = ?
          AND members.user_id = ?
          AND groups.active = 1
        """,
        (group_id, user_id)
    ).fetchone()


def weekly_group_window(reference_date=None):
    reference_date = reference_date or date.today()
    start = reference_date - timedelta(days=reference_date.weekday())
    end = start + timedelta(days=6)
    return start, end


def parse_positive_decimal(raw_value):
    value = (raw_value or "").strip().replace(",", ".")
    try:
        parsed = Decimal(value)
    except (InvalidOperation, ValueError):
        return None
    if parsed <= 0:
        return None
    return parsed


def is_admin(user):
    return bool(
        user
        and user["role_code"] in {
            "OWNER",
            "ADMIN"
        }
    )


def is_reception(user):
    return bool(
        user
        and user["role_code"] == "EMPLOYEE"
        and user["employee_type"] == "RECEPTION"
    )


def is_hr(user):
    return bool(
        user
        and user["role_code"] == "EMPLOYEE"
        and user["employee_type"] == "HR"
    )


def can_manage_plans(user):
    return bool(is_admin(user) or is_hr(user))


def require_plan_management(function):
    @wraps(function)
    def wrapper(*args, **kwargs):
        user = current_user()

        if not user:
            return redirect(url_for("login"))

        if not user["active"]:
            session.clear()
            return redirect(url_for("login"))

        if not can_manage_plans(user):
            abort(403)

        return function(*args, **kwargs)

    return wrapper


def require_hr_management(function):
    @wraps(function)
    def wrapper(*args, **kwargs):
        user = current_user()

        if not user:
            return redirect(url_for("login"))

        if not user["active"]:
            session.clear()
            return redirect(url_for("login"))

        if not (is_admin(user) or is_hr(user)):
            abort(403)

        return function(*args, **kwargs)

    return wrapper


def hr_can_manage_target(actor, target):
    if not actor or not target:
        return False

    if actor["role_code"] == "OWNER":
        return target["role_code"] != "OWNER"

    if actor["role_code"] == "ADMIN":
        return target["role_code"] == "EMPLOYEE"

    if is_hr(actor):
        return (
            target["role_code"] == "EMPLOYEE"
            and target["id"] != actor["id"]
        )

    return False


def sender_description(row):
    if row["sender_role_code"] == "STUDENT":
        return "Aluno"

    if row["sender_role_code"] == "OWNER":
        return "Dono / Super Admin"

    if row["sender_role_code"] == "ADMIN":
        return "Administrador"

    types = {
        "PERSONAL": "Personal Trainer",
        "CLEANING": "Limpeza",
        "SECURITY": "Segurança",
        "RECEPTION": "Recepção",
        "HR": "Recursos Humanos"
    }

    return types.get(
        row["sender_employee_type"],
        "Funcionário"
    )




MESSAGE_TARGET_LABELS = {
    "ADMIN": "Administração",
    "RECEPTION": "Recepção",
    "HR": "Recursos Humanos",
}

NOTIFICATION_KIND_LABELS = {
    "MESSAGE": "Recado",
    "SECURITY": "Ocorrência",
    "HR": "RH",
    "CLEANING": "Limpeza",
    "FINANCE": "Financeiro",
    "TRAINING": "Treino",
    "ACCOUNT": "Cadastros",
}


def message_recipient_candidates(conn, user):
    rows = conn.execute(
        """
        SELECT users.id, users.name, users.prontuario, users.employee_type,
               users.profile_image_filename, roles.code AS role_code
        FROM users
        JOIN roles ON roles.id = users.role_id
        WHERE users.active = 1
          AND users.id != ?
          AND roles.code IN ('OWNER', 'ADMIN', 'EMPLOYEE')
        ORDER BY
            CASE roles.code WHEN 'OWNER' THEN 0 WHEN 'ADMIN' THEN 1 ELSE 2 END,
            users.name
        """,
        (user["id"],),
    ).fetchall()

    recipients = []
    for row in rows:
        if row["role_code"] == "OWNER":
            role_label = "Dono"
        elif row["role_code"] == "ADMIN":
            role_label = "Administrador"
        else:
            role_label = employee_type_label(row["employee_type"])
        recipients.append({
            "id": row["id"],
            "name": row["name"],
            "prontuario": row["prontuario"],
            "role_label": role_label,
            "profile_image_filename": row["profile_image_filename"],
        })
    return recipients


def notification_items_for_user(conn, user):
    if not user:
        return []

    items = []

    message_rows = conn.execute(
        """
        SELECT messages.*, sender.name AS sender_name
        FROM system_message_recipients recipients
        JOIN system_messages messages ON messages.id = recipients.message_id
        JOIN users sender ON sender.id = messages.sender_id
        WHERE recipients.user_id = ?
        ORDER BY messages.id DESC
        LIMIT 100
        """,
        (user["id"],),
    ).fetchall()
    for row in message_rows:
        meta = row["sender_name"]
        if row["delivery_mode"] == "ALL":
            meta += " · Todos"
        elif row["delivery_mode"] == "LEGACY":
            meta += f" · {MESSAGE_TARGET_LABELS.get(row['target_group'], row['target_group'])}"
        items.append({
            "source_type": "MESSAGE",
            "source_id": row["id"],
            "kind": "MESSAGE",
            "title": row["subject"],
            "text": row["message"],
            "meta": meta,
            "created_at": row["created_at"],
            "priority": row["priority"],
            "href": url_for("messages_center"),
        })

    security_rows = conn.execute(
        """
        SELECT security_reports.*, security.name AS security_name,
               GROUP_CONCAT(involved.name, ', ') AS involved_names
        FROM security_reports
        JOIN users AS security ON security.id = security_reports.security_id
        LEFT JOIN security_report_involved links ON links.report_id = security_reports.id
        LEFT JOIN users AS involved ON involved.id = links.user_id
        GROUP BY security_reports.id
        ORDER BY security_reports.id DESC
        LIMIT 100
        """
    ).fetchall()
    for row in security_rows:
        items.append({
            "source_type": f"SECURITY_{row['status']}",
            "source_id": row["id"],
            "kind": "SECURITY",
            "title": row["subject"],
            "text": row["description"],
            "meta": f"{row['security_name']} · {row['severity']} · {row['status']}",
            "created_at": row["created_at"],
            "priority": "HIGH" if row["severity"] in {"HIGH", "CRITICAL"} else "NORMAL",
            "href": url_for("employee_notifications", tipo="SECURITY"),
        })

    if user["role_code"] in {"OWNER", "ADMIN"} or is_hr(user):
        leave_rows = conn.execute(
            """
            SELECT leave_requests.*, users.name AS employee_name
            FROM leave_requests
            JOIN users ON users.id = leave_requests.employee_id
            WHERE leave_requests.status = 'PENDING'
            ORDER BY leave_requests.id DESC
            LIMIT 80
            """
        ).fetchall()
        for row in leave_rows:
            items.append({
                "source_type": "LEAVE_PENDING",
                "source_id": row["id"],
                "kind": "HR",
                "title": "Afastamento aguardando análise",
                "text": f"{row['employee_name']} · {row['start_date']} a {row['end_date']}",
                "meta": row["leave_type"],
                "created_at": row["created_at"],
                "priority": "NORMAL",
                "href": url_for("leave_admin"),
            })
    elif user["role_code"] == "EMPLOYEE":
        leave_rows = conn.execute(
            """
            SELECT * FROM leave_requests
            WHERE employee_id = ?
            ORDER BY id DESC
            LIMIT 40
            """,
            (user["id"],),
        ).fetchall()
        for row in leave_rows:
            items.append({
                "source_type": f"LEAVE_{row['status']}",
                "source_id": row["id"],
                "kind": "HR",
                "title": "Férias / afastamento",
                "text": f"{row['start_date']} a {row['end_date']} · {row['status']}",
                "meta": row["leave_type"],
                "created_at": row["reviewed_at"] or row["created_at"],
                "priority": "NORMAL",
                "href": url_for("employee_hr"),
            })

    cleaning_rows = conn.execute(
        """
        SELECT cleaning_requests.*, requester.name AS requester_name,
               worker.name AS worker_name
        FROM cleaning_requests
        JOIN users requester ON requester.id = cleaning_requests.requester_id
        LEFT JOIN users worker ON worker.id = cleaning_requests.assigned_to
        WHERE cleaning_requests.status IN ('PENDING', 'IN_PROGRESS')
        ORDER BY cleaning_requests.id DESC
        LIMIT 100
        """
    ).fetchall()
    for row in cleaning_rows:
        items.append({
            "source_type": f"CLEANING_{row['status']}",
            "source_id": row["id"],
            "kind": "CLEANING",
            "title": row["title"],
            "text": row["description"] or row["location"] or "Solicitação de limpeza",
            "meta": f"{row['requester_name']} · {row['status']}",
            "created_at": row["assigned_at"] or row["created_at"],
            "priority": row["priority"],
            "href": url_for("messages_center") + "#limpeza",
        })

    if user["role_code"] in {"OWNER", "ADMIN"}:
        event_rows = conn.execute(
            """
            SELECT events.*, actor.name AS actor_name, target.name AS target_name,
                   target.prontuario AS target_prontuario
            FROM system_events events
            LEFT JOIN users actor ON actor.id = events.actor_id
            LEFT JOIN users target ON target.id = events.target_user_id
            WHERE events.event_type = 'STUDENT_REACTIVATED'
            ORDER BY events.id DESC
            LIMIT 80
            """
        ).fetchall()
        for row in event_rows:
            items.append({
                "source_type": "STUDENT_REACTIVATED",
                "source_id": row["id"],
                "kind": "ACCOUNT",
                "title": row["title"],
                "text": row["message"],
                "meta": row["actor_name"] or "Recepção",
                "created_at": row["created_at"],
                "priority": "NORMAL",
                "href": url_for("students"),
            })

    if user["role_code"] == "STUDENT":
        payment_rows = conn.execute(
            """
            SELECT * FROM payments
            WHERE student_id = ? AND status = 'OVERDUE'
            ORDER BY due_date DESC, id DESC
            """,
            (user["id"],),
        ).fetchall()
        for row in payment_rows:
            items.append({
                "source_type": "PAYMENT_OVERDUE",
                "source_id": row["id"],
                "kind": "FINANCE",
                "title": "Pagamento em atraso",
                "text": f"Vencimento: {row['due_date']} · {format_money(row['amount_cents'])}",
                "meta": "Financeiro",
                "created_at": row["due_date"] + " 00:00:00",
                "priority": "HIGH",
                "href": url_for("student_dashboard"),
            })

        warning_rows = conn.execute(
            """
            SELECT warnings.*, users.name AS personal_name
            FROM warnings JOIN users ON users.id = warnings.personal_id
            WHERE warnings.student_id = ?
            ORDER BY warnings.id DESC
            LIMIT 60
            """,
            (user["id"],),
        ).fetchall()
        for row in warning_rows:
            items.append({
                "source_type": "WARNING",
                "source_id": row["id"],
                "kind": "TRAINING",
                "title": "Orientação do personal",
                "text": row["message"],
                "meta": row["personal_name"],
                "created_at": row["created_at"],
                "priority": "NORMAL",
                "href": url_for("student_dashboard"),
            })

    reads = conn.execute(
        "SELECT source_type, source_id FROM notification_reads WHERE user_id = ?",
        (user["id"],),
    ).fetchall()
    read_keys = {(row["source_type"], row["source_id"]) for row in reads}

    for item in items:
        item["unread"] = (item["source_type"], item["source_id"]) not in read_keys
        item["kind_label"] = NOTIFICATION_KIND_LABELS.get(item["kind"], item["kind"])

    items.sort(key=lambda item: str(item["created_at"] or ""), reverse=True)
    return items[:140]

def notification_unread_count(user):
    if not user:
        return 0
    conn = get_db()
    try:
        return sum(1 for item in notification_items_for_user(conn, user) if item["unread"])
    finally:
        conn.close()


def mark_notifications_read(conn, user_id, items):
    conn.executemany(
        """
        INSERT OR IGNORE INTO notification_reads (user_id, source_type, source_id)
        VALUES (?, ?, ?)
        """,
        [(user_id, item["source_type"], item["source_id"]) for item in items],
    )


def parse_money_to_cents(value):
    text = str(value or "").strip()

    if not text:
        return 0

    text = text.replace("R$", "").replace(" ", "")

    if "," in text:
        text = text.replace(".", "").replace(",", ".")

    try:
        amount = Decimal(text)
    except InvalidOperation:
        return None

    if amount < 0:
        return None

    return int(
        (amount * Decimal("100"))
        .quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    )


def only_digits(value):
    return "".join(
        character
        for character in str(value or "")
        if character.isdigit()
    )


def validate_cpf(value):
    cpf = only_digits(value)

    if len(cpf) != 11 or cpf == cpf[0] * 11:
        return False

    for position in (9, 10):
        total = sum(
            int(cpf[index]) * ((position + 1) - index)
            for index in range(position)
        )
        digit = (total * 10) % 11
        if digit == 10:
            digit = 0
        if digit != int(cpf[position]):
            return False

    return True


def generate_prontuario(conn, prefix):
    if prefix not in {"F", "A"}:
        raise ValueError("Prefixo de prontuário inválido.")

    row = conn.execute(
        """
        SELECT MAX(
            CAST(SUBSTR(prontuario, 2) AS INTEGER)
        ) AS last_number
        FROM users
        WHERE prontuario GLOB ?
        """,
        (f"{prefix}[0-9]*",)
    ).fetchone()

    number = (row["last_number"] or 0) + 1

    while True:
        prontuario = f"{prefix}{number:05d}"
        exists = conn.execute(
            "SELECT 1 FROM users WHERE prontuario = ?",
            (prontuario,)
        ).fetchone()

        if not exists:
            return prontuario

        number += 1


def generate_employee_prontuario(conn):
    return generate_prontuario(conn, "F")


def generate_student_prontuario(conn):
    return generate_prontuario(conn, "A")


def new_onboarding_code():
    # Código curto para primeiro acesso, exibido apenas ao administrador.
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    return "".join(secrets.choice(alphabet) for _ in range(8))


def valid_email(value):
    email = (value or "").strip().lower()
    if not email or "@" not in email:
        return False
    local, domain = email.rsplit("@", 1)
    return bool(local and "." in domain and not domain.startswith(".") and not domain.endswith("."))


def email_in_use(conn, email, exclude_user_id=None):
    params = [email]
    sql = "SELECT id FROM users WHERE LOWER(email) = LOWER(?)"
    if exclude_user_id is not None:
        sql += " AND id != ?"
        params.append(exclude_user_id)
    return conn.execute(sql, tuple(params)).fetchone() is not None


def employee_type_label(value):
    return {
        "PERSONAL": "Personal Trainer",
        "CLEANING": "Limpeza",
        "SECURITY": "Segurança",
        "RECEPTION": "Recepção",
        "HR": "Recursos Humanos",
    }.get(value, "Administrador")


def format_date_br(value):
    if not value:
        return "-"

    try:
        parsed = date.fromisoformat(str(value)[:10])
        return parsed.strftime("%d/%m/%Y")
    except ValueError:
        return str(value)


def format_datetime_br(value):
    if not value:
        return "-"

    text = str(value).replace("T", " ")

    try:
        parsed = datetime.fromisoformat(text)
        return parsed.strftime("%d/%m/%Y %H:%M")
    except ValueError:
        return str(value)


def format_minutes(value):
    minutes = max(0, int(value or 0))
    hours, remaining = divmod(minutes, 60)
    return f"{hours:02d}h{remaining:02d}"


app.jinja_env.filters["date_br"] = format_date_br
app.jinja_env.filters["datetime_br"] = format_datetime_br
app.jinja_env.filters["minutes"] = format_minutes


def time_to_minutes(value):
    if not value:
        return None

    try:
        hour, minute = str(value)[:5].split(":")
        return int(hour) * 60 + int(minute)
    except (ValueError, TypeError):
        return None


def duration_between_times(start_value, end_value):
    start = time_to_minutes(start_value)
    end = time_to_minutes(end_value)

    if start is None or end is None:
        return 0

    if end <= start:
        end += 24 * 60

    return end - start


def schedule_expected_minutes(schedule):
    if not schedule or schedule["schedule_type"] != "WORK":
        return 0

    total = duration_between_times(
        schedule["shift_start"],
        schedule["shift_end"]
    )

    break_minutes = duration_between_times(
        schedule["break_start"],
        schedule["break_end"]
    )

    if break_minutes > total:
        break_minutes = 0

    return max(0, total - break_minutes)


def schedule_datetime_bounds(schedule):
    if not schedule or not schedule["shift_start"] or not schedule["shift_end"]:
        return None, None

    try:
        work_day = date.fromisoformat(schedule["work_date"])
        start_hour, start_minute = map(int, schedule["shift_start"][:5].split(":"))
        end_hour, end_minute = map(int, schedule["shift_end"][:5].split(":"))
    except (ValueError, TypeError):
        return None, None

    start_dt = datetime.combine(work_day, datetime.min.time()).replace(
        hour=start_hour,
        minute=start_minute
    )
    end_dt = datetime.combine(work_day, datetime.min.time()).replace(
        hour=end_hour,
        minute=end_minute
    )

    if end_dt <= start_dt:
        end_dt += timedelta(days=1)

    return start_dt, end_dt


def worked_minutes_from_entry(entry):
    if not entry or not entry["clock_in"] or not entry["clock_out"]:
        return 0

    total = duration_between_times(
        entry["clock_in"],
        entry["clock_out"]
    )

    break_minutes = duration_between_times(
        entry["break_out"],
        entry["break_in"]
    )

    if break_minutes > total:
        break_minutes = 0

    return max(0, total - break_minutes)


def calculate_inss_2026(gross_cents):
    gross_cents = max(0, int(gross_cents or 0))

    brackets = [
        (162100, Decimal("0.075")),
        (290284, Decimal("0.09")),
        (435427, Decimal("0.12")),
        (847555, Decimal("0.14")),
    ]

    previous_limit = 0
    contribution = Decimal("0")

    for limit, rate in brackets:
        taxable = min(gross_cents, limit) - previous_limit

        if taxable > 0:
            contribution += Decimal(taxable) * rate

        if gross_cents <= limit:
            break

        previous_limit = limit

    return int(
        contribution.quantize(
            Decimal("1"),
            rounding=ROUND_HALF_UP
        )
    )


def calculate_irrf_2026(gross_cents, inss_cents, dependents_count=0):
    gross_cents = max(0, int(gross_cents or 0))
    inss_cents = max(0, int(inss_cents or 0))
    dependents_count = max(0, int(dependents_count or 0))

    legal_deduction = inss_cents + dependents_count * 18959
    simplified_deduction = 60720
    deduction = max(legal_deduction, simplified_deduction)
    base = max(0, gross_cents - deduction)

    if base <= 242880:
        tax = Decimal("0")
    elif base <= 282665:
        tax = Decimal(base) * Decimal("0.075") - Decimal(18216)
    elif base <= 375105:
        tax = Decimal(base) * Decimal("0.15") - Decimal(39416)
    elif base <= 466468:
        tax = Decimal(base) * Decimal("0.225") - Decimal(67549)
    else:
        tax = Decimal(base) * Decimal("0.275") - Decimal(90873)

    tax = max(Decimal("0"), tax)

    # Redução mensal da Lei 15.270/2025, vigente em 2026.
    if gross_cents <= 500000:
        tax = Decimal("0")
    elif gross_cents <= 735000:
        gross_reais = Decimal(gross_cents) / Decimal("100")
        reduction_reais = (
            Decimal("978.62")
            - Decimal("0.133145") * gross_reais
        )
        reduction_cents = max(
            Decimal("0"),
            reduction_reais * Decimal("100")
        )
        tax = max(Decimal("0"), tax - reduction_cents)

    return int(
        tax.quantize(
            Decimal("1"),
            rounding=ROUND_HALF_UP
        )
    )


def payroll_calculation(
    base_salary_cents,
    weekly_hours,
    overtime_minutes,
    shortfall_minutes,
    bonus_cents=0,
    other_earnings_cents=0,
    other_deductions_cents=0,
    dependents_count=0,
    overtime_percent=50,
):
    base_salary_cents = max(0, int(base_salary_cents or 0))
    weekly_hours = Decimal(str(weekly_hours or 44))
    monthly_hours = weekly_hours * Decimal("5")

    if monthly_hours <= 0:
        monthly_hours = Decimal("220")

    hourly_cents = Decimal(base_salary_cents) / monthly_hours

    overtime_cents = (
        hourly_cents
        * (Decimal(overtime_minutes or 0) / Decimal("60"))
        * (Decimal("1") + Decimal(str(overtime_percent)) / Decimal("100"))
    )

    absence_discount_cents = (
        hourly_cents
        * (Decimal(shortfall_minutes or 0) / Decimal("60"))
    )

    overtime_cents = int(
        overtime_cents.quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    )
    absence_discount_cents = min(
        base_salary_cents,
        int(
            absence_discount_cents.quantize(
                Decimal("1"),
                rounding=ROUND_HALF_UP
            )
        )
    )

    gross_cents = max(
        0,
        base_salary_cents
        - absence_discount_cents
        + overtime_cents
        + int(bonus_cents or 0)
        + int(other_earnings_cents or 0)
    )

    inss_cents = calculate_inss_2026(gross_cents)
    irrf_cents = calculate_irrf_2026(
        gross_cents,
        inss_cents,
        dependents_count
    )
    fgts_cents = int(
        (Decimal(gross_cents) * Decimal("0.08"))
        .quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    )

    net_cents = max(
        0,
        gross_cents
        - inss_cents
        - irrf_cents
        - int(other_deductions_cents or 0)
    )

    return {
        "monthly_hours": float(monthly_hours),
        "overtime_cents": overtime_cents,
        "absence_discount_cents": absence_discount_cents,
        "gross_cents": gross_cents,
        "inss_cents": inss_cents,
        "irrf_cents": irrf_cents,
        "fgts_cents": fgts_cents,
        "net_cents": net_cents,
    }


def save_exercise_image(file_storage):
    if not file_storage or not file_storage.filename:
        return None, None

    original = secure_filename(file_storage.filename)
    if not original or "." not in original:
        return None, "Selecione uma imagem JPG, JPEG, PNG ou WEBP."

    extension = original.rsplit(".", 1)[1].lower()
    if extension not in EXERCISE_IMAGE_EXTENSIONS:
        return None, "A imagem deve usar JPG, JPEG, PNG ou WEBP."

    file_storage.stream.seek(0, os.SEEK_END)
    size = file_storage.stream.tell()
    file_storage.stream.seek(0)
    if size > MAX_EXERCISE_IMAGE_BYTES:
        return None, "A imagem do exercício deve ter no máximo 8 MB."

    filename = f"{uuid.uuid4().hex}.{extension}"
    file_storage.save(EXERCISE_IMAGE_DIR / filename)
    return filename, None


def log_exercise_action(conn, exercise_id, action, actor_id, details=None):
    conn.execute(
        """
        INSERT INTO exercise_audit_log (
            exercise_id, action, performed_by, details
        )
        VALUES (?, ?, ?, ?)
        """,
        (exercise_id, action, actor_id, details or None)
    )


def seed_database():
    conn = get_db()

    roles = [
        ("OWNER", "Dono / Super Admin"),
        ("ADMIN", "Administrador"),
        ("EMPLOYEE", "Funcionário"),
        ("STUDENT", "Aluno")
    ]

    conn.executemany(
        """
        INSERT OR IGNORE INTO roles (
            code,
            name
        )
        VALUES (?, ?)
        """,
        roles
    )

    owner_role = conn.execute(
        """
        SELECT id
        FROM roles
        WHERE code = 'OWNER'
        """
    ).fetchone()

    owner = conn.execute(
        """
        SELECT id
        FROM users
        WHERE prontuario = '0001'
        """
    ).fetchone()

    if not owner:
        conn.execute(
            """
            INSERT INTO users (
                prontuario,
                password_hash,
                name,
                role_id
            )
            VALUES (?, ?, ?, ?)
            """,
            (
                "0001",
                generate_password_hash("admin123"),
                "Dono da Academia",
                owner_role["id"]
            )
        )

    plans_count = conn.execute(
        """
        SELECT COUNT(*) AS total
        FROM plans
        """
    ).fetchone()["total"]

    if plans_count == 0:
        conn.executemany(
            """
            INSERT INTO plans (
                name,
                description,
                duration_months,
                price_cents,
                cancellation_fee_percent
            )
            VALUES (?, ?, ?, ?, ?)
            """,
            [
                (
                    "Mensal",
                    "Plano mensal",
                    1,
                    9990,
                    0
                ),
                (
                    "Trimestral",
                    "Plano de três meses",
                    3,
                    26990,
                    5
                ),
                (
                    "Anual",
                    "Plano anual",
                    12,
                    89990,
                    10
                )
            ]
        )

    exercise_seed = [
        ("Supino reto", "Peitoral", "supino_reto.jpg", "Mantenha as escápulas apoiadas e controle a descida da barra."),
        ("Supino inclinado", "Peitoral", "supino_inclinado.jpg", "Controle o movimento e evite tirar os ombros do banco."),
        ("Puxada alta", "Costas", "puxada_alta.jpg", "Puxe em direção ao peito sem balançar o tronco."),
        ("Remada baixa", "Costas", "remada_baixa.jpg", "Conduza os cotovelos para trás e mantenha o tronco estável."),
        ("Rosca direta", "Bíceps", "rosca_direta.jpg", "Mantenha os cotovelos próximos ao corpo durante todo o movimento."),
        ("Tríceps pulley", "Tríceps", "triceps_pulley.jpg", "Estenda os cotovelos sem projetar os ombros para frente."),
        ("Agachamento livre", "Pernas", "agachamento_livre.jpg", "Mantenha os pés firmes e controle a amplitude definida pelo personal."),
        ("Leg press", "Pernas", "leg_press.jpg", "Mantenha lombar e quadril apoiados no equipamento."),
        ("Cadeira extensora", "Quadríceps", "cadeira_extensora.jpg", "Faça a extensão dos joelhos de forma controlada."),
        ("Mesa flexora", "Posterior de coxa", "mesa_flexora.jpg", "Evite levantar o quadril durante a flexão dos joelhos."),
        ("Elevação lateral", "Ombros", "elevacao_lateral.jpg", "Eleve os braços de forma controlada sem impulsionar o tronco."),
        ("Desenvolvimento com halteres", "Ombros", "desenvolvimento_halteres.jpg", "Mantenha o abdômen firme e controle a trajetória dos halteres."),
        ("Panturrilha em pé", "Panturrilha", "panturrilha_em_pe.jpg", "Faça a amplitude completa sem quicar."),
        ("Prancha abdominal", "Core", "prancha_abdominal.jpg", "Mantenha quadril, tronco e cabeça alinhados."),
    ]

    conn.executemany(
        """
        INSERT OR IGNORE INTO exercises (
            name, muscle_group, image_filename, instructions
        )
        VALUES (?, ?, ?, ?)
        """,
        exercise_seed
    )

    conn.commit()
    conn.close()


@app.route("/")
def index():
    if "user_id" not in session:
        return redirect(url_for("login"))

    return redirect(url_for("dashboard"))


@app.route(
    "/login",
    methods=["GET", "POST"]
)
def login():
    if request.method == "GET":
        return render_template("login.html")

    prontuario = request.form.get(
        "prontuario",
        ""
    ).strip().upper()

    password = request.form.get(
        "password",
        ""
    )

    conn = get_db()

    user = conn.execute(
        """
        SELECT
            users.*,
            roles.code AS role_code
        FROM users
        JOIN roles
            ON roles.id = users.role_id
        WHERE users.prontuario = ?
        """,
        (prontuario,)
    ).fetchone()

    conn.close()

    if not user or not check_password_hash(user["password_hash"], password):
        flash("Prontuário ou senha incorretos.")
        return render_template("login.html")

    if not user["active"]:
        if user["account_status"] == "PENDING_APPROVAL":
            flash("Seu cadastro está aguardando aprovação do RH/administrador.")
        elif user["account_status"] == "INVITED":
            flash("Conclua primeiro o primeiro acesso com o código do convite.")
        elif user["account_status"] == "REJECTED":
            flash("Seu cadastro foi rejeitado. Procure o RH/administrador.")
        else:
            flash("Sua conta está inativa.")
        return render_template("login.html")

    session.clear()
    session.permanent = True
    session["user_id"] = user["id"]
    session["last_activity"] = datetime.now().timestamp()

    return redirect(url_for("dashboard"))


@app.route("/primeiro-acesso", methods=["GET", "POST"])
def first_access():
    if request.method == "GET":
        return render_template("primeiro_acesso.html")

    prontuario = request.form.get("prontuario", "").strip().upper()
    access_code = request.form.get("access_code", "").strip().upper()

    conn = get_db()

    employee = conn.execute(
        """
        SELECT users.*, roles.code AS role_code
        FROM users
        JOIN roles ON roles.id = users.role_id
        WHERE users.prontuario = ?
        AND roles.code IN ('ADMIN', 'EMPLOYEE')
        """,
        (prontuario,)
    ).fetchone()

    conn.close()

    if not employee or employee["account_status"] != "INVITED":
        flash("Convite não encontrado ou primeiro acesso já concluído.")
        return render_template("primeiro_acesso.html")

    if not employee["onboarding_code_hash"] or not check_password_hash(
        employee["onboarding_code_hash"],
        access_code
    ):
        flash("Código de primeiro acesso inválido.")
        return render_template("primeiro_acesso.html")

    if employee["onboarding_expires_at"]:
        expiration = datetime.fromisoformat(employee["onboarding_expires_at"])
        if datetime.now() > expiration:
            flash("Esse código expirou. Solicite um novo código ao administrador.")
            return render_template("primeiro_acesso.html")

    session.clear()
    session["onboarding_user_id"] = employee["id"]

    return redirect(url_for("first_access_profile"))


@app.route("/primeiro-acesso/perfil", methods=["GET", "POST"])
def first_access_profile():
    employee_id = session.get("onboarding_user_id")

    if not employee_id:
        return redirect(url_for("first_access"))

    conn = get_db()

    employee = conn.execute(
        """
        SELECT
            users.*,
            roles.code AS role_code,
            employee_profiles.*
        FROM users
        JOIN roles ON roles.id = users.role_id
        LEFT JOIN employee_profiles
            ON employee_profiles.user_id = users.id
        WHERE users.id = ?
        AND users.account_status = 'INVITED'
        """,
        (employee_id,)
    ).fetchone()

    if not employee:
        conn.close()
        session.pop("onboarding_user_id", None)
        return redirect(url_for("first_access"))

    if request.method == "GET":
        conn.close()
        return render_template(
            "primeiro_acesso_perfil.html",
            employee=employee
        )

    password = request.form.get("password", "")
    password_confirm = request.form.get("password_confirm", "")
    email = request.form.get("email", "").strip().lower()
    phone = only_digits(request.form.get("phone", ""))
    birth_date = request.form.get("birth_date") or None
    zip_code = only_digits(request.form.get("zip_code", ""))
    address = request.form.get("address", "").strip()
    address_number = request.form.get("address_number", "").strip()
    complement = request.form.get("complement", "").strip()
    neighborhood = request.form.get("neighborhood", "").strip()
    city = request.form.get("city", "").strip()
    state = request.form.get("state", "").strip().upper()
    emergency_contact = request.form.get("emergency_contact", "").strip()
    emergency_phone = only_digits(request.form.get("emergency_phone", ""))
    dependents_count = request.form.get("dependents_count", type=int) or 0
    education_level = request.form.get("education_level", "").strip()
    education_course = request.form.get("education_course", "").strip()
    education_institution = request.form.get("education_institution", "").strip()
    professional_title = request.form.get("professional_title", "").strip()
    specialties = request.form.get("specialties", "").strip()
    professional_bio = request.form.get("professional_bio", "").strip()

    if len(password) < 6:
        conn.close()
        flash("A senha deve ter pelo menos 6 caracteres.")
        return redirect(url_for("first_access_profile"))

    if password != password_confirm:
        conn.close()
        flash("As senhas não coincidem.")
        return redirect(url_for("first_access_profile"))

    if not valid_email(email):
        conn.close()
        flash("Informe um e-mail válido.")
        return redirect(url_for("first_access_profile"))

    if email_in_use(conn, email, exclude_user_id=employee_id):
        conn.close()
        flash("Esse e-mail já está vinculado a outra conta.")
        return redirect(url_for("first_access_profile"))

    if len(phone) < 10:
        conn.close()
        flash("Informe um telefone válido.")
        return redirect(url_for("first_access_profile"))

    if state and len(state) != 2:
        conn.close()
        flash("Informe a UF com 2 letras.")
        return redirect(url_for("first_access_profile"))

    valid_education_levels = {
        "BASIC",
        "HIGH_SCHOOL",
        "TECHNICAL",
        "SUPERIOR_IN_PROGRESS",
        "SUPERIOR_COMPLETE",
        "POSTGRADUATE"
    }

    if education_level and education_level not in valid_education_levels:
        conn.close()
        flash("Escolaridade inválida.")
        return redirect(url_for("first_access_profile"))

    if employee["employee_type"] == "HR":
        if education_level not in {"SUPERIOR_COMPLETE", "POSTGRADUATE"}:
            conn.close()
            flash("Para a função de Analista de RH, informe ensino superior completo ou pós-graduação.")
            return redirect(url_for("first_access_profile"))
        if not education_course:
            conn.close()
            flash("Informe o curso superior do profissional de RH.")
            return redirect(url_for("first_access_profile"))

    conn.execute(
        """
        UPDATE employee_profiles
        SET email = ?,
            phone = ?,
            birth_date = ?,
            zip_code = ?,
            address = ?,
            address_number = ?,
            complement = ?,
            neighborhood = ?,
            city = ?,
            state = ?,
            emergency_contact = ?,
            emergency_phone = ?,
            dependents_count = ?,
            education_level = ?,
            education_course = ?,
            education_institution = ?,
            professional_title = ?,
            specialties = ?,
            professional_bio = ?,
            profile_completed_at = CURRENT_TIMESTAMP
        WHERE user_id = ?
        """,
        (
            email,
            phone,
            birth_date,
            zip_code or None,
            address or None,
            address_number or None,
            complement or None,
            neighborhood or None,
            city or None,
            state or None,
            emergency_contact or None,
            emergency_phone or None,
            dependents_count,
            education_level or None,
            education_course or None,
            education_institution or None,
            professional_title or None,
            specialties or None,
            professional_bio or None,
            employee_id
        )
    )

    conn.execute(
        """
        UPDATE users
        SET password_hash = ?,
            email = ?,
            account_status = 'PENDING_APPROVAL',
            active = 0,
            onboarding_completed_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (
            generate_password_hash(password),
            email,
            employee_id
        )
    )

    prontuario = employee["prontuario"]
    conn.commit()
    conn.close()

    session.clear()
    flash(
        f"Cadastro concluído para o prontuário {prontuario}. "
        "Agora aguarde a aprovação do RH/administrador."
    )
    return redirect(url_for("login"))


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/dashboard")
@login_required
def dashboard():
    user = current_user()

    if user["role_code"] in {
        "OWNER",
        "ADMIN"
    }:
        return redirect(
            url_for("admin_dashboard")
        )

    if user["role_code"] == "STUDENT":
        return redirect(
            url_for("student_dashboard")
        )

    if user["role_code"] == "EMPLOYEE":
        employee_type = user["employee_type"]

        if employee_type == "PERSONAL":
            return redirect(
                url_for("personal_dashboard")
            )

        if employee_type == "CLEANING":
            return redirect(
                url_for("cleaning_dashboard")
            )

        if employee_type == "SECURITY":
            return redirect(
                url_for("security_dashboard")
            )

        if employee_type == "RECEPTION":
            return redirect(
                url_for("reception_dashboard")
            )

        if employee_type == "HR":
            return redirect(
                url_for("hr_dashboard")
            )

    abort(403)


@app.route("/admin")
@require_roles(
    "OWNER",
    "ADMIN"
)
def admin_dashboard():
    conn = get_db()

    students_count = conn.execute(
        """
        SELECT COUNT(*) AS total
        FROM users
        JOIN roles
            ON roles.id = users.role_id
        WHERE roles.code = 'STUDENT'
        AND users.active = 1
        """
    ).fetchone()["total"]

    employees_count = conn.execute(
        """
        SELECT COUNT(*) AS total
        FROM users
        JOIN roles
            ON roles.id = users.role_id
        WHERE roles.code IN (
            'ADMIN',
            'EMPLOYEE'
        )
        AND users.active = 1
        """
    ).fetchone()["total"]

    revenue = conn.execute(
        """
        SELECT
            COALESCE(
                SUM(amount_cents),
                0
            ) AS total
        FROM payments
        WHERE status = 'PAID'
        """
    ).fetchone()["total"]

    pending_payments = conn.execute(
        """
        SELECT COUNT(*) AS total
        FROM payments
        WHERE status IN (
            'PENDING',
            'OVERDUE'
        )
        """
    ).fetchone()["total"]

    open_reports = conn.execute(
        """
        SELECT COUNT(*) AS total
        FROM security_reports
        WHERE status != 'RESOLVED'
        """
    ).fetchone()["total"]

    pending_tasks = conn.execute(
        """
        SELECT
            (SELECT COUNT(*) FROM cleaning_tasks WHERE status != 'COMPLETED') +
            (SELECT COUNT(*) FROM cleaning_requests WHERE status != 'COMPLETED')
            AS total
        """
    ).fetchone()["total"]

    pending_reception_messages = conn.execute(
        """
        SELECT COUNT(*) AS total
        FROM reception_messages
        WHERE status = 'PENDING'
        """
    ).fetchone()["total"]

    conn.close()

    stats = {
        "students": students_count,
        "employees": employees_count,
        "revenue": revenue,
        "pending_payments": pending_payments,
        "open_reports": open_reports,
        "pending_tasks": pending_tasks,
        "pending_reception_messages": pending_reception_messages
    }

    return render_template(
        "admin/dashboard.html",
        stats=stats
    )


@app.route("/funcionarios")
@require_hr_management
def employees():
    actor = current_user()
    conn = get_db()

    role_filter = (
        f"AND roles.code = 'EMPLOYEE' AND users.id != {int(actor['id'])}"
        if is_hr(actor)
        else "AND roles.code IN ('ADMIN', 'EMPLOYEE')"
    )

    employees = conn.execute(
        f"""
        SELECT
            users.*,
            roles.code AS role_code,
            roles.name AS role_name,
            employee_profiles.cpf,
            employee_profiles.email,
            employee_profiles.phone,
            employee_profiles.hire_date,
            employee_profiles.base_salary_cents,
            employee_profiles.weekly_hours,
            employee_profiles.employment_type,
            employee_profiles.profile_completed_at
        FROM users
        JOIN roles
            ON roles.id = users.role_id
        LEFT JOIN employee_profiles
            ON employee_profiles.user_id = users.id
        WHERE 1 = 1
        {role_filter}
        ORDER BY
            CASE users.account_status
                WHEN 'PENDING_APPROVAL' THEN 0
                WHEN 'INVITED' THEN 1
                WHEN 'ACTIVE' THEN 2
                WHEN 'INACTIVE' THEN 2
                ELSE 4
            END,
            users.name
        """
    ).fetchall()

    conn.close()

    return render_template(
        "admin/funcionarios.html",
        employees=employees,
        hr_mode=is_hr(actor),
        can_create_admin=(actor["role_code"] == "OWNER")
    )


@app.post("/funcionarios/novo")
@require_hr_management
def create_employee():
    actor = current_user()
    name = request.form.get("name", "").strip()
    role_code = request.form.get("role_code", "").strip()
    employee_type = request.form.get("employee_type") or None
    cpf = only_digits(request.form.get("cpf", ""))
    email = request.form.get("email", "").strip().lower()
    phone = only_digits(request.form.get("phone", ""))
    hire_date = request.form.get("hire_date") or date.today().isoformat()
    employment_type = request.form.get("employment_type", "CLT")
    weekly_hours = request.form.get("weekly_hours", type=float) or 44
    base_salary_cents = parse_money_to_cents(
        request.form.get("base_salary", "")
    )

    if not name:
        flash("Digite o nome do funcionário.")
        return redirect(url_for("employees"))

    if role_code == "ADMIN" and actor["role_code"] != "OWNER":
        flash("Somente o dono da academia pode criar contas de administrador.")
        return redirect(url_for("employees"))

    if is_hr(actor) and role_code != "EMPLOYEE":
        flash("O RH pode admitir funcionários, mas não criar contas de administrador.")
        return redirect(url_for("employees"))

    if role_code not in {"ADMIN", "EMPLOYEE"}:
        flash("Cargo inválido.")
        return redirect(url_for("employees"))

    if role_code == "EMPLOYEE" and employee_type not in {
        "PERSONAL",
        "CLEANING",
        "SECURITY",
        "RECEPTION",
        "HR"
    }:
        flash("Escolha a categoria do funcionário.")
        return redirect(url_for("employees"))

    if role_code == "ADMIN":
        employee_type = None

    if not cpf:
        flash("Informe o CPF do funcionário.")
        return redirect(url_for("employees"))

    if not validate_cpf(cpf):
        flash("CPF inválido.")
        return redirect(url_for("employees"))

    if email and not valid_email(email):
        flash("Informe um e-mail inicial válido ou deixe o campo vazio.")
        return redirect(url_for("employees"))

    if base_salary_cents is None:
        flash("Salário inválido.")
        return redirect(url_for("employees"))

    # Referência nacional de Analista de RH pesquisada em setembro/2026.
    # É apenas valor inicial sugerido e pode ser alterado por OWNER/ADMIN/RH.
    if employee_type == "HR" and base_salary_cents == 0:
        base_salary_cents = 440000

    if weekly_hours <= 0 or weekly_hours > 44:
        flash("A jornada semanal deve ficar entre 1 e 44 horas.")
        return redirect(url_for("employees"))

    if employment_type not in {
        "CLT",
        "TEMPORARY",
        "INTERN",
        "SERVICE_PROVIDER"
    }:
        flash("Tipo de vínculo inválido.")
        return redirect(url_for("employees"))

    conn = get_db()

    if email and email_in_use(conn, email):
        conn.close()
        flash("Esse e-mail já está vinculado a outra conta.")
        return redirect(url_for("employees"))

    if cpf:
        existing_cpf = conn.execute(
            "SELECT user_id FROM employee_profiles WHERE cpf = ?",
            (cpf,)
        ).fetchone()

        if existing_cpf:
            conn.close()
            flash("Já existe um funcionário com esse CPF.")
            return redirect(url_for("employees"))

    role = conn.execute(
        "SELECT id FROM roles WHERE code = ?",
        (role_code,)
    ).fetchone()

    prontuario = generate_employee_prontuario(conn)
    access_code = new_onboarding_code()
    expires_at = datetime.now() + timedelta(days=7)
    placeholder_password = secrets.token_urlsafe(32)

    cursor = conn.execute(
        """
        INSERT INTO users (
            prontuario,
            password_hash,
            name,
            role_id,
            employee_type,
            active,
            email,
            account_status,
            onboarding_code_hash,
            onboarding_expires_at
        )
        VALUES (?, ?, ?, ?, ?, 0, ?, 'INVITED', ?, ?)
        """,
        (
            prontuario,
            generate_password_hash(placeholder_password),
            name,
            role["id"],
            employee_type,
            email or None,
            generate_password_hash(access_code),
            expires_at.strftime("%Y-%m-%d %H:%M:%S")
        )
    )

    employee_id = cursor.lastrowid

    conn.execute(
        """
        INSERT INTO employee_profiles (
            user_id,
            cpf,
            email,
            phone,
            hire_date,
            base_salary_cents,
            weekly_hours,
            employment_type
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            employee_id,
            cpf or None,
            email or None,
            phone or None,
            hire_date,
            base_salary_cents,
            weekly_hours,
            employment_type
        )
    )

    conn.commit()
    conn.close()

    flash(
        "Pré-cadastro criado. "
        f"Prontuário: {prontuario} | "
        f"Código de primeiro acesso: {access_code} | "
        "válido por 7 dias. Copie o código agora."
    )

    return redirect(url_for("employees"))


@app.post("/funcionarios/<int:user_id>/novo-codigo")
@require_hr_management
def regenerate_employee_code(user_id):
    conn = get_db()

    employee = conn.execute(
        """
        SELECT users.*, roles.code AS role_code
        FROM users
        JOIN roles ON roles.id = users.role_id
        WHERE users.id = ?
        AND roles.code IN ('ADMIN', 'EMPLOYEE')
        """,
        (user_id,)
    ).fetchone()

    if not employee:
        conn.close()
        abort(404)

    if not hr_can_manage_target(current_user(), employee):
        conn.close()
        abort(403)

    if employee["account_status"] not in {"INVITED", "REJECTED"}:
        conn.close()
        flash("Só é possível gerar código para convite pendente ou rejeitado.")
        return redirect(url_for("employees"))

    access_code = new_onboarding_code()
    expires_at = datetime.now() + timedelta(days=7)

    conn.execute(
        """
        UPDATE users
        SET account_status = 'INVITED',
            active = 0,
            onboarding_code_hash = ?,
            onboarding_expires_at = ?,
            rejected_at = NULL,
            rejection_reason = NULL
        WHERE id = ?
        """,
        (
            generate_password_hash(access_code),
            expires_at.strftime("%Y-%m-%d %H:%M:%S"),
            user_id
        )
    )

    conn.commit()
    conn.close()

    flash(
        f"Novo código para {employee['prontuario']}: {access_code} "
        "(válido por 7 dias)."
    )

    return redirect(url_for("employees"))


@app.post("/funcionarios/<int:user_id>/aprovar")
@require_hr_management
def approve_employee(user_id):
    conn = get_db()

    employee = conn.execute(
        """
        SELECT users.id, users.account_status, users.employee_type,
               roles.code AS role_code
        FROM users
        JOIN roles ON roles.id = users.role_id
        WHERE users.id = ?
        AND roles.code IN ('ADMIN', 'EMPLOYEE')
        """,
        (user_id,)
    ).fetchone()

    if not employee:
        conn.close()
        abort(404)

    if not hr_can_manage_target(current_user(), employee):
        conn.close()
        abort(403)

    if employee["account_status"] != "PENDING_APPROVAL":
        conn.close()
        flash("Esse funcionário não está aguardando aprovação.")
        return redirect(url_for("employees"))

    conn.execute(
        """
        UPDATE users
        SET account_status = 'ACTIVE',
            active = 1,
            approved_at = CURRENT_TIMESTAMP,
            approved_by = ?,
            onboarding_code_hash = NULL,
            onboarding_expires_at = NULL
        WHERE id = ?
        """,
        (session["user_id"], user_id)
    )

    conn.commit()
    conn.close()

    flash("Funcionário aprovado e acesso liberado.")
    return redirect(url_for("employees"))


@app.post("/funcionarios/<int:user_id>/rejeitar")
@require_hr_management
def reject_employee(user_id):
    reason = request.form.get("reason", "").strip()
    conn = get_db()

    employee = conn.execute(
        """
        SELECT users.id, users.employee_type, roles.code AS role_code
        FROM users
        JOIN roles ON roles.id = users.role_id
        WHERE users.id = ?
        AND roles.code IN ('ADMIN', 'EMPLOYEE')
        """,
        (user_id,)
    ).fetchone()

    if not employee:
        conn.close()
        abort(404)

    if not hr_can_manage_target(current_user(), employee):
        conn.close()
        abort(403)

    conn.execute(
        """
        UPDATE users
        SET account_status = 'REJECTED',
            active = 0,
            rejected_at = CURRENT_TIMESTAMP,
            rejection_reason = ?
        WHERE id = ?
        """,
        (reason or None, user_id)
    )

    conn.commit()
    conn.close()

    flash("Cadastro rejeitado. Um novo código poderá ser emitido depois.")
    return redirect(url_for("employees"))


@app.post(
    "/usuario/<int:user_id>/desativar"
)
@login_required
def deactivate_user(user_id):
    actor = current_user()

    if user_id == actor["id"]:
        flash(
            "Você não pode desativar sua própria conta."
        )

        return redirect(
            request.referrer
            or url_for("dashboard")
        )

    conn = get_db()

    target = conn.execute(
        """
        SELECT
            users.id,
            roles.code AS role_code
        FROM users
        JOIN roles
            ON roles.id = users.role_id
        WHERE users.id = ?
        """,
        (user_id,)
    ).fetchone()

    if not target:
        conn.close()
        abort(404)

    allowed = False

    if actor["role_code"] == "OWNER":
        allowed = target["role_code"] != "OWNER"

    elif actor["role_code"] == "ADMIN":
        allowed = target["role_code"] in {"EMPLOYEE", "STUDENT"}

    elif is_reception(actor):
        allowed = target["role_code"] == "STUDENT"

    elif is_hr(actor):
        allowed = target["role_code"] == "EMPLOYEE" and target["id"] != actor["id"]

    if not allowed:
        conn.close()
        abort(403)

    conn.execute(
        """
        UPDATE users
        SET active = 0,
            account_status = CASE
                WHEN account_status IN ('INVITED', 'EMAIL_PENDING', 'PENDING_APPROVAL', 'REJECTED')
                    THEN account_status
                ELSE 'INACTIVE'
            END
        WHERE id = ?
        """,
        (user_id,)
    )

    conn.commit()
    conn.close()

    flash("Conta desativada.")

    return redirect(
        request.referrer
        or url_for("dashboard")
    )


@app.post(
    "/usuario/<int:user_id>/reativar"
)
@login_required
def activate_user(user_id):
    actor = current_user()

    conn = get_db()

    target = conn.execute(
        """
        SELECT
            users.id,
            users.name,
            users.prontuario,
            users.active,
            users.account_status,
            roles.code AS role_code
        FROM users
        JOIN roles
            ON roles.id = users.role_id
        WHERE users.id = ?
        """,
        (user_id,)
    ).fetchone()

    if not target:
        conn.close()
        abort(404)

    allowed = False

    if actor["role_code"] == "OWNER":
        allowed = target["role_code"] != "OWNER"

    elif actor["role_code"] == "ADMIN":
        allowed = target["role_code"] in {"EMPLOYEE", "STUDENT"}

    elif is_reception(actor):
        allowed = target["role_code"] == "STUDENT"

    elif is_hr(actor):
        allowed = target["role_code"] == "EMPLOYEE" and target["id"] != actor["id"]

    if not allowed:
        conn.close()
        abort(403)

    if target["role_code"] in {"ADMIN", "EMPLOYEE"} and target["account_status"] in {
        "INVITED",
        "PENDING_APPROVAL",
        "REJECTED"
    }:
        conn.close()
        flash("Esse cadastro precisa concluir o fluxo de primeiro acesso/aprovação, não uma reativação comum.")
        return redirect(
            request.referrer
            or url_for("employees")
        )

    if target["active"]:
        conn.close()

        flash("Essa conta já está ativa.")

        return redirect(
            request.referrer
            or url_for("dashboard")
        )

    conn.execute(
        """
        UPDATE users
        SET active = 1,
            account_status = 'ACTIVE'
        WHERE id = ?
        """,
        (user_id,)
    )

    if is_reception(actor) and target["role_code"] == "STUDENT":
        conn.execute(
            """
            INSERT INTO system_events (
                event_type, actor_id, target_user_id, title, message
            )
            VALUES ('STUDENT_REACTIVATED', ?, ?, ?, ?)
            """,
            (
                actor["id"],
                user_id,
                "Aluno reativado pela recepção",
                f"{target['name']} ({target['prontuario']}) foi reativado por {actor['name']}.",
            ),
        )

    conn.commit()
    conn.close()

    flash("Conta reativada com sucesso.")

    return redirect(
        request.referrer
        or url_for("dashboard")
    )


@app.route("/alunos")
@login_required
def students():
    user = current_user()

    allowed = (
        user["role_code"]
        in {
            "OWNER",
            "ADMIN"
        }
        or
        (
            user["role_code"]
            == "EMPLOYEE"
            and
            user["employee_type"]
            == "RECEPTION"
        )
    )

    if not allowed:
        abort(403)

    conn = get_db()

    students = conn.execute(
        """
        SELECT
            users.*
        FROM users
        JOIN roles
            ON roles.id = users.role_id
        WHERE roles.code = 'STUDENT'
        ORDER BY users.name
        """
    ).fetchall()

    plan_rows = conn.execute(
        """
        SELECT *
        FROM plans
        WHERE active = 1
        ORDER BY price_cents
        """
    ).fetchall()
    plans = [plan_view_data(plan) for plan in plan_rows]

    conn.close()

    return render_template(
        "admin/alunos.html",
        students=students,
        plans=plans
    )


@app.post("/alunos/novo")
@login_required
def create_student():
    user = current_user()

    allowed = (
        user["role_code"] in {"OWNER", "ADMIN"}
        or (
            user["role_code"] == "EMPLOYEE"
            and user["employee_type"] == "RECEPTION"
        )
    )

    if not allowed:
        abort(403)

    name = request.form.get("name", "").strip()
    email = request.form.get("email", "").strip().lower()
    password = request.form.get("password", "")
    plan_id = request.form.get("plan_id", type=int)

    if not name:
        flash("Digite o nome do aluno.")
        return redirect(url_for("students"))

    if not valid_email(email):
        flash("Informe um e-mail válido para o aluno.")
        return redirect(url_for("students"))

    if len(password) < 6:
        flash("A senha inicial deve ter pelo menos 6 caracteres.")
        return redirect(url_for("students"))

    conn = get_db()

    if email_in_use(conn, email):
        conn.close()
        flash("Esse e-mail já está vinculado a outra conta.")
        return redirect(url_for("students"))

    prontuario = generate_student_prontuario(conn)

    role = conn.execute(
        "SELECT id FROM roles WHERE code = 'STUDENT'"
    ).fetchone()

    plan = conn.execute(
        """
        SELECT *
        FROM plans
        WHERE id = ?
          AND active = 1
        """,
        (plan_id,)
    ).fetchone()

    if not plan:
        conn.close()
        flash("Plano inválido.")
        return redirect(url_for("students"))

    try:
        cursor = conn.execute(
            """
            INSERT INTO users (
                prontuario, password_hash, name, role_id, active, email,
                account_status
            )
            VALUES (?, ?, ?, ?, 1, ?, 'ACTIVE')
            """,
            (
                prontuario,
                generate_password_hash(password),
                name,
                role["id"],
                email
            )
        )

        student_id = cursor.lastrowid

        conn.execute(
            """
            INSERT INTO student_profiles (user_id, email)
            VALUES (?, ?)
            """,
            (student_id, email)
        )

        start_date = date.today()
        end_date = calculate_plan_end_date(start_date, plan)
        contracted_price_cents = effective_plan_price_cents(plan, start_date)

        subscription = conn.execute(
            """
            INSERT INTO subscriptions (
                student_id, plan_id, start_date, end_date, status,
                contracted_channel
            )
            VALUES (?, ?, ?, ?, 'ACTIVE', 'PRESENTIAL')
            """,
            (
                student_id,
                plan["id"],
                start_date.isoformat(),
                end_date.isoformat()
            )
        )

        conn.execute(
            """
            INSERT INTO payments (
                student_id, subscription_id, amount_cents, due_date, status
            )
            VALUES (?, ?, ?, ?, 'PENDING')
            """,
            (
                student_id,
                subscription.lastrowid,
                contracted_price_cents,
                start_date.isoformat()
            )
        )

        conn.commit()
        conn.close()

        flash(
            f"Aluno cadastrado com sucesso. Prontuário: {prontuario}. "
            "A conta já está liberada para login."
        )

    except Exception as error:
        try:
            conn.rollback()
            conn.close()
        except Exception:
            pass
        flash(f"Erro ao cadastrar aluno: {error}")

    return redirect(url_for("students"))


@app.route("/planos")
@require_plan_management
def plans_management():
    conn = get_db()
    rows = conn.execute(
        """
        SELECT
            plans.*,
            COUNT(DISTINCT CASE WHEN subscriptions.status = 'ACTIVE' THEN subscriptions.id END) AS active_subscriptions
        FROM plans
        LEFT JOIN subscriptions ON subscriptions.plan_id = plans.id
        GROUP BY plans.id
        ORDER BY plans.active DESC, plans.price_cents, plans.name
        """
    ).fetchall()
    plans = [plan_view_data(row) for row in rows]
    conn.close()

    return render_template(
        "admin/planos.html",
        plans=plans,
        today=date.today().isoformat()
    )


@app.post("/planos/novo")
@require_plan_management
def create_plan():
    name = request.form.get("name", "").strip()[:100]
    description = request.form.get("description", "").strip()[:300]
    duration_value = request.form.get("duration_value", type=int)
    duration_unit = request.form.get("duration_unit", "MONTHS")
    price_cents = parse_money_to_cents(request.form.get("price", ""))
    cancellation_fee = request.form.get("cancellation_fee_percent", type=float)
    discount_percent = request.form.get("discount_percent", type=float)
    discount_start = request.form.get("discount_start", "").strip() or None
    discount_end = request.form.get("discount_end", "").strip() or None

    error = validate_plan_form(
        name, duration_value, duration_unit, price_cents, cancellation_fee,
        discount_percent, discount_start, discount_end
    )
    if error:
        flash(error)
        return redirect(url_for("plans_management"))

    duration_months = duration_value if duration_unit == "MONTHS" else 0
    duration_days = duration_value if duration_unit == "DAYS" else 0

    conn = get_db()
    conn.execute(
        """
        INSERT INTO plans (
            name, description, duration_months, duration_days, price_cents,
            cancellation_fee_percent, discount_percent, discount_start,
            discount_end, active, updated_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, CURRENT_TIMESTAMP)
        """,
        (
            name, description or None, duration_months, duration_days, price_cents,
            cancellation_fee or 0, discount_percent or 0, discount_start, discount_end
        )
    )
    conn.commit()
    conn.close()

    flash("Plano criado.")
    return redirect(url_for("plans_management"))


@app.post("/planos/<int:plan_id>/editar")
@require_plan_management
def update_plan(plan_id):
    name = request.form.get("name", "").strip()[:100]
    description = request.form.get("description", "").strip()[:300]
    duration_value = request.form.get("duration_value", type=int)
    duration_unit = request.form.get("duration_unit", "MONTHS")
    price_cents = parse_money_to_cents(request.form.get("price", ""))
    cancellation_fee = request.form.get("cancellation_fee_percent", type=float)
    discount_percent = request.form.get("discount_percent", type=float)
    discount_start = request.form.get("discount_start", "").strip() or None
    discount_end = request.form.get("discount_end", "").strip() or None
    active = 1 if request.form.get("active") == "1" else 0

    error = validate_plan_form(
        name, duration_value, duration_unit, price_cents, cancellation_fee,
        discount_percent, discount_start, discount_end
    )
    if error:
        flash(error)
        return redirect(url_for("plans_management"))

    duration_months = duration_value if duration_unit == "MONTHS" else 0
    duration_days = duration_value if duration_unit == "DAYS" else 0

    conn = get_db()
    plan = conn.execute("SELECT id FROM plans WHERE id = ?", (plan_id,)).fetchone()
    if not plan:
        conn.close()
        abort(404)

    conn.execute(
        """
        UPDATE plans
        SET name = ?, description = ?, duration_months = ?, duration_days = ?,
            price_cents = ?, cancellation_fee_percent = ?, discount_percent = ?,
            discount_start = ?, discount_end = ?, active = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (
            name, description or None, duration_months, duration_days, price_cents,
            cancellation_fee or 0, discount_percent or 0, discount_start,
            discount_end, active, plan_id
        )
    )
    conn.commit()
    conn.close()

    flash("Plano atualizado.")
    return redirect(url_for("plans_management"))


def validate_plan_form(
    name, duration_value, duration_unit, price_cents, cancellation_fee,
    discount_percent, discount_start, discount_end
):
    if not name:
        return "Informe o nome do plano."

    if not duration_value or duration_value < 1 or duration_value > 3650:
        return "Informe uma duração válida."

    if duration_unit not in {"DAYS", "MONTHS"}:
        return "Unidade de duração inválida."

    if price_cents is None or price_cents < 0:
        return "Informe um preço válido."

    cancellation_fee = cancellation_fee or 0
    discount_percent = discount_percent or 0

    if cancellation_fee < 0 or cancellation_fee > 100:
        return "A taxa de cancelamento deve ficar entre 0% e 100%."

    if discount_percent < 0 or discount_percent > 100:
        return "O desconto deve ficar entre 0% e 100%."

    try:
        start_date = date.fromisoformat(discount_start) if discount_start else None
        end_date = date.fromisoformat(discount_end) if discount_end else None
    except ValueError:
        return "Período de desconto inválido."

    if start_date and end_date and end_date < start_date:
        return "A data final do desconto não pode ser anterior à inicial."

    if discount_percent > 0 and not (start_date or end_date):
        return "Defina ao menos uma data para a vigência do desconto."

    return None


@app.route("/financeiro")
@login_required
def finance():
    user = current_user()

    allowed = (
        user["role_code"]
        in {
            "OWNER",
            "ADMIN"
        }
        or
        (
            user["role_code"]
            == "EMPLOYEE"
            and
            user["employee_type"]
            in {"RECEPTION", "HR"}
        )
    )

    if not allowed:
        abort(403)

    period = request.args.get("period", "12")
    today = date.today()

    if period == "6":
        month_count = 6
        start_month = add_months(today.replace(day=1), -5)
        period_label = "Últimos 6 meses"
    elif period == "year":
        month_count = today.month
        start_month = date(today.year, 1, 1)
        period_label = str(today.year)
    else:
        period = "12"
        month_count = 12
        start_month = add_months(today.replace(day=1), -11)
        period_label = "Últimos 12 meses"

    end_month = add_months(today.replace(day=1), 1)
    start_iso = start_month.isoformat()
    end_iso = end_month.isoformat()
    current_month_iso = today.replace(day=1).isoformat()

    conn = get_db()

    payments = conn.execute(
        """
        SELECT
            payments.*,
            users.name AS student_name,
            users.prontuario
        FROM payments
        JOIN users
            ON users.id = payments.student_id
        ORDER BY payments.due_date DESC, payments.id DESC
        """
    ).fetchall()

    period_summary = conn.execute(
        """
        SELECT
            COALESCE(SUM(CASE WHEN status = 'PAID' THEN amount_cents ELSE 0 END), 0) AS received_cents,
            COALESCE(SUM(CASE WHEN status IN ('PENDING', 'OVERDUE') THEN amount_cents ELSE 0 END), 0) AS open_cents,
            COALESCE(SUM(CASE WHEN status = 'OVERDUE' THEN amount_cents ELSE 0 END), 0) AS overdue_cents,
            COALESCE(SUM(CASE WHEN status NOT IN ('CANCELED', 'REFUNDED') THEN amount_cents ELSE 0 END), 0) AS billable_cents,
            SUM(CASE WHEN status = 'PAID' THEN 1 ELSE 0 END) AS paid_count
        FROM payments
        WHERE due_date >= ? AND due_date < ?
        """,
        (start_iso, end_iso)
    ).fetchone()

    current_month = conn.execute(
        """
        SELECT
            COALESCE(SUM(CASE WHEN status = 'PAID' THEN amount_cents ELSE 0 END), 0) AS received_cents,
            COALESCE(SUM(CASE WHEN status = 'PENDING' THEN amount_cents ELSE 0 END), 0) AS pending_cents,
            COALESCE(SUM(CASE WHEN status = 'OVERDUE' THEN amount_cents ELSE 0 END), 0) AS overdue_cents,
            COALESCE(SUM(CASE WHEN status NOT IN ('CANCELED', 'REFUNDED') THEN amount_cents ELSE 0 END), 0) AS expected_cents
        FROM payments
        WHERE due_date >= ? AND due_date < ?
        """,
        (current_month_iso, end_iso)
    ).fetchone()

    monthly_rows = conn.execute(
        """
        SELECT
            substr(due_date, 1, 7) AS month_key,
            COALESCE(SUM(CASE WHEN status NOT IN ('CANCELED', 'REFUNDED') THEN amount_cents ELSE 0 END), 0) AS expected_cents,
            COALESCE(SUM(CASE WHEN status = 'PAID' THEN amount_cents ELSE 0 END), 0) AS received_cents,
            COALESCE(SUM(CASE WHEN status IN ('PENDING', 'OVERDUE') THEN amount_cents ELSE 0 END), 0) AS open_cents
        FROM payments
        WHERE due_date >= ? AND due_date < ?
        GROUP BY substr(due_date, 1, 7)
        ORDER BY month_key
        """,
        (start_iso, end_iso)
    ).fetchall()

    status_rows = conn.execute(
        """
        SELECT
            status,
            COUNT(*) AS payment_count,
            COALESCE(SUM(amount_cents), 0) AS total_cents
        FROM payments
        WHERE due_date >= ? AND due_date < ?
        GROUP BY status
        """,
        (start_iso, end_iso)
    ).fetchall()

    method_rows = conn.execute(
        """
        SELECT
            COALESCE(payment_method, 'UNINFORMED') AS payment_method,
            COUNT(*) AS payment_count,
            COALESCE(SUM(amount_cents), 0) AS total_cents
        FROM payments
        WHERE due_date >= ? AND due_date < ?
          AND status = 'PAID'
        GROUP BY COALESCE(payment_method, 'UNINFORMED')
        ORDER BY total_cents DESC
        """,
        (start_iso, end_iso)
    ).fetchall()

    plan_rows = conn.execute(
        """
        SELECT
            plans.name AS plan_name,
            COUNT(payments.id) AS payment_count,
            COALESCE(SUM(payments.amount_cents), 0) AS total_cents
        FROM payments
        JOIN subscriptions ON subscriptions.id = payments.subscription_id
        JOIN plans ON plans.id = subscriptions.plan_id
        WHERE payments.due_date >= ? AND payments.due_date < ?
          AND payments.status = 'PAID'
        GROUP BY plans.id, plans.name
        ORDER BY total_cents DESC, plans.name
        """,
        (start_iso, end_iso)
    ).fetchall()

    active_students = conn.execute(
        """
        SELECT COUNT(*) AS total
        FROM users
        JOIN roles ON roles.id = users.role_id
        WHERE roles.code = 'STUDENT' AND users.active = 1
        """
    ).fetchone()["total"]

    conn.close()

    month_names = [
        "Jan", "Fev", "Mar", "Abr", "Mai", "Jun",
        "Jul", "Ago", "Set", "Out", "Nov", "Dez"
    ]
    monthly_map = {row["month_key"]: row for row in monthly_rows}
    monthly_labels = []
    monthly_expected = []
    monthly_received = []
    monthly_open = []

    cursor = start_month
    for _ in range(month_count):
        key = cursor.strftime("%Y-%m")
        row = monthly_map.get(key)
        monthly_labels.append(f"{month_names[cursor.month - 1]}/{str(cursor.year)[2:]}")
        monthly_expected.append((row["expected_cents"] if row else 0) / 100)
        monthly_received.append((row["received_cents"] if row else 0) / 100)
        monthly_open.append((row["open_cents"] if row else 0) / 100)
        cursor = add_months(cursor, 1)

    status_names = {
        "PAID": "Pago",
        "PENDING": "Pendente",
        "OVERDUE": "Atrasado",
        "CANCELED": "Cancelado",
        "REFUNDED": "Reembolsado"
    }
    method_names = {
        "SIMULATED_DIGITAL": "Digital",
        "CASH": "Dinheiro",
        "PIX": "PIX",
        "CARD": "Cartão",
        "OTHER": "Outro",
        "UNINFORMED": "Não informado"
    }

    billable = period_summary["billable_cents"] or 0
    received = period_summary["received_cents"] or 0
    paid_count = period_summary["paid_count"] or 0
    collection_rate = round((received / billable) * 100, 1) if billable else 0
    monthly_average_cents = round(received / month_count) if month_count else 0
    average_ticket_cents = round(received / paid_count) if paid_count else 0
    revenue_per_active_student_cents = (
        round(received / active_students) if active_students else 0
    )

    finance_data = {
        "monthly": {
            "labels": monthly_labels,
            "expected": monthly_expected,
            "received": monthly_received,
            "open": monthly_open
        },
        "status": {
            "labels": [status_names.get(row["status"], row["status"]) for row in status_rows],
            "values": [row["total_cents"] / 100 for row in status_rows],
            "counts": [row["payment_count"] for row in status_rows]
        },
        "methods": {
            "labels": [method_names.get(row["payment_method"], row["payment_method"]) for row in method_rows],
            "values": [row["total_cents"] / 100 for row in method_rows]
        },
        "plans": {
            "labels": [row["plan_name"] for row in plan_rows],
            "values": [row["total_cents"] / 100 for row in plan_rows]
        }
    }

    metrics = {
        "received_cents": received,
        "open_cents": period_summary["open_cents"] or 0,
        "overdue_cents": period_summary["overdue_cents"] or 0,
        "monthly_average_cents": monthly_average_cents,
        "average_ticket_cents": average_ticket_cents,
        "revenue_per_active_student_cents": revenue_per_active_student_cents,
        "collection_rate": collection_rate,
        "active_students": active_students
    }

    return render_template(
        "admin/financeiro.html",
        payments=payments,
        period=period,
        period_label=period_label,
        now_year=today.year,
        metrics=metrics,
        current_month=current_month,
        finance_data=finance_data,
        can_manage_plans=can_manage_plans(user)
    )


@app.post(
    "/pagamento/<int:payment_id>/manual"
)
@login_required
def manual_payment(payment_id):
    user = current_user()

    allowed = (
        user["role_code"]
        in {
            "OWNER",
            "ADMIN"
        }
        or
        (
            user["role_code"]
            == "EMPLOYEE"
            and
            user["employee_type"]
            == "RECEPTION"
        )
    )

    if not allowed:
        abort(403)

    method = request.form.get(
        "method"
    )

    if method not in {
        "CASH",
        "PIX",
        "CARD",
        "OTHER"
    }:
        flash(
            "Forma de pagamento inválida."
        )

        return redirect(
            url_for("finance")
        )

    if user["role_code"] in {
        "OWNER",
        "ADMIN"
    }:
        origin = "ADMIN"
    else:
        origin = "RECEPTION"

    conn = get_db()

    payment = conn.execute(
        """
        SELECT *
        FROM payments
        WHERE id = ?
        """,
        (payment_id,)
    ).fetchone()

    if not payment:
        conn.close()
        abort(404)

    if payment["status"] == "PAID":
        conn.close()

        flash(
            "Esse pagamento já foi realizado."
        )

        return redirect(
            url_for("finance")
        )

    conn.execute(
        """
        UPDATE payments
        SET
            status = 'PAID',
            paid_at = CURRENT_TIMESTAMP,
            payment_method = ?,
            payment_origin = ?,
            registered_by = ?
        WHERE id = ?
        """,
        (
            method,
            origin,
            user["id"],
            payment_id
        )
    )

    conn.commit()
    conn.close()

    flash(
        "Pagamento registrado com sucesso."
    )

    return redirect(
        url_for("finance")
    )


@app.route("/admin/limpeza")
@require_roles("OWNER", "ADMIN")
def manage_cleaning():
    return redirect(url_for("messages_center") + "#limpeza")


@app.post("/admin/limpeza/nova")
@require_roles(
    "OWNER",
    "ADMIN"
)
def create_cleaning_task():
    title = request.form.get(
        "title",
        ""
    ).strip()

    description = request.form.get(
        "description",
        ""
    ).strip()

    assigned_to = request.form.get(
        "assigned_to",
        type=int
    )

    due_date = request.form.get(
        "due_date"
    ) or None

    if not title:
        flash(
            "Digite o título da tarefa."
        )

        return redirect(
            url_for("manage_cleaning")
        )

    conn = get_db()

    worker = conn.execute(
        """
        SELECT id
        FROM users
        WHERE id = ?
        AND employee_type = 'CLEANING'
        AND active = 1
        """,
        (assigned_to,)
    ).fetchone()

    if not worker:
        conn.close()

        flash(
            "Funcionário da limpeza inválido."
        )

        return redirect(
            url_for("manage_cleaning")
        )

    conn.execute(
        """
        INSERT INTO cleaning_tasks (
            title,
            description,
            assigned_to,
            created_by,
            due_date
        )
        VALUES (?, ?, ?, ?, ?)
        """,
        (
            title,
            description,
            assigned_to,
            session["user_id"],
            due_date
        )
    )

    conn.commit()
    conn.close()

    flash(
        "Tarefa criada com sucesso."
    )

    return redirect(
        url_for("manage_cleaning")
    )


@app.route("/admin/ocorrencias")
@require_roles("OWNER", "ADMIN")
def reports():
    return redirect(url_for("employee_notifications", tipo="SECURITY"))


@app.route("/admin/notificacoes")
@require_roles("OWNER", "ADMIN")
def admin_notifications():
    return redirect(url_for("employee_notifications"))


@app.route("/recepcao")
@require_employee_types(
    "RECEPTION"
)
def reception_dashboard():
    conn = get_db()

    pending_messages = conn.execute(
        """
        SELECT COUNT(*) AS total
        FROM system_messages
        WHERE target_group = 'RECEPTION'
          AND NOT EXISTS (
              SELECT 1 FROM notification_reads
              WHERE notification_reads.user_id = ?
                AND notification_reads.source_type = 'MESSAGE'
                AND notification_reads.source_id = system_messages.id
          )
        """,
        (session["user_id"],)
    ).fetchone()["total"]

    conn.close()

    return render_template(
        "recepcao/dashboard.html",
        pending_messages=pending_messages
    )


@app.route("/recepcao/recados")
@require_employee_types("RECEPTION")
def reception_messages():
    return redirect(url_for("messages_center"))


@app.post("/recados/recepcao/enviar")
@login_required
def send_reception_message():
    user = current_user()
    message = request.form.get("message", "").strip()

    if not message:
        flash("Digite o recado.")
        return redirect(request.referrer or url_for("messages_center"))

    conn = get_db()
    recipients = conn.execute(
        """
        SELECT id FROM users
        WHERE active = 1 AND employee_type = 'RECEPTION' AND id != ?
        """,
        (user["id"],),
    ).fetchall()
    if not recipients:
        conn.close()
        flash("Não há recepcionista ativo para receber o recado.")
        return redirect(url_for("messages_center"))

    cursor = conn.execute(
        """
        INSERT INTO system_messages (
            sender_id, target_group, subject, message, delivery_mode
        )
        VALUES (?, 'RECEPTION', 'Recado', ?, 'SPECIFIC')
        """,
        (user["id"], message),
    )
    conn.executemany(
        "INSERT INTO system_message_recipients (message_id, user_id) VALUES (?, ?)",
        [(cursor.lastrowid, row["id"]) for row in recipients],
    )
    conn.commit()
    conn.close()

    flash("Recado enviado para a recepção.")
    return redirect(url_for("messages_center"))


@app.post(
    "/recepcao/recados/<int:message_id>/encaminhar"
)
@require_employee_types(
    "RECEPTION"
)
def forward_reception_message(message_id):
    classification = request.form.get(
        "classification"
    )

    if classification not in {
        "IMPORTANT",
        "SECONDARY"
    }:
        flash("Classificação inválida.")
        return redirect(
            url_for("reception_messages")
        )

    conn = get_db()

    message = conn.execute(
        """
        SELECT *
        FROM reception_messages
        WHERE id = ?
        """,
        (message_id,)
    ).fetchone()

    if not message:
        conn.close()
        abort(404)

    if message["status"] == "SENT":
        conn.close()
        flash("Esse recado já foi enviado aos administradores.")
        return redirect(
            url_for("reception_messages")
        )

    conn.execute(
        """
        UPDATE reception_messages
        SET
            status = 'SENT',
            classification = ?,
            forwarded_by = ?,
            forwarded_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (
            classification,
            session["user_id"],
            message_id
        )
    )

    conn.commit()
    conn.close()

    flash("Recado enviado aos administradores.")

    return redirect(
        url_for("reception_messages")
    )


@app.post("/recepcao/recados/novo-admin")
@require_employee_types(
    "RECEPTION"
)
def reception_create_admin_message():
    message = request.form.get(
        "message",
        ""
    ).strip()

    classification = request.form.get(
        "classification"
    )

    if not message:
        flash("Digite o recado.")
        return redirect(
            url_for("reception_messages")
        )

    if classification not in {
        "IMPORTANT",
        "SECONDARY"
    }:
        flash("Classificação inválida.")
        return redirect(
            url_for("reception_messages")
        )

    conn = get_db()

    conn.execute(
        """
        INSERT INTO reception_messages (
            sender_id,
            message,
            status,
            classification,
            forwarded_by,
            forwarded_at
        )
        VALUES (
            ?,
            ?,
            'SENT',
            ?,
            ?,
            CURRENT_TIMESTAMP
        )
        """,
        (
            session["user_id"],
            message,
            classification,
            session["user_id"]
        )
    )

    conn.commit()
    conn.close()

    flash("Recado enviado aos administradores.")

    return redirect(
        url_for("reception_messages")
    )


@app.route("/notificacoes")
@login_required
def employee_notifications():
    user = current_user()
    selected_kind = request.args.get("tipo", "ALL").strip().upper()
    allowed_kinds = {"ALL", "MESSAGE", "SECURITY", "HR", "CLEANING", "FINANCE", "TRAINING", "ACCOUNT"}
    if selected_kind not in allowed_kinds:
        selected_kind = "ALL"

    conn = get_db()
    items = notification_items_for_user(conn, user)
    counts = {kind: 0 for kind in allowed_kinds if kind != "ALL"}
    for item in items:
        counts[item["kind"]] = counts.get(item["kind"], 0) + 1

    visible_items = items if selected_kind == "ALL" else [
        item for item in items if item["kind"] == selected_kind
    ]

    mark_notifications_read(conn, user["id"], visible_items)
    conn.commit()
    conn.close()

    return render_template(
        "notificacoes.html",
        items=visible_items,
        counts=counts,
        selected_kind=selected_kind,
    )


@app.route("/recados")
@login_required
def messages_center():
    user = current_user()
    conn = get_db()
    recipient_options = message_recipient_candidates(conn, user)

    inbox = conn.execute(
        """
        SELECT messages.*, sender.name AS sender_name
        FROM system_message_recipients recipients
        JOIN system_messages messages ON messages.id = recipients.message_id
        JOIN users sender ON sender.id = messages.sender_id
        WHERE recipients.user_id = ?
        ORDER BY messages.id DESC
        LIMIT 100
        """,
        (user["id"],),
    ).fetchall()

    sent_messages = conn.execute(
        """
        SELECT messages.*,
               COUNT(DISTINCT recipients.user_id) AS recipient_count,
               COUNT(DISTINCT reads.user_id) AS read_count
        FROM system_messages messages
        LEFT JOIN system_message_recipients recipients
               ON recipients.message_id = messages.id
        LEFT JOIN notification_reads reads
               ON reads.user_id = recipients.user_id
              AND reads.source_type = 'MESSAGE'
              AND reads.source_id = messages.id
        WHERE messages.sender_id = ?
        GROUP BY messages.id
        ORDER BY messages.id DESC
        LIMIT 60
        """,
        (user["id"],),
    ).fetchall()

    cleaning_requests = conn.execute(
        """
        SELECT cleaning_requests.*, requester.name AS requester_name,
               worker.name AS worker_name
        FROM cleaning_requests
        JOIN users requester ON requester.id = cleaning_requests.requester_id
        LEFT JOIN users worker ON worker.id = cleaning_requests.assigned_to
        WHERE cleaning_requests.status IN ('PENDING', 'IN_PROGRESS')
        ORDER BY
            CASE cleaning_requests.status WHEN 'PENDING' THEN 0 ELSE 1 END,
            cleaning_requests.id DESC
        LIMIT 120
        """
    ).fetchall()

    cleaners = []
    if user["role_code"] in {"OWNER", "ADMIN"}:
        cleaners = conn.execute(
            """
            SELECT id, name FROM users
            WHERE employee_type = 'CLEANING' AND active = 1
            ORDER BY name
            """
        ).fetchall()

    for item in inbox:
        conn.execute(
            """
            INSERT OR IGNORE INTO notification_reads (user_id, source_type, source_id)
            VALUES (?, 'MESSAGE', ?)
            """,
            (user["id"], item["id"]),
        )
    for item in cleaning_requests:
        conn.execute(
            """
            INSERT OR IGNORE INTO notification_reads (user_id, source_type, source_id)
            VALUES (?, ?, ?)
            """,
            (user["id"], f"CLEANING_{item['status']}", item["id"]),
        )
    conn.commit()
    conn.close()

    return render_template(
        "recados.html",
        recipient_options=recipient_options,
        inbox=inbox,
        sent_messages=sent_messages,
        cleaning_requests=cleaning_requests,
        cleaners=cleaners,
    )


@app.post("/recados/enviar")
@login_required
def send_system_message():
    user = current_user()
    subject = request.form.get("subject", "").strip()
    message = request.form.get("message", "").strip()
    priority = request.form.get("priority", "NORMAL").strip().upper()
    send_all = request.form.get("send_all") == "1"

    if not subject or not message:
        flash("Preencha o assunto e o recado.")
        return redirect(url_for("messages_center"))
    if priority not in {"NORMAL", "HIGH"}:
        priority = "NORMAL"

    conn = get_db()
    candidates = message_recipient_candidates(conn, user)
    candidate_ids = {item["id"] for item in candidates}

    if send_all:
        recipient_ids = sorted(candidate_ids)
        delivery_mode = "ALL"
    else:
        recipient_ids = []
        for value in request.form.getlist("recipient_ids"):
            try:
                recipient_id = int(value)
            except (TypeError, ValueError):
                continue
            if recipient_id in candidate_ids and recipient_id not in recipient_ids:
                recipient_ids.append(recipient_id)
        delivery_mode = "SPECIFIC"

    if not recipient_ids:
        conn.close()
        flash("Selecione pelo menos um destinatário.")
        return redirect(url_for("messages_center"))

    cursor = conn.execute(
        """
        INSERT INTO system_messages (
            sender_id, target_group, subject, message, priority, delivery_mode
        )
        VALUES (?, 'ADMIN', ?, ?, ?, ?)
        """,
        (user["id"], subject, message, priority, delivery_mode),
    )
    message_id = cursor.lastrowid
    conn.executemany(
        """
        INSERT INTO system_message_recipients (message_id, user_id)
        VALUES (?, ?)
        """,
        [(message_id, recipient_id) for recipient_id in recipient_ids],
    )
    conn.commit()
    conn.close()
    flash("Recado enviado.")
    return redirect(url_for("messages_center"))


@app.post("/recados/limpeza/nova")
@login_required
def create_cleaning_request():
    user = current_user()
    if user["role_code"] == "EMPLOYEE" and user["employee_type"] == "CLEANING":
        abort(403)

    title = request.form.get("title", "").strip()
    location = request.form.get("location", "").strip()
    description = request.form.get("description", "").strip()
    priority = request.form.get("priority", "NORMAL").strip().upper()

    if not title:
        flash("Informe o que precisa ser limpo.")
        return redirect(url_for("messages_center") + "#limpeza")
    if priority not in {"NORMAL", "HIGH"}:
        priority = "NORMAL"

    conn = get_db()
    conn.execute(
        """
        INSERT INTO cleaning_requests (requester_id, title, location, description, priority)
        VALUES (?, ?, ?, ?, ?)
        """,
        (user["id"], title, location or None, description or None, priority),
    )
    conn.commit()
    conn.close()
    flash("Solicitação de limpeza enviada.")
    return redirect(url_for("messages_center") + "#limpeza")


@app.post("/recados/limpeza/<int:request_id>/assumir")
@require_employee_types("CLEANING")
def claim_cleaning_request(request_id):
    conn = get_db()
    row = conn.execute(
        "SELECT * FROM cleaning_requests WHERE id = ?",
        (request_id,),
    ).fetchone()
    if not row:
        conn.close()
        abort(404)
    if row["status"] != "PENDING" or row["assigned_to"] is not None:
        conn.close()
        flash("Essa solicitação já foi assumida.")
        return redirect(url_for("messages_center") + "#limpeza")

    conn.execute(
        """
        UPDATE cleaning_requests
        SET assigned_to = ?, assigned_at = CURRENT_TIMESTAMP, status = 'IN_PROGRESS'
        WHERE id = ?
        """,
        (session["user_id"], request_id),
    )
    conn.commit()
    conn.close()
    flash("Solicitação assumida.")
    return redirect(url_for("messages_center") + "#limpeza")


@app.post("/recados/limpeza/<int:request_id>/concluir")
@require_employee_types("CLEANING")
def complete_cleaning_request(request_id):
    conn = get_db()
    row = conn.execute(
        "SELECT * FROM cleaning_requests WHERE id = ? AND assigned_to = ?",
        (request_id, session["user_id"]),
    ).fetchone()
    if not row:
        conn.close()
        abort(404)

    conn.execute(
        """
        UPDATE cleaning_requests
        SET status = 'COMPLETED', completed_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (request_id,),
    )
    conn.commit()
    conn.close()
    flash("Solicitação concluída.")
    return redirect(url_for("messages_center") + "#limpeza")


@app.post("/recados/limpeza/<int:request_id>/atribuir")
@require_roles("OWNER", "ADMIN")
def assign_cleaning_request(request_id):
    worker_id = request.form.get("worker_id", type=int)
    conn = get_db()
    worker = conn.execute(
        "SELECT id FROM users WHERE id = ? AND employee_type = 'CLEANING' AND active = 1",
        (worker_id,),
    ).fetchone()
    request_row = conn.execute(
        "SELECT id FROM cleaning_requests WHERE id = ?",
        (request_id,),
    ).fetchone()
    if not worker or not request_row:
        conn.close()
        abort(404)

    conn.execute(
        """
        UPDATE cleaning_requests
        SET assigned_to = ?, assigned_at = CURRENT_TIMESTAMP,
            status = CASE WHEN status = 'COMPLETED' THEN status ELSE 'IN_PROGRESS' END
        WHERE id = ?
        """,
        (worker_id, request_id),
    )
    conn.commit()
    conn.close()
    flash("Solicitação atribuída.")
    return redirect(url_for("messages_center") + "#limpeza")


@app.route("/aluno")
@require_roles(
    "STUDENT"
)
def student_dashboard():
    student_id = session["user_id"]

    conn = get_db()

    subscription = conn.execute(
        """
        SELECT
            subscriptions.*,
            plans.name AS plan_name,
            COALESCE(
                (
                    SELECT payments.amount_cents
                    FROM payments
                    WHERE payments.subscription_id = subscriptions.id
                    ORDER BY payments.id
                    LIMIT 1
                ),
                plans.price_cents
            ) AS price_cents
        FROM subscriptions
        JOIN plans ON plans.id = subscriptions.plan_id
        WHERE subscriptions.student_id = ?
        ORDER BY subscriptions.id DESC
        LIMIT 1
        """,
        (student_id,)
    ).fetchone()

    payments = conn.execute(
        """
        SELECT *
        FROM payments
        WHERE student_id = ?
        ORDER BY id DESC
        """,
        (student_id,)
    ).fetchall()

    workout_plan = conn.execute(
        """
        SELECT
            workout_plans.*,
            personal.name AS personal_name
        FROM workout_plans
        JOIN users AS personal ON personal.id = workout_plans.personal_id
        WHERE workout_plans.student_id = ?
          AND workout_plans.status = 'ACTIVE'
        ORDER BY workout_plans.id DESC
        LIMIT 1
        """,
        (student_id,)
    ).fetchone()

    recent_sessions = conn.execute(
        """
        SELECT
            workout_sessions.*,
            workout_days.day_name,
            workout_plans.title
        FROM workout_sessions
        JOIN workout_days ON workout_days.id = workout_sessions.workout_day_id
        JOIN workout_plans ON workout_plans.id = workout_days.workout_plan_id
        WHERE workout_sessions.student_id = ?
        ORDER BY workout_sessions.session_date DESC, workout_sessions.id DESC
        LIMIT 8
        """,
        (student_id,)
    ).fetchall()

    warnings = conn.execute(
        """
        SELECT
            warnings.*,
            users.name AS personal_name
        FROM warnings
        JOIN users ON users.id = warnings.personal_id
        WHERE warnings.student_id = ?
        ORDER BY warnings.id DESC
        """,
        (student_id,)
    ).fetchall()

    conn.close()

    return render_template(
        "aluno/dashboard.html",
        subscription=subscription,
        payments=payments,
        workout_plan=workout_plan,
        recent_sessions=recent_sessions,
        warnings=warnings
    )


@app.route("/aluno/grupos")
@require_roles("STUDENT")
def student_groups():
    student_id = session["user_id"]
    selected_type = request.args.get("tipo", "").strip().upper()
    if selected_type not in GROUP_TYPE_LABELS:
        selected_type = ""

    conn = get_db()

    my_groups = conn.execute(
        """
        SELECT
            groups.*,
            users.name AS admin_name,
            members.member_role,
            (
                SELECT COUNT(*)
                FROM activity_group_members AS all_members
                WHERE all_members.group_id = groups.id
            ) AS member_count
        FROM activity_group_members AS members
        JOIN activity_groups AS groups ON groups.id = members.group_id
        JOIN users ON users.id = groups.created_by
        WHERE members.user_id = ?
          AND groups.active = 1
        ORDER BY
            CASE members.member_role WHEN 'ADMIN' THEN 0 ELSE 1 END,
            groups.created_at DESC,
            groups.id DESC
        """,
        (student_id,)
    ).fetchall()

    params = [student_id]
    type_sql = ""
    if selected_type:
        type_sql = "AND groups.group_type = ?"
        params.append(selected_type)

    discover_groups = conn.execute(
        f"""
        SELECT
            groups.*,
            users.name AS admin_name,
            (
                SELECT COUNT(*)
                FROM activity_group_members AS all_members
                WHERE all_members.group_id = groups.id
            ) AS member_count
        FROM activity_groups AS groups
        JOIN users ON users.id = groups.created_by
        WHERE groups.active = 1
          AND NOT EXISTS (
              SELECT 1
              FROM activity_group_members AS mine
              WHERE mine.group_id = groups.id
                AND mine.user_id = ?
          )
          {type_sql}
        ORDER BY groups.created_at DESC, groups.id DESC
        """,
        tuple(params)
    ).fetchall()

    conn.close()
    return render_template(
        "aluno/grupos.html",
        my_groups=my_groups,
        discover_groups=discover_groups,
        group_type_labels=GROUP_TYPE_LABELS,
        group_type_icons=GROUP_TYPE_ICONS,
        selected_type=selected_type,
    )


@app.post("/aluno/grupos/criar")
@require_roles("STUDENT")
def student_group_create():
    student_id = session["user_id"]
    name = request.form.get("name", "").strip()
    group_type = request.form.get("group_type", "").strip().upper()
    description = request.form.get("description", "").strip()

    if len(name) < 3 or len(name) > 60:
        flash("O nome do grupo deve ter entre 3 e 60 caracteres.")
        return redirect(url_for("student_groups"))

    if group_type not in GROUP_TYPE_LABELS:
        flash("Escolha corrida, natação ou ciclismo.")
        return redirect(url_for("student_groups"))

    if len(description) > 320:
        flash("A descrição pode ter no máximo 320 caracteres.")
        return redirect(url_for("student_groups"))

    conn = get_db()

    if student_group_admin_count(conn, student_id) >= 3:
        conn.close()
        flash("Você já administra 3 grupos ativos. Encerre um deles antes de criar outro.")
        return redirect(url_for("student_groups"))

    if student_group_membership_count(conn, student_id) >= 5:
        conn.close()
        flash("Você já participa de 5 grupos. Saia de um grupo antes de criar outro.")
        return redirect(url_for("student_groups"))

    cursor = conn.execute(
        """
        INSERT INTO activity_groups (name, group_type, description, created_by)
        VALUES (?, ?, ?, ?)
        """,
        (name, group_type, description or None, student_id)
    )
    group_id = cursor.lastrowid
    conn.execute(
        """
        INSERT INTO activity_group_members (group_id, user_id, member_role)
        VALUES (?, ?, 'ADMIN')
        """,
        (group_id, student_id)
    )
    conn.commit()
    conn.close()

    flash("Grupo criado.")
    return redirect(url_for("student_group_detail", group_id=group_id))


@app.route("/aluno/grupos/<int:group_id>")
@require_roles("STUDENT")
def student_group_detail(group_id):
    student_id = session["user_id"]
    conn = get_db()

    group = conn.execute(
        """
        SELECT
            groups.*,
            users.name AS admin_name,
            users.profile_image_filename AS admin_image,
            (
                SELECT COUNT(*)
                FROM activity_group_members AS all_members
                WHERE all_members.group_id = groups.id
            ) AS member_count
        FROM activity_groups AS groups
        JOIN users ON users.id = groups.created_by
        WHERE groups.id = ?
          AND groups.active = 1
        """,
        (group_id,)
    ).fetchone()

    if not group:
        conn.close()
        abort(404)

    membership = student_group_membership(conn, group_id, student_id)

    members = conn.execute(
        """
        SELECT
            users.id,
            users.name,
            users.prontuario,
            users.profile_image_filename,
            members.member_role,
            members.joined_at
        FROM activity_group_members AS members
        JOIN users ON users.id = members.user_id
        WHERE members.group_id = ?
        ORDER BY
            CASE members.member_role WHEN 'ADMIN' THEN 0 ELSE 1 END,
            users.name COLLATE NOCASE,
            users.id
        """,
        (group_id,)
    ).fetchall()

    week_start, week_end = weekly_group_window()
    ranking_rows = conn.execute(
        """
        SELECT
            users.id,
            users.name,
            users.profile_image_filename,
            COUNT(activities.id) AS activity_count,
            SUM(activities.distance_km) AS total_distance_km,
            SUM(activities.duration_minutes) AS total_duration_minutes
        FROM activity_group_members AS members
        JOIN users ON users.id = members.user_id
        JOIN activity_group_activities AS activities
          ON activities.group_id = members.group_id
         AND activities.user_id = members.user_id
         AND activities.activity_date BETWEEN ? AND ?
        WHERE members.group_id = ?
        GROUP BY users.id, users.name, users.profile_image_filename
        HAVING SUM(activities.distance_km) > 0
        ORDER BY
            total_distance_km DESC,
            total_duration_minutes ASC,
            activity_count DESC,
            users.name COLLATE NOCASE
        """,
        (week_start.isoformat(), week_end.isoformat(), group_id)
    ).fetchall()

    ranking = []
    medal_labels = {1: "Ouro", 2: "Prata", 3: "Bronze"}
    medal_classes = {1: "gold", 2: "silver", 3: "bronze"}
    for position, row in enumerate(ranking_rows, start=1):
        item = dict(row)
        item["position"] = position
        item["medal_label"] = medal_labels.get(position)
        item["medal_class"] = medal_classes.get(position)
        ranking.append(item)

    activities = conn.execute(
        """
        SELECT
            activities.*,
            users.name AS student_name,
            users.profile_image_filename
        FROM activity_group_activities AS activities
        JOIN users ON users.id = activities.user_id
        WHERE activities.group_id = ?
        ORDER BY activities.activity_date DESC, activities.id DESC
        LIMIT 18
        """,
        (group_id,)
    ).fetchall()

    messages = []
    if membership:
        message_rows = conn.execute(
            """
            SELECT
                messages.*,
                users.name AS sender_name,
                users.profile_image_filename
            FROM activity_group_messages AS messages
            JOIN users ON users.id = messages.sender_id
            WHERE messages.group_id = ?
            ORDER BY messages.id DESC
            LIMIT 80
            """,
            (group_id,)
        ).fetchall()
        messages = list(reversed(message_rows))

    conn.close()
    return render_template(
        "aluno/grupo_detalhe.html",
        group=group,
        membership=membership,
        members=members,
        ranking=ranking,
        activities=activities,
        messages=messages,
        group_type_label=GROUP_TYPE_LABELS[group["group_type"]],
        group_type_icon=GROUP_TYPE_ICONS[group["group_type"]],
        week_start=week_start,
        week_end=week_end,
        today=date.today(),
    )


@app.post("/aluno/grupos/<int:group_id>/entrar")
@require_roles("STUDENT")
def student_group_join(group_id):
    student_id = session["user_id"]
    conn = get_db()

    group = conn.execute(
        "SELECT id FROM activity_groups WHERE id = ? AND active = 1",
        (group_id,)
    ).fetchone()
    if not group:
        conn.close()
        abort(404)

    if student_group_membership(conn, group_id, student_id):
        conn.close()
        return redirect(url_for("student_group_detail", group_id=group_id))

    if student_group_membership_count(conn, student_id) >= 5:
        conn.close()
        flash("Você já participa de 5 grupos. Saia de um grupo antes de entrar em outro.")
        return redirect(url_for("student_groups"))

    conn.execute(
        """
        INSERT INTO activity_group_members (group_id, user_id, member_role)
        VALUES (?, ?, 'MEMBER')
        """,
        (group_id, student_id)
    )
    conn.commit()
    conn.close()

    flash("Você entrou no grupo.")
    return redirect(url_for("student_group_detail", group_id=group_id))


@app.post("/aluno/grupos/<int:group_id>/sair")
@require_roles("STUDENT")
def student_group_leave(group_id):
    student_id = session["user_id"]
    conn = get_db()

    group = conn.execute(
        "SELECT id, created_by FROM activity_groups WHERE id = ? AND active = 1",
        (group_id,)
    ).fetchone()
    if not group:
        conn.close()
        abort(404)

    if int(group["created_by"]) == int(student_id):
        conn.close()
        flash("Como administrador, encerre o grupo para deixar de operá-lo.")
        return redirect(url_for("student_group_detail", group_id=group_id))

    conn.execute(
        "DELETE FROM activity_group_members WHERE group_id = ? AND user_id = ?",
        (group_id, student_id)
    )
    conn.commit()
    conn.close()

    flash("Você saiu do grupo.")
    return redirect(url_for("student_groups"))


@app.post("/aluno/grupos/<int:group_id>/encerrar")
@require_roles("STUDENT")
def student_group_close(group_id):
    student_id = session["user_id"]
    conn = get_db()

    group = conn.execute(
        """
        SELECT id
        FROM activity_groups
        WHERE id = ?
          AND created_by = ?
          AND active = 1
        """,
        (group_id, student_id)
    ).fetchone()
    if not group:
        conn.close()
        abort(404)

    conn.execute(
        "UPDATE activity_groups SET active = 0 WHERE id = ?",
        (group_id,)
    )
    conn.commit()
    conn.close()

    flash("Grupo encerrado. O histórico foi preservado no banco.")
    return redirect(url_for("student_groups"))


@app.post("/aluno/grupos/<int:group_id>/atividade")
@require_roles("STUDENT")
def student_group_activity(group_id):
    student_id = session["user_id"]
    conn = get_db()

    group = conn.execute(
        "SELECT id, group_type FROM activity_groups WHERE id = ? AND active = 1",
        (group_id,)
    ).fetchone()
    membership = student_group_membership(conn, group_id, student_id) if group else None
    if not group or not membership:
        conn.close()
        abort(403 if group else 404)

    activity_date_raw = request.form.get("activity_date", "").strip()
    try:
        activity_date = date.fromisoformat(activity_date_raw)
    except ValueError:
        conn.close()
        flash("Informe uma data válida para a atividade.")
        return redirect(url_for("student_group_detail", group_id=group_id))

    if activity_date > date.today():
        conn.close()
        flash("A atividade não pode ser registrada em uma data futura.")
        return redirect(url_for("student_group_detail", group_id=group_id))

    distance = parse_positive_decimal(request.form.get("distance"))
    if distance is None:
        conn.close()
        flash("Informe uma distância maior que zero.")
        return redirect(url_for("student_group_detail", group_id=group_id))

    if group["group_type"] == "SWIMMING":
        distance_km = distance / Decimal("1000")
    else:
        distance_km = distance

    try:
        duration_minutes = int(request.form.get("duration_minutes", "0"))
    except ValueError:
        duration_minutes = 0
    if duration_minutes <= 0 or duration_minutes > 24 * 60:
        conn.close()
        flash("Informe o tempo da atividade em minutos.")
        return redirect(url_for("student_group_detail", group_id=group_id))

    notes = request.form.get("notes", "").strip()
    if len(notes) > 220:
        conn.close()
        flash("A observação pode ter no máximo 220 caracteres.")
        return redirect(url_for("student_group_detail", group_id=group_id))

    conn.execute(
        """
        INSERT INTO activity_group_activities (
            group_id, user_id, activity_date, distance_km, duration_minutes, notes
        )
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (
            group_id,
            student_id,
            activity_date.isoformat(),
            float(distance_km),
            duration_minutes,
            notes or None,
        )
    )
    conn.commit()
    conn.close()

    flash("Atividade registrada. A classificação da semana já foi atualizada.")
    return redirect(url_for("student_group_detail", group_id=group_id) + "#classificacao")


@app.post("/aluno/grupos/<int:group_id>/mensagem")
@require_roles("STUDENT")
def student_group_message(group_id):
    student_id = session["user_id"]
    message = request.form.get("message", "").strip()

    if not message:
        flash("Escreva uma mensagem antes de enviar.")
        return redirect(url_for("student_group_detail", group_id=group_id) + "#chat")

    if len(message) > 600:
        flash("A mensagem pode ter no máximo 600 caracteres.")
        return redirect(url_for("student_group_detail", group_id=group_id) + "#chat")

    conn = get_db()
    group = conn.execute(
        "SELECT id FROM activity_groups WHERE id = ? AND active = 1",
        (group_id,)
    ).fetchone()
    membership = student_group_membership(conn, group_id, student_id) if group else None
    if not group or not membership:
        conn.close()
        abort(403 if group else 404)

    conn.execute(
        """
        INSERT INTO activity_group_messages (group_id, sender_id, message)
        VALUES (?, ?, ?)
        """,
        (group_id, student_id, message)
    )
    conn.commit()
    conn.close()

    return redirect(url_for("student_group_detail", group_id=group_id) + "#chat")


@app.post(
    "/aluno/pagamento/<int:payment_id>/pagar"
)
@require_roles(
    "STUDENT"
)
def student_pay(payment_id):
    conn = get_db()

    payment = conn.execute(
        """
        SELECT *
        FROM payments
        WHERE id = ?
        AND student_id = ?
        """,
        (
            payment_id,
            session["user_id"]
        )
    ).fetchone()

    if not payment:
        conn.close()
        abort(404)

    if payment["status"] == "PAID":
        conn.close()

        flash(
            "Esse pagamento já foi realizado."
        )

        return redirect(
            url_for("student_dashboard")
        )

    conn.execute(
        """
        UPDATE payments
        SET
            status = 'PAID',
            paid_at = CURRENT_TIMESTAMP,
            payment_method =
            'SIMULATED_DIGITAL',
            payment_origin =
            'STUDENT'
        WHERE id = ?
        """,
        (payment_id,)
    )

    conn.commit()
    conn.close()

    flash(
        "Pagamento simulado aprovado."
    )

    return redirect(
        url_for("student_dashboard")
    )


@app.route("/aluno/ficha/<int:plan_id>")
@require_roles("STUDENT")
def student_workout_plan(plan_id):
    student_id = session["user_id"]
    conn = get_db()

    plan = conn.execute(
        """
        SELECT workout_plans.*, personal.name AS personal_name
        FROM workout_plans
        JOIN users AS personal ON personal.id = workout_plans.personal_id
        WHERE workout_plans.id = ?
          AND workout_plans.student_id = ?
        """,
        (plan_id, student_id)
    ).fetchone()

    if not plan:
        conn.close()
        abort(404)

    days = conn.execute(
        """
        SELECT *
        FROM workout_days
        WHERE workout_plan_id = ?
        ORDER BY position, id
        """,
        (plan_id,)
    ).fetchall()

    day_cards = []
    for day in days:
        items = conn.execute(
            """
            SELECT
                workout_items.*,
                exercises.name AS exercise_name,
                exercises.muscle_group,
                exercises.image_filename,
                exercises.instructions
            FROM workout_items
            JOIN exercises ON exercises.id = workout_items.exercise_id
            WHERE workout_items.workout_day_id = ?
            ORDER BY workout_items.position, workout_items.id
            """,
            (day["id"],)
        ).fetchall()

        last_session = conn.execute(
            """
            SELECT *
            FROM workout_sessions
            WHERE workout_day_id = ?
              AND student_id = ?
            ORDER BY session_date DESC, id DESC
            LIMIT 1
            """,
            (day["id"], student_id)
        ).fetchone()

        day_cards.append({
            "day": day,
            "items": items,
            "last_session": last_session,
        })

    conn.close()

    return render_template(
        "aluno/ficha_treino.html",
        plan=plan,
        day_cards=day_cards
    )


@app.route("/aluno/ficha/<int:plan_id>/dia/<int:day_id>")
@require_roles("STUDENT")
def student_workout_day(plan_id, day_id):
    student_id = session["user_id"]
    today = date.today().isoformat()
    conn = get_db()

    day = conn.execute(
        """
        SELECT
            workout_days.*,
            workout_plans.title,
            workout_plans.student_id,
            workout_plans.status AS plan_status
        FROM workout_days
        JOIN workout_plans ON workout_plans.id = workout_days.workout_plan_id
        WHERE workout_days.id = ?
          AND workout_plans.id = ?
          AND workout_plans.student_id = ?
        """,
        (day_id, plan_id, student_id)
    ).fetchone()

    if not day:
        conn.close()
        abort(404)

    conn.execute(
        """
        INSERT OR IGNORE INTO workout_sessions (
            workout_day_id, student_id, session_date
        )
        VALUES (?, ?, ?)
        """,
        (day_id, student_id, today)
    )

    workout_session = conn.execute(
        """
        SELECT *
        FROM workout_sessions
        WHERE workout_day_id = ?
          AND student_id = ?
          AND session_date = ?
        """,
        (day_id, student_id, today)
    ).fetchone()

    items = conn.execute(
        """
        SELECT
            workout_items.*,
            exercises.name AS exercise_name,
            exercises.muscle_group,
            exercises.image_filename,
            exercises.instructions
        FROM workout_items
        JOIN exercises ON exercises.id = workout_items.exercise_id
        WHERE workout_items.workout_day_id = ?
        ORDER BY workout_items.position, workout_items.id
        """,
        (day_id,)
    ).fetchall()

    for item in items:
        conn.execute(
            """
            INSERT OR IGNORE INTO workout_item_logs (
                session_id, workout_item_id, status
            )
            VALUES (?, ?, 'PENDING')
            """,
            (workout_session["id"], item["id"])
        )

    conn.commit()

    item_rows = conn.execute(
        """
        SELECT
            workout_items.*,
            exercises.name AS exercise_name,
            exercises.muscle_group,
            exercises.image_filename,
            exercises.instructions,
            workout_item_logs.status AS log_status,
            workout_item_logs.completed_at
        FROM workout_items
        JOIN exercises ON exercises.id = workout_items.exercise_id
        JOIN workout_item_logs
            ON workout_item_logs.workout_item_id = workout_items.id
           AND workout_item_logs.session_id = ?
        WHERE workout_items.workout_day_id = ?
        ORDER BY workout_items.position, workout_items.id
        """,
        (workout_session["id"], day_id)
    ).fetchall()

    conn.close()

    return render_template(
        "aluno/treino_dia.html",
        day=day,
        workout_session=workout_session,
        items=item_rows,
        plan_id=plan_id
    )


@app.post("/aluno/treino/sessao/<int:session_id>/item/<int:item_id>")
@require_roles("STUDENT")
def mark_workout_item(session_id, item_id):
    status = request.form.get("status", "").strip().upper()
    if status not in {"PENDING", "DONE", "SKIPPED"}:
        abort(400)

    conn = get_db()
    row = conn.execute(
        """
        SELECT
            workout_sessions.id AS session_id,
            workout_sessions.student_id,
            workout_days.workout_plan_id,
            workout_items.id AS item_id
        FROM workout_sessions
        JOIN workout_days ON workout_days.id = workout_sessions.workout_day_id
        JOIN workout_items ON workout_items.workout_day_id = workout_days.id
        WHERE workout_sessions.id = ?
          AND workout_items.id = ?
          AND workout_sessions.student_id = ?
        """,
        (session_id, item_id, session["user_id"])
    ).fetchone()

    if not row:
        conn.close()
        abort(404)

    conn.execute(
        """
        UPDATE workout_item_logs
        SET status = ?,
            completed_at = CASE
                WHEN ? = 'PENDING' THEN NULL
                ELSE CURRENT_TIMESTAMP
            END
        WHERE session_id = ?
          AND workout_item_id = ?
        """,
        (status, status, session_id, item_id)
    )
    conn.commit()
    conn.close()

    return redirect(request.referrer or url_for(
        "student_workout_plan",
        plan_id=row["workout_plan_id"]
    ))


@app.post("/aluno/treino/sessao/<int:session_id>/finalizar")
@require_roles("STUDENT")
def finish_workout_session(session_id):
    conn = get_db()
    workout_session = conn.execute(
        """
        SELECT workout_sessions.*, workout_days.workout_plan_id
        FROM workout_sessions
        JOIN workout_days ON workout_days.id = workout_sessions.workout_day_id
        WHERE workout_sessions.id = ?
          AND workout_sessions.student_id = ?
        """,
        (session_id, session["user_id"])
    ).fetchone()

    if not workout_session:
        conn.close()
        abort(404)

    pending = conn.execute(
        """
        SELECT COUNT(*) AS total
        FROM workout_item_logs
        WHERE session_id = ?
          AND status = 'PENDING'
        """,
        (session_id,)
    ).fetchone()["total"]

    if pending:
        conn.close()
        flash("Marque todos os exercícios como Feito ou Não fiz antes de finalizar.")
        return redirect(request.referrer or url_for(
            "student_workout_plan",
            plan_id=workout_session["workout_plan_id"]
        ))

    conn.execute(
        """
        UPDATE workout_sessions
        SET status = 'COMPLETED',
            finished_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (session_id,)
    )
    conn.commit()
    conn.close()

    flash("Treino finalizado e salvo no seu histórico.")
    return redirect(url_for(
        "student_workout_plan",
        plan_id=workout_session["workout_plan_id"]
    ))


@app.route("/personal")
@require_employee_types(
    "PERSONAL"
)
def personal_dashboard():
    personal_id = session["user_id"]

    conn = get_db()

    students = conn.execute(
        """
        SELECT
            users.*,
            active_plan.id AS workout_plan_id,
            active_plan.title AS workout_title,
            active_plan.assigned_at AS workout_assigned_at,
            plan_personal.name AS workout_personal_name
        FROM users
        JOIN roles ON roles.id = users.role_id
        LEFT JOIN workout_plans AS active_plan
            ON active_plan.id = (
                SELECT wp.id
                FROM workout_plans AS wp
                WHERE wp.student_id = users.id
                  AND wp.status = 'ACTIVE'
                ORDER BY wp.id DESC
                LIMIT 1
            )
        LEFT JOIN users AS plan_personal
            ON plan_personal.id = active_plan.personal_id
        WHERE roles.code = 'STUDENT'
          AND users.active = 1
        ORDER BY users.name
        """
    ).fetchall()

    schedule = conn.execute(
        """
        SELECT *
        FROM work_schedules
        WHERE employee_id = ?
        ORDER BY work_date
        """,
        (personal_id,)
    ).fetchall()

    conn.close()

    return render_template(
        "personal/dashboard.html",
        students=students,
        schedule=schedule
    )


@app.route("/personal/exercicios")
@require_employee_types("PERSONAL")
def exercise_catalog():
    conn = get_db()

    active_exercises = conn.execute(
        """
        SELECT
            exercises.*,
            creator.name AS creator_name
        FROM exercises
        LEFT JOIN users AS creator ON creator.id = exercises.created_by
        WHERE exercises.active = 1
        ORDER BY exercises.muscle_group, exercises.name
        """
    ).fetchall()

    deleted_exercises = conn.execute(
        """
        SELECT
            exercises.*,
            creator.name AS creator_name,
            deleter.name AS deleted_by_name
        FROM exercises
        LEFT JOIN users AS creator ON creator.id = exercises.created_by
        LEFT JOIN users AS deleter ON deleter.id = exercises.deleted_by
        WHERE exercises.active = 0
        ORDER BY exercises.deleted_at DESC, exercises.name
        """
    ).fetchall()

    audit_log = conn.execute(
        """
        SELECT
            exercise_audit_log.*,
            exercises.name AS exercise_name,
            users.name AS actor_name
        FROM exercise_audit_log
        JOIN exercises ON exercises.id = exercise_audit_log.exercise_id
        LEFT JOIN users ON users.id = exercise_audit_log.performed_by
        ORDER BY exercise_audit_log.id DESC
        LIMIT 100
        """
    ).fetchall()

    conn.close()
    return render_template(
        "personal/exercicios.html",
        active_exercises=active_exercises,
        deleted_exercises=deleted_exercises,
        audit_log=audit_log
    )


@app.post("/personal/exercicios/novo")
@require_employee_types("PERSONAL")
def create_exercise():
    name = request.form.get("name", "").strip()
    muscle_group = request.form.get("muscle_group", "").strip()
    instructions = request.form.get("instructions", "").strip()
    image_file = request.files.get("image")

    if not name or not muscle_group:
        flash("Informe o nome e o grupo muscular do exercício.")
        return redirect(url_for("exercise_catalog"))

    conn = get_db()
    existing = conn.execute(
        "SELECT id, active FROM exercises WHERE LOWER(name) = LOWER(?)",
        (name,)
    ).fetchone()

    if existing:
        conn.close()
        if existing["active"]:
            flash("Já existe um exercício ativo com esse nome.")
        else:
            flash("Já existe um exercício excluído com esse nome. Restaure-o ou use outro nome.")
        return redirect(url_for("exercise_catalog"))

    image_filename, image_error = save_exercise_image(image_file)
    if image_error:
        conn.close()
        flash(image_error)
        return redirect(url_for("exercise_catalog"))

    cursor = conn.execute(
        """
        INSERT INTO exercises (
            name, muscle_group, image_filename, instructions, created_by
        )
        VALUES (?, ?, ?, ?, ?)
        """,
        (name, muscle_group, image_filename, instructions or None, session["user_id"])
    )
    exercise_id = cursor.lastrowid
    log_exercise_action(conn, exercise_id, "CREATED", session["user_id"], "Exercício criado no catálogo.")
    conn.commit()
    conn.close()

    flash("Exercício criado e disponibilizado no catálogo.")
    return redirect(url_for("exercise_catalog"))


@app.post("/personal/exercicios/<int:exercise_id>/editar")
@require_employee_types("PERSONAL")
def edit_exercise(exercise_id):
    name = request.form.get("name", "").strip()
    muscle_group = request.form.get("muscle_group", "").strip()
    instructions = request.form.get("instructions", "").strip()
    image_file = request.files.get("image")

    if not name or not muscle_group:
        flash("Informe o nome e o grupo muscular do exercício.")
        return redirect(url_for("exercise_catalog"))

    conn = get_db()
    exercise = conn.execute("SELECT * FROM exercises WHERE id = ? AND active = 1", (exercise_id,)).fetchone()
    if not exercise:
        conn.close()
        abort(404)

    duplicate = conn.execute(
        "SELECT id FROM exercises WHERE LOWER(name) = LOWER(?) AND id != ?",
        (name, exercise_id)
    ).fetchone()
    if duplicate:
        conn.close()
        flash("Já existe outro exercício com esse nome.")
        return redirect(url_for("exercise_catalog"))

    image_filename = exercise["image_filename"]
    if image_file and image_file.filename:
        image_filename, image_error = save_exercise_image(image_file)
        if image_error:
            conn.close()
            flash(image_error)
            return redirect(url_for("exercise_catalog"))

    conn.execute(
        """
        UPDATE exercises
        SET name = ?, muscle_group = ?, instructions = ?, image_filename = ?,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (name, muscle_group, instructions or None, image_filename, exercise_id)
    )
    log_exercise_action(conn, exercise_id, "UPDATED", session["user_id"], "Dados do exercício atualizados.")
    conn.commit()
    conn.close()

    flash("Exercício atualizado.")
    return redirect(url_for("exercise_catalog"))


@app.post("/personal/exercicios/<int:exercise_id>/excluir")
@require_employee_types("PERSONAL")
def delete_exercise(exercise_id):
    reason = request.form.get("reason", "").strip()
    conn = get_db()
    exercise = conn.execute("SELECT * FROM exercises WHERE id = ? AND active = 1", (exercise_id,)).fetchone()
    if not exercise:
        conn.close()
        abort(404)

    conn.execute(
        """
        UPDATE exercises
        SET active = 0, deleted_at = CURRENT_TIMESTAMP, deleted_by = ?,
            deletion_reason = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (session["user_id"], reason or None, exercise_id)
    )
    log_exercise_action(conn, exercise_id, "DELETED", session["user_id"], reason or "Exercício excluído do catálogo ativo.")
    conn.commit()
    conn.close()

    flash("Exercício excluído do catálogo ativo. O histórico foi preservado.")
    return redirect(url_for("exercise_catalog"))


@app.post("/personal/exercicios/<int:exercise_id>/restaurar")
@require_employee_types("PERSONAL")
def restore_exercise(exercise_id):
    conn = get_db()
    exercise = conn.execute("SELECT * FROM exercises WHERE id = ? AND active = 0", (exercise_id,)).fetchone()
    if not exercise:
        conn.close()
        abort(404)

    conn.execute(
        """
        UPDATE exercises
        SET active = 1, deleted_at = NULL, deleted_by = NULL, deletion_reason = NULL,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (exercise_id,)
    )
    log_exercise_action(conn, exercise_id, "RESTORED", session["user_id"], "Exercício restaurado ao catálogo ativo.")
    conn.commit()
    conn.close()

    flash("Exercício restaurado.")
    return redirect(url_for("exercise_catalog"))


@app.route("/personal/ficha/nova/<int:student_id>", methods=["GET", "POST"])
@require_employee_types("PERSONAL")
def create_workout_plan(student_id):
    conn = get_db()
    student = conn.execute(
        """
        SELECT users.*
        FROM users
        JOIN roles ON roles.id = users.role_id
        WHERE users.id = ?
          AND roles.code = 'STUDENT'
          AND users.active = 1
        """,
        (student_id,)
    ).fetchone()

    if not student:
        conn.close()
        abort(404)

    exercises = conn.execute(
        """
        SELECT *
        FROM exercises
        WHERE active = 1
        ORDER BY muscle_group, name
        """
    ).fetchall()

    if request.method == "GET":
        conn.close()
        return render_template(
            "personal/montar_ficha.html",
            student=student,
            exercises=exercises
        )

    title = request.form.get("title", "").strip()
    objective = request.form.get("objective", "").strip()
    plan_notes = request.form.get("plan_notes", "").strip()

    day_names = request.form.getlist("day_name")
    exercise_ids = request.form.getlist("exercise_id")
    sets_values = request.form.getlist("sets")
    reps_values = request.form.getlist("reps")
    load_values = request.form.getlist("load_text")
    rest_values = request.form.getlist("rest_seconds")
    notes_values = request.form.getlist("item_notes")

    if not title:
        conn.close()
        flash("Dê um nome para a ficha de treino.")
        return redirect(url_for("create_workout_plan", student_id=student_id))

    exercise_map = {row["id"]: row for row in exercises}
    rows = []
    total = max(
        len(day_names), len(exercise_ids), len(sets_values), len(reps_values),
        len(load_values), len(rest_values), len(notes_values), 0
    )

    for index in range(total):
        day_name = day_names[index].strip() if index < len(day_names) else ""
        exercise_raw = exercise_ids[index].strip() if index < len(exercise_ids) else ""
        if not day_name or not exercise_raw:
            continue

        try:
            exercise_id = int(exercise_raw)
        except ValueError:
            continue

        if exercise_id not in exercise_map:
            conn.close()
            flash("Um dos exercícios selecionados não existe mais no catálogo.")
            return redirect(url_for("create_workout_plan", student_id=student_id))

        sets_raw = sets_values[index].strip() if index < len(sets_values) else ""
        rest_raw = rest_values[index].strip() if index < len(rest_values) else ""

        try:
            sets = int(sets_raw) if sets_raw else None
            rest_seconds = int(rest_raw) if rest_raw else None
        except ValueError:
            conn.close()
            flash("Séries e descanso precisam ser números válidos.")
            return redirect(url_for("create_workout_plan", student_id=student_id))

        if sets is not None and sets <= 0:
            conn.close()
            flash("A quantidade de séries precisa ser maior que zero.")
            return redirect(url_for("create_workout_plan", student_id=student_id))

        if rest_seconds is not None and rest_seconds < 0:
            conn.close()
            flash("O descanso não pode ser negativo.")
            return redirect(url_for("create_workout_plan", student_id=student_id))

        rows.append({
            "day_name": day_name[:60],
            "exercise_id": exercise_id,
            "sets": sets,
            "reps": (reps_values[index].strip() if index < len(reps_values) else "")[:50] or None,
            "load_text": (load_values[index].strip() if index < len(load_values) else "")[:50] or None,
            "rest_seconds": rest_seconds,
            "notes": (notes_values[index].strip() if index < len(notes_values) else "")[:300] or None,
        })

    if not rows:
        conn.close()
        flash("Adicione pelo menos um exercício à ficha.")
        return redirect(url_for("create_workout_plan", student_id=student_id))

    try:
        # A ficha anterior não é apagada: vira histórico.
        conn.execute(
            """
            UPDATE workout_plans
            SET status = 'ARCHIVED'
            WHERE student_id = ?
              AND status = 'ACTIVE'
            """,
            (student_id,)
        )

        plan_cursor = conn.execute(
            """
            INSERT INTO workout_plans (
                student_id, personal_id, title, objective, notes, status
            )
            VALUES (?, ?, ?, ?, ?, 'ACTIVE')
            """,
            (
                student_id,
                session["user_id"],
                title,
                objective or None,
                plan_notes or None
            )
        )
        plan_id = plan_cursor.lastrowid

        day_ids = {}
        day_positions = {}
        item_positions = {}

        for row in rows:
            day_name = row["day_name"]
            if day_name not in day_ids:
                day_position = len(day_ids) + 1
                cursor = conn.execute(
                    """
                    INSERT INTO workout_days (workout_plan_id, day_name, position)
                    VALUES (?, ?, ?)
                    """,
                    (plan_id, day_name, day_position)
                )
                day_ids[day_name] = cursor.lastrowid
                day_positions[day_name] = day_position
                item_positions[day_name] = 0

            item_positions[day_name] += 1
            conn.execute(
                """
                INSERT INTO workout_items (
                    workout_day_id, exercise_id, sets, reps, load_text,
                    rest_seconds, notes, position
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    day_ids[day_name],
                    row["exercise_id"],
                    row["sets"],
                    row["reps"],
                    row["load_text"],
                    row["rest_seconds"],
                    row["notes"],
                    item_positions[day_name]
                )
            )

        conn.commit()
        conn.close()
        flash(f"Ficha '{title}' enviada para {student['name']}.")
        return redirect(url_for("personal_dashboard"))

    except Exception as error:
        conn.rollback()
        conn.close()
        flash(f"Não foi possível salvar a ficha: {error}")
        return redirect(url_for("create_workout_plan", student_id=student_id))


@app.post(
    "/personal/advertencia/<int:student_id>"
)
@require_employee_types(
    "PERSONAL"
)
def warning(student_id):
    message = request.form.get(
        "message",
        ""
    ).strip()

    if not message:
        flash("Digite a advertência.")

        return redirect(
            url_for("personal_dashboard")
        )

    conn = get_db()

    student = conn.execute(
        """
        SELECT users.id
        FROM users
        JOIN roles
            ON roles.id = users.role_id
        WHERE users.id = ?
        AND roles.code = 'STUDENT'
        AND users.active = 1
        """,
        (student_id,)
    ).fetchone()

    if not student:
        conn.close()
        abort(404)

    conn.execute(
        """
        INSERT INTO warnings (
            student_id,
            personal_id,
            message
        )
        VALUES (?, ?, ?)
        """,
        (
            student_id,
            session["user_id"],
            message
        )
    )

    conn.commit()
    conn.close()

    flash("Advertência enviada.")

    return redirect(
        url_for("personal_dashboard")
    )


@app.route("/limpeza")
@require_employee_types(
    "CLEANING"
)
def cleaning_dashboard():
    employee_id = session["user_id"]

    conn = get_db()

    tasks = conn.execute(
        """
        SELECT *
        FROM cleaning_tasks
        WHERE assigned_to = ?
        ORDER BY id DESC
        """,
        (employee_id,)
    ).fetchall()

    schedule = conn.execute(
        """
        SELECT *
        FROM work_schedules
        WHERE employee_id = ?
        ORDER BY work_date
        """,
        (employee_id,)
    ).fetchall()

    conn.close()

    return render_template(
        "limpeza/dashboard.html",
        tasks=tasks,
        schedule=schedule
    )


@app.post(
    "/limpeza/tarefa/<int:task_id>/concluir"
)
@require_employee_types(
    "CLEANING"
)
def complete_task(task_id):
    conn = get_db()

    task = conn.execute(
        """
        SELECT *
        FROM cleaning_tasks
        WHERE id = ?
        AND assigned_to = ?
        """,
        (
            task_id,
            session["user_id"]
        )
    ).fetchone()

    if not task:
        conn.close()
        abort(404)

    conn.execute(
        """
        UPDATE cleaning_tasks
        SET
            status = 'COMPLETED',
            completed_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (task_id,)
    )

    conn.commit()
    conn.close()

    flash("Tarefa concluída.")

    return redirect(
        url_for("cleaning_dashboard")
    )


@app.route("/seguranca")
@require_employee_types(
    "SECURITY"
)
def security_dashboard():
    security_id = session["user_id"]

    conn = get_db()

    reports_list = conn.execute(
        """
        SELECT
            security_reports.*,
            GROUP_CONCAT(involved.name, ', ') AS involved_names
        FROM security_reports
        LEFT JOIN security_report_involved
            ON security_report_involved.report_id = security_reports.id
        LEFT JOIN users AS involved
            ON involved.id = security_report_involved.user_id
        WHERE security_reports.security_id = ?
        GROUP BY security_reports.id
        ORDER BY security_reports.id DESC
        """,
        (security_id,)
    ).fetchall()

    people = conn.execute(
        """
        SELECT
            users.id,
            users.name,
            users.prontuario,
            users.employee_type,
            roles.code AS role_code,
            roles.name AS role_name
        FROM users
        JOIN roles
            ON roles.id = users.role_id
        WHERE users.active = 1
        AND roles.code IN (
            'OWNER',
            'ADMIN',
            'EMPLOYEE',
            'STUDENT'
        )
        ORDER BY
            CASE roles.code
                WHEN 'STUDENT' THEN 1
                ELSE 0
            END,
            users.name
        """
    ).fetchall()

    schedule = conn.execute(
        """
        SELECT *
        FROM work_schedules
        WHERE employee_id = ?
        ORDER BY work_date
        """,
        (security_id,)
    ).fetchall()

    conn.close()

    return render_template(
        "seguranca/dashboard.html",
        reports=reports_list,
        people=people,
        schedule=schedule
    )


@app.post(
    "/seguranca/ocorrencia"
)
@require_employee_types(
    "SECURITY"
)
def security_report():
    subject = request.form.get(
        "subject",
        ""
    ).strip()

    description = request.form.get(
        "description",
        ""
    ).strip()

    severity = request.form.get(
        "severity"
    )

    raw_involved_ids = request.form.getlist(
        "involved_user_ids"
    )

    if severity not in {
        "LOW",
        "MEDIUM",
        "HIGH",
        "CRITICAL"
    }:
        flash("Gravidade inválida.")

        return redirect(
            url_for("security_dashboard")
        )

    if not subject:
        flash(
            "Digite o assunto da ocorrência."
        )

        return redirect(
            url_for("security_dashboard")
        )

    if not description:
        flash(
            "Digite a descrição da ocorrência."
        )

        return redirect(
            url_for("security_dashboard")
        )

    involved_ids = []

    for raw_id in raw_involved_ids:
        try:
            involved_ids.append(int(raw_id))
        except (TypeError, ValueError):
            continue

    involved_ids = list(dict.fromkeys(involved_ids))

    conn = get_db()

    valid_involved = []

    if involved_ids:
        placeholders = ",".join(
            "?" for _ in involved_ids
        )

        valid_rows = conn.execute(
            f"""
            SELECT users.id
            FROM users
            JOIN roles
                ON roles.id = users.role_id
            WHERE users.id IN ({placeholders})
            AND users.active = 1
            AND roles.code IN (
                'OWNER',
                'ADMIN',
                'EMPLOYEE',
                'STUDENT'
            )
            """,
            involved_ids
        ).fetchall()

        valid_involved = [
            row["id"] for row in valid_rows
        ]

    cursor = conn.execute(
        """
        INSERT INTO security_reports (
            security_id,
            subject,
            description,
            severity
        )
        VALUES (?, ?, ?, ?)
        """,
        (
            session["user_id"],
            subject,
            description,
            severity
        )
    )

    report_id = cursor.lastrowid

    for involved_id in valid_involved:
        conn.execute(
            """
            INSERT OR IGNORE INTO security_report_involved (
                report_id,
                user_id
            )
            VALUES (?, ?)
            """,
            (
                report_id,
                involved_id
            )
        )

    conn.commit()
    conn.close()

    if valid_involved:
        flash(
            f"Ocorrência registrada com {len(valid_involved)} pessoa(s) envolvida(s)."
        )
    else:
        flash("Ocorrência registrada.")

    return redirect(
        url_for("security_dashboard")
    )


@app.route("/meu-rh")
@login_required
def employee_hr():
    user = current_user()

    if user["role_code"] == "STUDENT":
        abort(403)

    conn = get_db()

    profile = conn.execute(
        "SELECT * FROM employee_profiles WHERE user_id = ?",
        (user["id"],)
    ).fetchone()

    today = date.today()
    month_prefix = today.strftime("%Y-%m")

    schedules = conn.execute(
        """
        SELECT *
        FROM work_schedules
        WHERE employee_id = ?
        AND work_date >= ?
        ORDER BY work_date
        LIMIT 45
        """,
        (user["id"], today.isoformat())
    ).fetchall()

    time_entries = conn.execute(
        """
        SELECT *
        FROM time_entries
        WHERE employee_id = ?
        AND work_date LIKE ?
        ORDER BY work_date DESC
        """,
        (user["id"], f"{month_prefix}%")
    ).fetchall()

    today_entry = conn.execute(
        """
        SELECT * FROM time_entries
        WHERE employee_id = ? AND work_date = ?
        """,
        (user["id"], today.isoformat())
    ).fetchone()

    leave_requests = conn.execute(
        """
        SELECT *
        FROM leave_requests
        WHERE employee_id = ?
        ORDER BY id DESC
        LIMIT 20
        """,
        (user["id"],)
    ).fetchall()

    payrolls = conn.execute(
        """
        SELECT *
        FROM payrolls
        WHERE employee_id = ?
        ORDER BY reference_month DESC, id DESC
        LIMIT 12
        """,
        (user["id"],)
    ).fetchall()

    employee_people = conn.execute(
        """
        SELECT users.id, users.name, users.prontuario, users.employee_type
        FROM users
        JOIN roles ON roles.id = users.role_id
        WHERE roles.code = 'EMPLOYEE'
          AND users.active = 1
          AND users.id != ?
        ORDER BY users.name
        """,
        (user["id"],)
    ).fetchall()

    hr_reports = conn.execute(
        """
        SELECT
            hr_reports.*,
            involved.name AS involved_name,
            handler.name AS handled_by_name
        FROM hr_reports
        LEFT JOIN users AS involved ON involved.id = hr_reports.involved_user_id
        LEFT JOIN users AS handler ON handler.id = hr_reports.handled_by
        WHERE hr_reports.reporter_id = ?
        ORDER BY hr_reports.id DESC
        LIMIT 50
        """,
        (user["id"],)
    ).fetchall()

    conn.close()

    return render_template(
        "rh/meu_rh.html",
        profile=profile,
        schedules=schedules,
        time_entries=time_entries,
        today_entry=today_entry,
        leave_requests=leave_requests,
        payrolls=payrolls,
        employee_people=employee_people,
        hr_reports=hr_reports,
        today=today
    )


@app.post("/meu-rh/ponto")
@login_required
def clock_action():
    user = current_user()

    if user["role_code"] == "STUDENT":
        abort(403)

    action = request.form.get("action")

    if action not in {"clock_in", "break_out", "break_in", "clock_out"}:
        abort(400)

    now = datetime.now()
    work_date = now.date().isoformat()
    current_time = now.strftime("%H:%M")

    conn = get_db()

    entry = conn.execute(
        """
        SELECT * FROM time_entries
        WHERE employee_id = ? AND work_date = ?
        """,
        (user["id"], work_date)
    ).fetchone()

    if not entry:
        conn.execute(
            """
            INSERT INTO time_entries (employee_id, work_date)
            VALUES (?, ?)
            """,
            (user["id"], work_date)
        )
        entry = conn.execute(
            """
            SELECT * FROM time_entries
            WHERE employee_id = ? AND work_date = ?
            """,
            (user["id"], work_date)
        ).fetchone()

    required_previous = {
        "clock_in": None,
        "break_out": "clock_in",
        "break_in": "break_out",
        "clock_out": "clock_in",
    }

    target_column = action

    if entry[target_column]:
        conn.close()
        flash("Esse registro de ponto já foi realizado hoje.")
        return redirect(url_for("employee_hr"))

    previous = required_previous[action]
    if previous and not entry[previous]:
        conn.close()
        flash("A sequência do ponto está incompleta.")
        return redirect(url_for("employee_hr"))

    if action == "break_in" and not entry["break_out"]:
        conn.close()
        flash("Registre o início do intervalo primeiro.")
        return redirect(url_for("employee_hr"))

    if action == "clock_out" and entry["break_out"] and not entry["break_in"]:
        conn.close()
        flash("Finalize o intervalo antes de registrar a saída.")
        return redirect(url_for("employee_hr"))

    conn.execute(
        f"""
        UPDATE time_entries
        SET {target_column} = ?,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (current_time, entry["id"])
    )

    if action == "clock_out":
        refreshed = conn.execute(
            "SELECT * FROM time_entries WHERE id = ?",
            (entry["id"],)
        ).fetchone()

        schedule = conn.execute(
            """
            SELECT * FROM work_schedules
            WHERE employee_id = ?
            AND work_date = ?
            ORDER BY id DESC
            LIMIT 1
            """,
            (user["id"], work_date)
        ).fetchone()

        worked = worked_minutes_from_entry(refreshed)
        expected = schedule_expected_minutes(schedule)
        overtime = max(0, worked - expected) if expected else 0
        shortfall = max(0, expected - worked) if expected else 0

        conn.execute(
            """
            UPDATE time_entries
            SET worked_minutes = ?,
                expected_minutes = ?,
                overtime_minutes = ?,
                shortfall_minutes = ?,
                status = 'PENDING',
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            (
                worked,
                expected,
                overtime,
                shortfall,
                entry["id"]
            )
        )

    conn.commit()
    conn.close()

    flash("Ponto registrado.")
    return redirect(url_for("employee_hr"))


@app.post("/meu-rh/afastamentos/solicitar")
@login_required
def request_leave():
    user = current_user()

    if user["role_code"] == "STUDENT":
        abort(403)

    leave_type = request.form.get("leave_type")
    start_text = request.form.get("start_date")
    end_text = request.form.get("end_date")
    reason = request.form.get("reason", "").strip()

    if leave_type not in {"VACATION", "MEDICAL", "PERSONAL", "OTHER"}:
        flash("Tipo de afastamento inválido.")
        return redirect(url_for("employee_hr"))

    try:
        start_date_value = date.fromisoformat(start_text)
        end_date_value = date.fromisoformat(end_text)
    except (TypeError, ValueError):
        flash("Datas inválidas.")
        return redirect(url_for("employee_hr"))

    if end_date_value < start_date_value:
        flash("A data final não pode ser anterior à inicial.")
        return redirect(url_for("employee_hr"))

    total_days = (end_date_value - start_date_value).days + 1

    conn = get_db()
    profile = conn.execute(
        "SELECT * FROM employee_profiles WHERE user_id = ?",
        (user["id"],)
    ).fetchone()

    if leave_type == "VACATION":
        if total_days > 30 or total_days < 5:
            conn.close()
            flash("Períodos de férias neste sistema devem ter entre 5 e 30 dias.")
            return redirect(url_for("employee_hr"))

        if profile and profile["hire_date"]:
            try:
                hire = date.fromisoformat(profile["hire_date"])
                if start_date_value < add_months(hire, 12):
                    conn.close()
                    flash("O período aquisitivo inicial de 12 meses ainda não foi concluído.")
                    return redirect(url_for("employee_hr"))
            except ValueError:
                pass

    conn.execute(
        """
        INSERT INTO leave_requests (
            employee_id,
            leave_type,
            start_date,
            end_date,
            total_days,
            reason
        )
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (
            user["id"],
            leave_type,
            start_date_value.isoformat(),
            end_date_value.isoformat(),
            total_days,
            reason or None
        )
    )

    conn.commit()
    conn.close()

    flash("Solicitação enviada ao RH/administrador.")
    return redirect(url_for("employee_hr"))


@app.post("/meu-rh/relatos/novo")
@login_required
def submit_hr_report():
    user = current_user()
    if user["role_code"] == "STUDENT":
        abort(403)

    category = request.form.get("category", "").strip().upper()
    subject = request.form.get("subject", "").strip()
    description = request.form.get("description", "").strip()
    involved_user_id = request.form.get("involved_user_id", type=int)
    confidential = 1 if request.form.get("confidential") == "1" else 0

    allowed_categories = {
        "CONFLICT", "CONDUCT", "WORK_CONDITION", "SCHEDULE",
        "HARASSMENT", "REQUEST", "SUGGESTION", "OTHER"
    }
    if category not in allowed_categories or not subject or not description:
        flash("Preencha categoria, assunto e descrição do relato.")
        return redirect(url_for("employee_hr"))

    conn = get_db()
    if involved_user_id:
        involved = conn.execute(
            """
            SELECT users.id
            FROM users
            JOIN roles ON roles.id = users.role_id
            WHERE users.id = ? AND roles.code = 'EMPLOYEE' AND users.active = 1
            """,
            (involved_user_id,)
        ).fetchone()
        if not involved:
            conn.close()
            flash("Funcionário envolvido inválido.")
            return redirect(url_for("employee_hr"))

    conn.execute(
        """
        INSERT INTO hr_reports (
            reporter_id, category, subject, description, involved_user_id, confidential
        )
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (user["id"], category, subject, description, involved_user_id, confidential)
    )
    conn.commit()
    conn.close()

    flash("Relato enviado ao RH. Você poderá acompanhar o status em Meu RH.")
    return redirect(url_for("employee_hr"))


@app.post("/admin/rh/relatos/<int:report_id>/atualizar")
@require_hr_management
def update_hr_report(report_id):
    status = request.form.get("status", "").strip().upper()
    hr_notes = request.form.get("hr_notes", "").strip()
    if status not in {"OPEN", "IN_REVIEW", "RESOLVED", "DISMISSED"}:
        abort(400)

    conn = get_db()
    report = conn.execute("SELECT id FROM hr_reports WHERE id = ?", (report_id,)).fetchone()
    if not report:
        conn.close()
        abort(404)

    conn.execute(
        """
        UPDATE hr_reports
        SET status = ?, hr_notes = ?, handled_by = ?,
            handled_at = CASE WHEN ? IN ('RESOLVED', 'DISMISSED') THEN CURRENT_TIMESTAMP ELSE handled_at END,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (status, hr_notes or None, session["user_id"], status, report_id)
    )
    conn.commit()
    conn.close()

    flash("Relato de RH atualizado.")
    return redirect(url_for("admin_hr"))


@app.route("/rh")
@require_employee_types("HR")
def hr_dashboard():
    return redirect(url_for("admin_hr"))


@app.route("/admin/rh")
@require_hr_management
def admin_hr():
    actor = current_user()
    conn = get_db()

    employee_scope = "AND roles.code = 'EMPLOYEE'" if is_hr(actor) else "AND roles.code IN ('ADMIN', 'EMPLOYEE')"

    pending_approvals = conn.execute(
        f"""
        SELECT COUNT(*) AS total
        FROM users
        JOIN roles ON roles.id = users.role_id
        WHERE users.account_status = 'PENDING_APPROVAL'
        {employee_scope}
        """
    ).fetchone()["total"]

    pending_time = conn.execute(
        f"""
        SELECT COUNT(*) AS total
        FROM time_entries
        JOIN users ON users.id = time_entries.employee_id
        JOIN roles ON roles.id = users.role_id
        WHERE time_entries.status = 'PENDING'
        {employee_scope}
        """
    ).fetchone()["total"]

    pending_leaves = conn.execute(
        f"""
        SELECT COUNT(*) AS total
        FROM leave_requests
        JOIN users ON users.id = leave_requests.employee_id
        JOIN roles ON roles.id = users.role_id
        WHERE leave_requests.status = 'PENDING'
        {employee_scope}
        """
    ).fetchone()["total"]

    active_employees = conn.execute(
        f"""
        SELECT COUNT(*) AS total
        FROM users
        JOIN roles ON roles.id = users.role_id
        WHERE users.active = 1
        {employee_scope}
        """
    ).fetchone()["total"]

    hr_reports = conn.execute(
        """
        SELECT
            hr_reports.*,
            reporter.name AS reporter_name,
            reporter.prontuario AS reporter_prontuario,
            involved.name AS involved_name,
            handler.name AS handled_by_name
        FROM hr_reports
        JOIN users AS reporter ON reporter.id = hr_reports.reporter_id
        LEFT JOIN users AS involved ON involved.id = hr_reports.involved_user_id
        LEFT JOIN users AS handler ON handler.id = hr_reports.handled_by
        ORDER BY
            CASE hr_reports.status
                WHEN 'OPEN' THEN 0
                WHEN 'IN_REVIEW' THEN 1
                ELSE 2
            END,
            hr_reports.id DESC
        LIMIT 100
        """
    ).fetchall()

    open_hr_reports = sum(1 for item in hr_reports if item["status"] in {"OPEN", "IN_REVIEW"})

    conn.close()

    return render_template(
        "admin/rh.html",
        stats={
            "pending_approvals": pending_approvals,
            "pending_time": pending_time,
            "pending_leaves": pending_leaves,
            "active_employees": active_employees,
            "open_hr_reports": open_hr_reports,
        },
        hr_reports=hr_reports,
        hr_mode=is_hr(actor),
        default_hr_salary_cents=440000
    )


def hr_employee_scope_sql(actor, alias="users"):
    if is_hr(actor):
        return f"AND {alias}.id != {int(actor['id'])} AND roles.code = 'EMPLOYEE'"
    return "AND roles.code IN ('ADMIN', 'EMPLOYEE')"


def load_hr_target(conn, employee_id):
    return conn.execute(
        """
        SELECT users.id, users.employee_type, users.active,
               roles.code AS role_code
        FROM users
        JOIN roles ON roles.id = users.role_id
        WHERE users.id = ?
        """,
        (employee_id,)
    ).fetchone()


@app.route("/admin/escalas")
@require_hr_management
def schedules_admin():
    actor = current_user()
    conn = get_db()
    scope_sql = hr_employee_scope_sql(actor)

    employees_list = conn.execute(
        f"""
        SELECT users.id, users.name, users.prontuario, users.employee_type,
               roles.code AS role_code
        FROM users
        JOIN roles ON roles.id = users.role_id
        WHERE users.active = 1
        {scope_sql}
        ORDER BY users.name
        """
    ).fetchall()

    schedules = conn.execute(
        f"""
        SELECT work_schedules.*, users.name AS employee_name
        FROM work_schedules
        JOIN users ON users.id = work_schedules.employee_id
        JOIN roles ON roles.id = users.role_id
        WHERE work_date >= DATE('now', '-30 day')
        {scope_sql}
        ORDER BY work_date DESC, shift_start
        LIMIT 300
        """
    ).fetchall()

    conn.close()

    return render_template(
        "admin/escalas.html",
        employees=employees_list,
        schedules=schedules
    )


@app.post("/admin/escalas/nova")
@require_hr_management
def create_schedule():
    employee_id = request.form.get("employee_id", type=int)
    start_text = request.form.get("work_date")
    end_text = request.form.get("end_date") or start_text
    schedule_type = request.form.get("schedule_type", "WORK")
    shift_model = request.form.get("shift_model", "STANDARD")
    shift_start = request.form.get("shift_start") or None
    shift_end = request.form.get("shift_end") or None
    break_start = request.form.get("break_start") or None
    break_end = request.form.get("break_end") or None
    notes = request.form.get("notes", "").strip()
    weekdays = {
        int(value)
        for value in request.form.getlist("weekdays")
        if value.isdigit()
    }

    if schedule_type not in {"WORK", "DAY_OFF", "VACATION", "LEAVE"}:
        flash("Tipo de escala inválido.")
        return redirect(url_for("schedules_admin"))

    if shift_model not in {"STANDARD", "TWELVE_BY_THIRTY_SIX"}:
        flash("Modelo de jornada inválido.")
        return redirect(url_for("schedules_admin"))

    try:
        start_date_value = date.fromisoformat(start_text)
        end_date_value = date.fromisoformat(end_text)
    except (TypeError, ValueError):
        flash("Datas inválidas.")
        return redirect(url_for("schedules_admin"))

    if end_date_value < start_date_value:
        flash("A data final não pode ser anterior à inicial.")
        return redirect(url_for("schedules_admin"))

    if (end_date_value - start_date_value).days > 92:
        flash("Gere no máximo 93 dias de escala por vez.")
        return redirect(url_for("schedules_admin"))

    if schedule_type == "WORK":
        if not shift_start or not shift_end:
            flash("Informe entrada e saída para jornada de trabalho.")
            return redirect(url_for("schedules_admin"))

        total_minutes = duration_between_times(shift_start, shift_end)
        break_minutes = duration_between_times(break_start, break_end)
        worked = max(0, total_minutes - break_minutes)

        if shift_model == "STANDARD" and worked > 600:
            flash("Jornada padrão acima de 10 horas foi bloqueada. Use 12x36 quando aplicável.")
            return redirect(url_for("schedules_admin"))

        if shift_model == "TWELVE_BY_THIRTY_SIX" and total_minutes > 720:
            flash("A jornada 12x36 não pode ultrapassar 12 horas nesta simulação.")
            return redirect(url_for("schedules_admin"))

        if worked > 360 and break_minutes < 30:
            flash("Jornadas acima de 6 horas precisam de intervalo. Informe ao menos 30 minutos.")
            return redirect(url_for("schedules_admin"))

    conn = get_db()

    employee = load_hr_target(conn, employee_id)

    if not employee or not employee["active"] or not hr_can_manage_target(current_user(), employee):
        conn.close()
        flash("Funcionário inválido ou fora das permissões do RH.")
        return redirect(url_for("schedules_admin"))

    inserted = 0
    current = start_date_value

    while current <= end_date_value:
        if weekdays and current.weekday() not in weekdays:
            current += timedelta(days=1)
            continue

        # Evita duplicidade por funcionário/data.
        conn.execute(
            """
            DELETE FROM work_schedules
            WHERE employee_id = ? AND work_date = ?
            """,
            (employee_id, current.isoformat())
        )

        conn.execute(
            """
            INSERT INTO work_schedules (
                employee_id,
                work_date,
                shift_start,
                shift_end,
                break_start,
                break_end,
                shift_model,
                schedule_type,
                notes,
                created_by
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                employee_id,
                current.isoformat(),
                shift_start if schedule_type == "WORK" else None,
                shift_end if schedule_type == "WORK" else None,
                break_start if schedule_type == "WORK" else None,
                break_end if schedule_type == "WORK" else None,
                shift_model,
                schedule_type,
                notes or None,
                session["user_id"]
            )
        )
        inserted += 1
        current += timedelta(days=1)

    if inserted == 0:
        conn.rollback()
        conn.close()
        flash("Nenhum dia da semana selecionado caiu dentro do período informado.")
        return redirect(url_for("schedules_admin"))

    validation_start = start_date_value - timedelta(days=8)
    validation_end = end_date_value + timedelta(days=8)

    work_rows = conn.execute(
        """
        SELECT *
        FROM work_schedules
        WHERE employee_id = ?
        AND schedule_type = 'WORK'
        AND work_date BETWEEN ? AND ?
        ORDER BY work_date, shift_start
        """,
        (
            employee_id,
            validation_start.isoformat(),
            validation_end.isoformat()
        )
    ).fetchall()

    intervals = []
    for row in work_rows:
        start_dt, end_dt = schedule_datetime_bounds(row)
        if start_dt and end_dt:
            intervals.append((start_dt, end_dt, row))

    intervals.sort(key=lambda item: item[0])

    for previous, following in zip(intervals, intervals[1:]):
        rest_minutes = int((following[0] - previous[1]).total_seconds() // 60)

        if (
            previous[2]["shift_model"] == "TWELVE_BY_THIRTY_SIX"
            or following[2]["shift_model"] == "TWELVE_BY_THIRTY_SIX"
        ) and rest_minutes < 36 * 60:
            conn.rollback()
            conn.close()
            flash(
                "Escala 12x36 bloqueada: devem existir 36 horas de descanso após o plantão."
            )
            return redirect(url_for("schedules_admin"))

        if rest_minutes < 660:
            conn.rollback()
            conn.close()
            flash(
                "Escala bloqueada: é necessário preservar pelo menos 11 horas de descanso entre jornadas."
            )
            return redirect(url_for("schedules_admin"))

    if shift_model == "STANDARD" and schedule_type == "WORK":
        affected_mondays = set()
        current = start_date_value
        while current <= end_date_value:
            if not weekdays or current.weekday() in weekdays:
                affected_mondays.add(current - timedelta(days=current.weekday()))
            current += timedelta(days=1)

        for monday in affected_mondays:
            sunday = monday + timedelta(days=6)
            week_rows = conn.execute(
                """
                SELECT *
                FROM work_schedules
                WHERE employee_id = ?
                AND schedule_type = 'WORK'
                AND shift_model = 'STANDARD'
                AND work_date BETWEEN ? AND ?
                """,
                (employee_id, monday.isoformat(), sunday.isoformat())
            ).fetchall()

            week_minutes = sum(schedule_expected_minutes(row) for row in week_rows)

            if week_minutes > 44 * 60:
                conn.rollback()
                conn.close()
                flash(
                    f"Escala bloqueada: a semana iniciada em {monday.strftime('%d/%m/%Y')} ultrapassaria 44 horas na jornada padrão."
                )
                return redirect(url_for("schedules_admin"))

    conn.commit()
    conn.close()

    warning = ""
    if schedule_type == "WORK" and worked > 360 and break_minutes < 60:
        warning = (
            " Atenção: intervalo inferior a 1 hora em jornada acima de 6 horas "
            "pressupõe hipótese legal/negociação coletiva aplicável."
        )

    flash(f"{inserted} dia(s) de escala cadastrado(s).{warning}")
    return redirect(url_for("schedules_admin"))


@app.post("/admin/escalas/<int:schedule_id>/remover")
@require_hr_management
def delete_schedule(schedule_id):
    conn = get_db()
    schedule = conn.execute(
        "SELECT employee_id FROM work_schedules WHERE id = ?",
        (schedule_id,)
    ).fetchone()

    if not schedule:
        conn.close()
        abort(404)

    target = load_hr_target(conn, schedule["employee_id"])
    if not hr_can_manage_target(current_user(), target):
        conn.close()
        abort(403)

    conn.execute("DELETE FROM work_schedules WHERE id = ?", (schedule_id,))
    conn.commit()
    conn.close()

    flash("Escala removida.")
    return redirect(url_for("schedules_admin"))


@app.route("/admin/ponto")
@require_hr_management
def time_admin():
    actor = current_user()
    reference_month = request.args.get("month") or date.today().strftime("%Y-%m")
    employee_id = request.args.get("employee_id", type=int)

    conn = get_db()
    scope_sql = hr_employee_scope_sql(actor)

    employees_list = conn.execute(
        f"""
        SELECT users.id, users.name, users.prontuario
        FROM users
        JOIN roles ON roles.id = users.role_id
        WHERE 1 = 1
        {scope_sql}
        ORDER BY users.name
        """
    ).fetchall()

    parameters = [f"{reference_month}%"]
    extra_filter = ""

    if employee_id:
        extra_filter = "AND time_entries.employee_id = ?"
        parameters.append(employee_id)

    entries = conn.execute(
        f"""
        SELECT time_entries.*, users.name AS employee_name,
               users.prontuario
        FROM time_entries
        JOIN users ON users.id = time_entries.employee_id
        JOIN roles ON roles.id = users.role_id
        WHERE time_entries.work_date LIKE ?
        {scope_sql}
        {extra_filter}
        ORDER BY time_entries.work_date DESC, users.name
        """,
        parameters
    ).fetchall()

    conn.close()

    return render_template(
        "admin/ponto.html",
        entries=entries,
        employees=employees_list,
        reference_month=reference_month,
        selected_employee=employee_id
    )


@app.post("/admin/ponto/<int:entry_id>/aprovar")
@require_hr_management
def approve_time_entry(entry_id):
    overtime_minutes = request.form.get("overtime_minutes", type=int)
    shortfall_minutes = request.form.get("shortfall_minutes", type=int)
    notes = request.form.get("notes", "").strip()

    conn = get_db()
    entry = conn.execute(
        "SELECT * FROM time_entries WHERE id = ?",
        (entry_id,)
    ).fetchone()

    if not entry:
        conn.close()
        abort(404)

    target = load_hr_target(conn, entry["employee_id"])
    if not hr_can_manage_target(current_user(), target):
        conn.close()
        abort(403)

    if overtime_minutes is None:
        overtime_minutes = entry["overtime_minutes"]

    if shortfall_minutes is None:
        shortfall_minutes = entry["shortfall_minutes"]

    conn.execute(
        """
        UPDATE time_entries
        SET overtime_minutes = ?,
            shortfall_minutes = ?,
            notes = ?,
            status = CASE
                WHEN overtime_minutes != ? OR shortfall_minutes != ?
                    THEN 'ADJUSTED'
                ELSE 'APPROVED'
            END,
            approved_by = ?,
            approved_at = CURRENT_TIMESTAMP,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (
            max(0, overtime_minutes),
            max(0, shortfall_minutes),
            notes or None,
            entry["overtime_minutes"],
            entry["shortfall_minutes"],
            session["user_id"],
            entry_id
        )
    )

    conn.commit()
    conn.close()

    flash("Registro de ponto aprovado.")
    return redirect(request.referrer or url_for("time_admin"))


@app.route("/admin/ferias-afastamentos")
@require_hr_management
def leave_admin():
    actor = current_user()
    conn = get_db()
    scope_sql = hr_employee_scope_sql(actor)

    requests_list = conn.execute(
        f"""
        SELECT leave_requests.*, users.name AS employee_name,
               users.prontuario, employee_profiles.hire_date
        FROM leave_requests
        JOIN users ON users.id = leave_requests.employee_id
        LEFT JOIN employee_profiles
            ON employee_profiles.user_id = users.id
        JOIN roles ON roles.id = users.role_id
        WHERE 1 = 1
        {scope_sql}
        ORDER BY
            CASE leave_requests.status WHEN 'PENDING' THEN 0 ELSE 1 END,
            leave_requests.id DESC
        """
    ).fetchall()

    conn.close()

    return render_template(
        "admin/afastamentos.html",
        requests=requests_list
    )


@app.post("/admin/ferias-afastamentos/<int:request_id>/decidir")
@require_hr_management
def decide_leave(request_id):
    decision = request.form.get("decision")
    admin_notes = request.form.get("admin_notes", "").strip()

    if decision not in {"APPROVED", "REJECTED"}:
        abort(400)

    conn = get_db()
    leave = conn.execute(
        "SELECT * FROM leave_requests WHERE id = ?",
        (request_id,)
    ).fetchone()

    if not leave:
        conn.close()
        abort(404)

    target = load_hr_target(conn, leave["employee_id"])
    if not hr_can_manage_target(current_user(), target):
        conn.close()
        abort(403)

    conn.execute(
        """
        UPDATE leave_requests
        SET status = ?,
            admin_notes = ?,
            reviewed_by = ?,
            reviewed_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (
            decision,
            admin_notes or None,
            session["user_id"],
            request_id
        )
    )

    if decision == "APPROVED":
        schedule_type = "VACATION" if leave["leave_type"] == "VACATION" else "LEAVE"
        current = date.fromisoformat(leave["start_date"])
        end = date.fromisoformat(leave["end_date"])

        while current <= end:
            conn.execute(
                "DELETE FROM work_schedules WHERE employee_id = ? AND work_date = ?",
                (leave["employee_id"], current.isoformat())
            )
            conn.execute(
                """
                INSERT INTO work_schedules (
                    employee_id,
                    work_date,
                    shift_model,
                    schedule_type,
                    notes,
                    created_by
                )
                VALUES (?, ?, 'STANDARD', ?, ?, ?)
                """,
                (
                    leave["employee_id"],
                    current.isoformat(),
                    schedule_type,
                    "Gerado por solicitação de RH aprovada",
                    session["user_id"]
                )
            )
            current += timedelta(days=1)

    conn.commit()
    conn.close()

    flash("Solicitação atualizada.")
    return redirect(url_for("leave_admin"))


@app.route("/admin/folha")
@require_hr_management
def payroll_admin():
    actor = current_user()
    reference_month = request.args.get("month") or date.today().strftime("%Y-%m")

    conn = get_db()
    scope_sql = hr_employee_scope_sql(actor)

    employees_list = conn.execute(
        f"""
        SELECT users.id, users.name, users.prontuario, users.employee_type,
               roles.code AS role_code,
               employee_profiles.base_salary_cents,
               employee_profiles.weekly_hours,
               employee_profiles.dependents_count
        FROM users
        JOIN roles ON roles.id = users.role_id
        LEFT JOIN employee_profiles
            ON employee_profiles.user_id = users.id
        WHERE users.active = 1
        {scope_sql}
        ORDER BY users.name
        """
    ).fetchall()

    payrolls = conn.execute(
        f"""
        SELECT payrolls.*, users.name AS employee_name,
               users.prontuario
        FROM payrolls
        JOIN users ON users.id = payrolls.employee_id
        JOIN roles ON roles.id = users.role_id
        WHERE payrolls.reference_month = ?
        {scope_sql}
        ORDER BY users.name
        """,
        (reference_month,)
    ).fetchall()

    conn.close()

    return render_template(
        "admin/folha.html",
        employees=employees_list,
        payrolls=payrolls,
        reference_month=reference_month,
        hr_mode=is_hr(actor)
    )


@app.post("/admin/folha/gerar")
@require_hr_management
def generate_payroll():
    employee_id = request.form.get("employee_id", type=int)
    reference_month = request.form.get("reference_month") or date.today().strftime("%Y-%m")
    bonus_cents = parse_money_to_cents(request.form.get("bonus", ""))
    other_earnings_cents = parse_money_to_cents(request.form.get("other_earnings", ""))
    other_deductions_cents = parse_money_to_cents(request.form.get("other_deductions", ""))

    if None in {bonus_cents, other_earnings_cents, other_deductions_cents}:
        flash("Há valores monetários inválidos.")
        return redirect(url_for("payroll_admin", month=reference_month))

    conn = get_db()

    employee = conn.execute(
        """
        SELECT users.id, users.name, users.employee_type,
               roles.code AS role_code,
               employee_profiles.base_salary_cents,
               employee_profiles.weekly_hours,
               employee_profiles.dependents_count
        FROM users
        JOIN roles ON roles.id = users.role_id
        LEFT JOIN employee_profiles
            ON employee_profiles.user_id = users.id
        WHERE users.id = ?
        AND roles.code IN ('ADMIN', 'EMPLOYEE')
        """,
        (employee_id,)
    ).fetchone()

    if not employee or not hr_can_manage_target(current_user(), employee):
        conn.close()
        flash("Funcionário inválido ou fora das permissões do RH.")
        return redirect(url_for("payroll_admin", month=reference_month))

    if not employee["base_salary_cents"]:
        conn.close()
        flash("Cadastre o salário-base do funcionário antes de gerar a folha.")
        return redirect(url_for("payroll_admin", month=reference_month))

    totals = conn.execute(
        """
        SELECT
            COALESCE(SUM(overtime_minutes), 0) AS overtime_minutes,
            COALESCE(SUM(shortfall_minutes), 0) AS shortfall_minutes
        FROM time_entries
        WHERE employee_id = ?
        AND work_date LIKE ?
        AND status IN ('APPROVED', 'ADJUSTED')
        """,
        (employee_id, f"{reference_month}%")
    ).fetchone()

    calculation = payroll_calculation(
        employee["base_salary_cents"],
        employee["weekly_hours"] or 44,
        totals["overtime_minutes"],
        totals["shortfall_minutes"],
        bonus_cents,
        other_earnings_cents,
        other_deductions_cents,
        employee["dependents_count"] or 0,
        50
    )

    conn.execute(
        """
        INSERT INTO payrolls (
            employee_id,
            reference_month,
            base_salary_cents,
            monthly_hours,
            overtime_minutes,
            overtime_percent,
            overtime_cents,
            shortfall_minutes,
            absence_discount_cents,
            bonus_cents,
            other_earnings_cents,
            other_deductions_cents,
            gross_cents,
            inss_cents,
            irrf_cents,
            fgts_cents,
            net_cents,
            status,
            created_by
        )
        VALUES (?, ?, ?, ?, ?, 50, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'CLOSED', ?)
        ON CONFLICT(employee_id, reference_month, payroll_type)
        DO UPDATE SET
            base_salary_cents = excluded.base_salary_cents,
            monthly_hours = excluded.monthly_hours,
            overtime_minutes = excluded.overtime_minutes,
            overtime_percent = excluded.overtime_percent,
            overtime_cents = excluded.overtime_cents,
            shortfall_minutes = excluded.shortfall_minutes,
            absence_discount_cents = excluded.absence_discount_cents,
            bonus_cents = excluded.bonus_cents,
            other_earnings_cents = excluded.other_earnings_cents,
            other_deductions_cents = excluded.other_deductions_cents,
            gross_cents = excluded.gross_cents,
            inss_cents = excluded.inss_cents,
            irrf_cents = excluded.irrf_cents,
            fgts_cents = excluded.fgts_cents,
            net_cents = excluded.net_cents,
            status = 'CLOSED',
            created_by = excluded.created_by,
            paid_at = NULL,
            created_at = CURRENT_TIMESTAMP
        """,
        (
            employee_id,
            reference_month,
            employee["base_salary_cents"],
            calculation["monthly_hours"],
            totals["overtime_minutes"],
            calculation["overtime_cents"],
            totals["shortfall_minutes"],
            calculation["absence_discount_cents"],
            bonus_cents,
            other_earnings_cents,
            other_deductions_cents,
            calculation["gross_cents"],
            calculation["inss_cents"],
            calculation["irrf_cents"],
            calculation["fgts_cents"],
            calculation["net_cents"],
            session["user_id"]
        )
    )

    conn.commit()
    conn.close()

    flash("Folha calculada com as tabelas de INSS/IRRF de 2026.")
    return redirect(url_for("payroll_admin", month=reference_month))


@app.post("/admin/folha/<int:payroll_id>/pagar")
@require_roles("OWNER", "ADMIN")
def pay_payroll(payroll_id):
    conn = get_db()
    payroll = conn.execute(
        "SELECT id FROM payrolls WHERE id = ?",
        (payroll_id,)
    ).fetchone()

    if not payroll:
        conn.close()
        abort(404)

    conn.execute(
        """
        UPDATE payrolls
        SET status = 'PAID',
            paid_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (payroll_id,)
    )
    conn.commit()
    conn.close()

    flash("Folha marcada como paga.")
    return redirect(request.referrer or url_for("payroll_admin"))



@app.route("/perfil/<int:user_id>")
@login_required
def user_profile(user_id):
    actor = current_user()
    conn = get_db()

    target = conn.execute(
        """
        SELECT
            users.*,
            roles.code AS role_code,
            roles.name AS role_name,
            employee_profiles.phone AS employee_phone,
            employee_profiles.email AS employee_email,
            employee_profiles.hire_date,
            employee_profiles.professional_title,
            employee_profiles.specialties,
            employee_profiles.professional_bio,
            student_profiles.phone AS student_phone,
            student_profiles.email AS student_email,
            student_profiles.birth_date AS student_birth_date
        FROM users
        JOIN roles ON roles.id = users.role_id
        LEFT JOIN employee_profiles ON employee_profiles.user_id = users.id
        LEFT JOIN student_profiles ON student_profiles.user_id = users.id
        WHERE users.id = ?
        """,
        (user_id,)
    ).fetchone()

    if not target:
        conn.close()
        abort(404)

    access_level = None
    if actor["id"] == target["id"]:
        access_level = "SELF"
    elif actor["role_code"] in {"OWNER", "ADMIN"}:
        access_level = "MANAGEMENT"
    elif is_hr(actor) and target["role_code"] in {"ADMIN", "EMPLOYEE"}:
        access_level = "MANAGEMENT"
    elif target["role_code"] in {"OWNER", "ADMIN", "EMPLOYEE"}:
        if target["active"]:
            if actor["role_code"] == "EMPLOYEE":
                access_level = "PROFESSIONAL"
            elif actor["role_code"] == "STUDENT" and target["role_code"] == "EMPLOYEE" and target["employee_type"] == "PERSONAL":
                relation = conn.execute(
                    """
                    SELECT 1
                    WHERE EXISTS (
                        SELECT 1
                        FROM workout_plans
                        WHERE student_id = ?
                          AND personal_id = ?
                          AND status = 'ACTIVE'
                    )
                    OR EXISTS (
                        SELECT 1
                        FROM warnings
                        WHERE student_id = ?
                          AND personal_id = ?
                    )
                    """,
                    (actor["id"], target["id"], actor["id"], target["id"])
                ).fetchone()
                if relation:
                    access_level = "PROFESSIONAL"
    elif target["role_code"] == "STUDENT" and target["active"]:
        if is_reception(actor):
            access_level = "STUDENT_CONTACT"
        elif actor["role_code"] == "EMPLOYEE" and actor["employee_type"] == "PERSONAL":
            access_level = "COACH"

    if not access_level:
        conn.close()
        abort(403)

    subscription = None
    active_workout = None
    recent_sessions = []

    if target["role_code"] == "STUDENT":
        subscription = conn.execute(
            """
            SELECT subscriptions.*, plans.name AS plan_name
            FROM subscriptions
            JOIN plans ON plans.id = subscriptions.plan_id
            WHERE subscriptions.student_id = ?
            ORDER BY subscriptions.id DESC
            LIMIT 1
            """,
            (target["id"],)
        ).fetchone()

        active_workout = conn.execute(
            """
            SELECT
                workout_plans.*,
                personal.name AS personal_name,
                personal.profile_image_filename AS personal_image_filename
            FROM workout_plans
            JOIN users AS personal ON personal.id = workout_plans.personal_id
            WHERE workout_plans.student_id = ?
              AND workout_plans.status = 'ACTIVE'
            ORDER BY workout_plans.id DESC
            LIMIT 1
            """,
            (target["id"],)
        ).fetchone()

        if access_level in {"SELF", "MANAGEMENT", "COACH"}:
            recent_sessions = conn.execute(
                """
                SELECT
                    workout_sessions.session_date,
                    workout_sessions.status,
                    workout_days.day_name,
                    workout_plans.title
                FROM workout_sessions
                JOIN workout_days ON workout_days.id = workout_sessions.workout_day_id
                JOIN workout_plans ON workout_plans.id = workout_days.workout_plan_id
                WHERE workout_sessions.student_id = ?
                ORDER BY workout_sessions.session_date DESC, workout_sessions.id DESC
                LIMIT 10
                """,
                (target["id"],)
            ).fetchall()

    conn.close()

    if target["role_code"] == "STUDENT":
        can_view_contact = access_level in {"SELF", "MANAGEMENT", "STUDENT_CONTACT", "COACH"}
    else:
        can_view_contact = access_level in {"SELF", "MANAGEMENT"}

    specialty_items = []
    if target["specialties"]:
        specialty_items = [
            item.strip()
            for item in target["specialties"].replace(";", ",").split(",")
            if item.strip()
        ]

    return render_template(
        "perfil.html",
        profile_user=target,
        access_level=access_level,
        can_view_contact=can_view_contact,
        subscription=subscription,
        active_workout=active_workout,
        recent_sessions=recent_sessions,
        specialty_items=specialty_items
    )


@app.route("/perfil/editar", methods=["GET", "POST"])
@login_required
def edit_profile():
    user = current_user()
    conn = get_db()

    profile = conn.execute(
        """
        SELECT
            users.*,
            roles.code AS role_code,
            employee_profiles.email AS employee_email,
            employee_profiles.phone AS employee_phone,
            employee_profiles.professional_title,
            employee_profiles.specialties,
            employee_profiles.professional_bio,
            student_profiles.email AS student_email,
            student_profiles.phone AS student_phone,
            student_profiles.emergency_contact AS student_emergency_contact
        FROM users
        JOIN roles ON roles.id = users.role_id
        LEFT JOIN employee_profiles ON employee_profiles.user_id = users.id
        LEFT JOIN student_profiles ON student_profiles.user_id = users.id
        WHERE users.id = ?
        """,
        (user["id"],)
    ).fetchone()

    if request.method == "GET":
        conn.close()
        return render_template("editar_perfil.html", profile=profile)

    name = request.form.get("name", "").strip()[:120]
    if len(name) < 2:
        conn.close()
        flash("Informe um nome válido.")
        return redirect(url_for("edit_profile"))

    conn.execute(
        "UPDATE users SET name = ? WHERE id = ?",
        (name, user["id"])
    )

    if profile["role_code"] == "STUDENT":
        email = request.form.get("email", "").strip().lower()[:180]
        phone = only_digits(request.form.get("phone", ""))[:15]
        emergency_contact = request.form.get("emergency_contact", "").strip()[:180]

        if email and not valid_email(email):
            conn.rollback()
            conn.close()
            flash("Informe um e-mail válido.")
            return redirect(url_for("edit_profile"))

        if email and email_in_use(conn, email, exclude_user_id=user["id"]):
            conn.rollback()
            conn.close()
            flash("Esse e-mail já está vinculado a outra conta.")
            return redirect(url_for("edit_profile"))

        conn.execute(
            """
            INSERT OR IGNORE INTO student_profiles (user_id)
            VALUES (?)
            """,
            (user["id"],)
        )
        conn.execute(
            """
            UPDATE student_profiles
            SET email = ?, phone = ?, emergency_contact = ?
            WHERE user_id = ?
            """,
            (email or None, phone or None, emergency_contact or None, user["id"])
        )
        conn.execute(
            "UPDATE users SET email = ? WHERE id = ?",
            (email or None, user["id"])
        )

    elif profile["role_code"] in {"ADMIN", "EMPLOYEE"}:
        email = request.form.get("email", "").strip().lower()[:180]
        phone = only_digits(request.form.get("phone", ""))[:15]
        professional_title = request.form.get("professional_title", "").strip()[:100]
        specialties = request.form.get("specialties", "").strip()[:220]
        professional_bio = request.form.get("professional_bio", "").strip()[:900]

        if email and not valid_email(email):
            conn.rollback()
            conn.close()
            flash("Informe um e-mail válido.")
            return redirect(url_for("edit_profile"))

        if email and email_in_use(conn, email, exclude_user_id=user["id"]):
            conn.rollback()
            conn.close()
            flash("Esse e-mail já está vinculado a outra conta.")
            return redirect(url_for("edit_profile"))

        conn.execute(
            """
            INSERT OR IGNORE INTO employee_profiles (
                user_id, hire_date, weekly_hours, employment_type
            ) VALUES (?, DATE('now'), 44, 'CLT')
            """,
            (user["id"],)
        )
        conn.execute(
            """
            UPDATE employee_profiles
            SET email = ?,
                phone = ?,
                professional_title = ?,
                specialties = ?,
                professional_bio = ?
            WHERE user_id = ?
            """,
            (
                email or None,
                phone or None,
                professional_title or None,
                specialties or None,
                professional_bio or None,
                user["id"]
            )
        )
        conn.execute(
            "UPDATE users SET email = ? WHERE id = ?",
            (email or None, user["id"])
        )

    conn.commit()
    conn.close()
    flash("Perfil atualizado.")
    return redirect(url_for("user_profile", user_id=user["id"]))


@app.route("/configuracoes")
@login_required
def account_settings():
    return render_template("configuracoes.html")


@app.post("/configuracoes/interface")
@login_required
def update_interface_settings():
    user = current_user()
    theme = request.form.get("theme", user["theme"] or "LIGHT").strip().upper()
    density = request.form.get("ui_density", user["ui_density"] or "COMFORTABLE").strip().upper()
    motion_enabled = 1 if request.form.get("motion_enabled") == "1" else 0

    if theme not in {"LIGHT", "DARK_YELLOW"}:
        flash("Tema inválido.")
        return redirect(url_for("account_settings"))

    if density not in {"COMFORTABLE", "COMPACT"}:
        flash("Densidade inválida.")
        return redirect(url_for("account_settings"))

    conn = get_db()
    conn.execute(
        """
        UPDATE users
        SET theme = ?, ui_density = ?, motion_enabled = ?
        WHERE id = ?
        """,
        (theme, density, motion_enabled, user["id"])
    )
    conn.commit()
    conn.close()

    flash("Preferências salvas.")
    return redirect(url_for("account_settings"))


@app.post("/configuracoes/perfil-profissional")
@login_required
def update_professional_profile():
    return redirect(url_for("edit_profile"))


@app.post("/configuracoes/foto")
@login_required
def update_profile_photo():
    user = current_user()
    image = request.files.get("profile_image")

    if not image or not image.filename:
        flash("Selecione uma imagem para o perfil.")
        return redirect(url_for("user_profile", user_id=user["id"]))

    original_name = secure_filename(image.filename)
    if "." not in original_name:
        flash("Formato de imagem inválido.")
        return redirect(url_for("user_profile", user_id=user["id"]))

    extension = original_name.rsplit(".", 1)[1].lower()
    if extension not in PROFILE_IMAGE_EXTENSIONS:
        flash("Use uma foto JPG, JPEG, PNG ou WEBP.")
        return redirect(url_for("user_profile", user_id=user["id"]))

    data = image.read(MAX_PROFILE_IMAGE_BYTES + 1)
    if len(data) > MAX_PROFILE_IMAGE_BYTES:
        flash("A foto deve ter no máximo 5 MB.")
        return redirect(url_for("user_profile", user_id=user["id"]))

    if not valid_profile_image_bytes(data, extension):
        flash("O arquivo enviado não parece ser uma imagem válida.")
        return redirect(url_for("user_profile", user_id=user["id"]))

    stored_name = f"user_{user['id']}_{uuid.uuid4().hex}.{extension}"
    (PROFILE_IMAGE_DIR / stored_name).write_bytes(data)

    conn = get_db()
    row = conn.execute(
        "SELECT profile_image_filename FROM users WHERE id = ?",
        (user["id"],)
    ).fetchone()
    old_name = row["profile_image_filename"] if row else None

    conn.execute(
        "UPDATE users SET profile_image_filename = ? WHERE id = ?",
        (stored_name, user["id"])
    )
    conn.commit()
    conn.close()

    if old_name and old_name != stored_name:
        try:
            old_path = PROFILE_IMAGE_DIR / old_name
            if old_path.is_file():
                old_path.unlink()
        except OSError:
            pass

    flash("Foto atualizada.")
    return redirect(url_for("user_profile", user_id=user["id"]))


@app.post("/configuracoes/foto/remover")
@login_required
def remove_profile_photo():
    user = current_user()
    old_name = user["profile_image_filename"]

    conn = get_db()
    conn.execute(
        "UPDATE users SET profile_image_filename = NULL WHERE id = ?",
        (user["id"],)
    )
    conn.commit()
    conn.close()

    if old_name:
        try:
            old_path = PROFILE_IMAGE_DIR / old_name
            if old_path.is_file():
                old_path.unlink()
        except OSError:
            pass

    flash("Foto removida.")
    return redirect(url_for("user_profile", user_id=user["id"]))


@app.post("/configuracoes/senha")
@login_required
def change_password():
    user = current_user()
    current_password = request.form.get("current_password", "")
    new_password = request.form.get("new_password", "")
    confirm_password = request.form.get("confirm_password", "")

    if not check_password_hash(user["password_hash"], current_password):
        flash("A senha atual está incorreta.")
        return redirect(url_for("account_settings"))

    if len(new_password) < 6:
        flash("A nova senha deve ter pelo menos 6 caracteres.")
        return redirect(url_for("account_settings"))

    if new_password != confirm_password:
        flash("A confirmação da nova senha não coincide.")
        return redirect(url_for("account_settings"))

    if check_password_hash(user["password_hash"], new_password):
        flash("Escolha uma senha diferente da atual.")
        return redirect(url_for("account_settings"))

    conn = get_db()
    conn.execute(
        "UPDATE users SET password_hash = ? WHERE id = ?",
        (generate_password_hash(new_password), user["id"])
    )
    conn.commit()
    conn.close()

    flash("Senha alterada.")
    return redirect(url_for("account_settings"))


@app.post("/configuracoes/tema")
@login_required
def change_theme():
    user = current_user()
    theme = request.form.get("theme", "LIGHT").strip().upper()

    if theme not in {"LIGHT", "DARK_YELLOW"}:
        flash("Tema inválido.")
        return redirect(url_for("account_settings"))

    conn = get_db()
    conn.execute(
        "UPDATE users SET theme = ? WHERE id = ?",
        (theme, user["id"])
    )
    conn.commit()
    conn.close()

    return redirect(url_for("account_settings"))


init_db()
seed_database()


if __name__ == "__main__":
    app.run(debug=True)
