from pathlib import Path
import sqlite3

BASE_DIR = Path(__file__).resolve().parent
DATABASE_PATH = BASE_DIR / "database" / "academia.db"
SCHEMA_PATH = BASE_DIR / "schema.sql"


def get_db():
    DATABASE_PATH.parent.mkdir(parents=True, exist_ok=True)

    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")

    return conn


def _table_columns(conn, table_name):
    return {
        row["name"]
        for row in conn.execute(f"PRAGMA table_info({table_name})").fetchall()
    }


def _ensure_column(conn, table_name, column_name, definition):
    if column_name not in _table_columns(conn, table_name):
        conn.execute(
            f"ALTER TABLE {table_name} ADD COLUMN {column_name} {definition}"
        )


def _users_table_sql(conn):
    row = conn.execute(
        "SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'users'"
    ).fetchone()
    return row["sql"] if row and row["sql"] else ""


def _users_table_requires_rebuild(conn):
    sql = _users_table_sql(conn)
    return "'HR'" not in sql or "'EMAIL_PENDING'" not in sql


def _rebuild_users_table(conn):
    if not _users_table_requires_rebuild(conn):
        return

    # SQLite não permite alterar CHECK constraints diretamente. A tabela é
    # recriada preservando IDs e relações existentes.
    conn.commit()
    conn.execute("PRAGMA foreign_keys = OFF")

    conn.execute("DROP TABLE IF EXISTS users_new")
    conn.execute(
        """
        CREATE TABLE users_new (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            prontuario TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            name TEXT NOT NULL,
            role_id INTEGER NOT NULL,
            employee_type TEXT CHECK (
                employee_type IS NULL OR employee_type IN (
                    'PERSONAL', 'CLEANING', 'SECURITY', 'RECEPTION', 'HR'
                )
            ),
            active INTEGER NOT NULL DEFAULT 1,
            email TEXT,
            profile_image_filename TEXT,
            theme TEXT NOT NULL DEFAULT 'LIGHT'
            CHECK (theme IN ('LIGHT', 'DARK_YELLOW')),
            ui_density TEXT NOT NULL DEFAULT 'COMFORTABLE'
            CHECK (ui_density IN ('COMFORTABLE', 'COMPACT')),
            motion_enabled INTEGER NOT NULL DEFAULT 1,
            account_status TEXT NOT NULL DEFAULT 'ACTIVE'
            CHECK (
                account_status IN (
                    'INVITED', 'EMAIL_PENDING', 'PENDING_APPROVAL',
                    'ACTIVE', 'INACTIVE', 'REJECTED'
                )
            ),
            onboarding_code_hash TEXT,
            onboarding_expires_at TEXT,
            onboarding_completed_at TEXT,
            approved_at TEXT,
            approved_by INTEGER,
            rejected_at TEXT,
            rejection_reason TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (role_id) REFERENCES roles(id)
        )
        """
    )

    conn.execute(
        """
        INSERT INTO users_new (
            id, prontuario, password_hash, name, role_id, employee_type,
            active, email,
            profile_image_filename, theme, ui_density, motion_enabled,
            account_status, onboarding_code_hash, onboarding_expires_at,
            onboarding_completed_at, approved_at, approved_by, rejected_at,
            rejection_reason, created_at
        )
        SELECT
            id, prontuario, password_hash, name, role_id, employee_type,
            active, email,
            profile_image_filename, theme, ui_density, motion_enabled,
            account_status, onboarding_code_hash, onboarding_expires_at,
            onboarding_completed_at, approved_at, approved_by, rejected_at,
            rejection_reason, created_at
        FROM users
        """
    )

    conn.execute("DROP TABLE users")
    conn.execute("ALTER TABLE users_new RENAME TO users")
    conn.commit()
    conn.execute("PRAGMA foreign_keys = ON")


def _migrate_existing_database(conn):
    # CREATE TABLE IF NOT EXISTS não adiciona colunas a tabelas antigas.
    user_columns = {
        "email": "TEXT",
        "profile_image_filename": "TEXT",
        "theme": "TEXT NOT NULL DEFAULT 'LIGHT'",
        "ui_density": "TEXT NOT NULL DEFAULT 'COMFORTABLE'",
        "motion_enabled": "INTEGER NOT NULL DEFAULT 1",
        "account_status": "TEXT NOT NULL DEFAULT 'ACTIVE'",
        "onboarding_code_hash": "TEXT",
        "onboarding_expires_at": "TEXT",
        "onboarding_completed_at": "TEXT",
        "approved_at": "TEXT",
        "approved_by": "INTEGER",
        "rejected_at": "TEXT",
        "rejection_reason": "TEXT",
    }

    for column, definition in user_columns.items():
        _ensure_column(conn, "users", column, definition)

    _rebuild_users_table(conn)

    student_profile_columns = {
        "email": "TEXT",
    }
    for column, definition in student_profile_columns.items():
        _ensure_column(conn, "student_profiles", column, definition)

    employee_profile_columns = {
        "education_level": "TEXT",
        "education_course": "TEXT",
        "education_institution": "TEXT",
        "professional_title": "TEXT",
        "specialties": "TEXT",
        "professional_bio": "TEXT",
    }
    for column, definition in employee_profile_columns.items():
        _ensure_column(conn, "employee_profiles", column, definition)

    _ensure_column(
        conn,
        "system_messages",
        "legacy_reception_message_id",
        "INTEGER"
    )
    _ensure_column(
        conn,
        "system_messages",
        "delivery_mode",
        "TEXT NOT NULL DEFAULT 'LEGACY'"
    )
    conn.execute(
        """
        CREATE UNIQUE INDEX IF NOT EXISTS idx_system_messages_legacy_reception
        ON system_messages(legacy_reception_message_id)
        WHERE legacy_reception_message_id IS NOT NULL
        """
    )
    conn.execute(
        """
        INSERT INTO system_messages (
            sender_id, target_group, subject, message, priority,
            legacy_reception_message_id, created_at
        )
        SELECT
            reception_messages.sender_id,
            CASE reception_messages.status WHEN 'SENT' THEN 'ADMIN' ELSE 'RECEPTION' END,
            CASE reception_messages.classification WHEN 'IMPORTANT' THEN 'Recado importante' ELSE 'Recado' END,
            reception_messages.message,
            CASE reception_messages.classification WHEN 'IMPORTANT' THEN 'HIGH' ELSE 'NORMAL' END,
            reception_messages.id,
            reception_messages.created_at
        FROM reception_messages
        WHERE NOT EXISTS (
            SELECT 1 FROM system_messages
            WHERE system_messages.legacy_reception_message_id = reception_messages.id
        )
        """
    )

    conn.execute(
        """
        INSERT OR IGNORE INTO system_message_recipients (message_id, user_id)
        SELECT messages.id, users.id
        FROM system_messages AS messages
        JOIN users
        JOIN roles ON roles.id = users.role_id
        WHERE messages.delivery_mode = 'LEGACY'
          AND users.active = 1
          AND users.id != messages.sender_id
          AND (
              (messages.target_group = 'ADMIN' AND roles.code IN ('OWNER', 'ADMIN'))
              OR (messages.target_group = 'RECEPTION' AND users.employee_type = 'RECEPTION')
              OR (messages.target_group = 'HR' AND users.employee_type = 'HR')
          )
          AND NOT EXISTS (
              SELECT 1
              FROM system_message_recipients existing
              WHERE existing.message_id = messages.id
          )
        """
    )

    plan_columns = {
        "duration_days": "INTEGER NOT NULL DEFAULT 0",
        "discount_percent": "REAL NOT NULL DEFAULT 0",
        "discount_start": "TEXT",
        "discount_end": "TEXT",
        "updated_at": "TEXT",
    }
    for column, definition in plan_columns.items():
        _ensure_column(conn, "plans", column, definition)

    exercise_columns = {
        "updated_at": "TEXT",
        "deleted_at": "TEXT",
        "deleted_by": "INTEGER",
        "deletion_reason": "TEXT",
    }
    for column, definition in exercise_columns.items():
        _ensure_column(conn, "exercises", column, definition)

    schedule_columns = {
        "break_start": "TEXT",
        "break_end": "TEXT",
        "shift_model": "TEXT NOT NULL DEFAULT 'STANDARD'",
    }
    for column, definition in schedule_columns.items():
        _ensure_column(conn, "work_schedules", column, definition)

    # Copia e-mails antigos de funcionários para o cadastro central de usuário.
    conn.execute(
        """
        UPDATE users
        SET email = (
            SELECT employee_profiles.email
            FROM employee_profiles
            WHERE employee_profiles.user_id = users.id
        )
        WHERE (email IS NULL OR TRIM(email) = '')
          AND EXISTS (
            SELECT 1
            FROM employee_profiles
            WHERE employee_profiles.user_id = users.id
              AND employee_profiles.email IS NOT NULL
              AND TRIM(employee_profiles.email) <> ''
          )
        """
    )

    conn.execute(
        """
        CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email_unique
        ON users(LOWER(email))
        WHERE email IS NOT NULL AND TRIM(email) <> ''
        """
    )

    # Usuários de versões anteriores continuam funcionando.
    conn.execute(
        """
        UPDATE users
        SET account_status = CASE
            WHEN active = 1 THEN 'ACTIVE'
            ELSE 'INACTIVE'
        END
        WHERE account_status IS NULL OR account_status = ''
        """
    )

    conn.execute(
        """
        UPDATE users
        SET account_status = 'INACTIVE'
        WHERE active = 0
          AND account_status = 'ACTIVE'
          AND onboarding_code_hash IS NULL
          AND onboarding_completed_at IS NULL
        """
    )

    # Compatibilidade com cadastros antigos que ficaram no status legado EMAIL_PENDING.
    conn.execute(
        """
        UPDATE subscriptions
        SET status = 'ACTIVE'
        WHERE status = 'PENDING'
          AND student_id IN (
              SELECT users.id
              FROM users
              JOIN roles ON roles.id = users.role_id
              WHERE roles.code = 'STUDENT'
                AND users.account_status = 'EMAIL_PENDING'
          )
        """
    )

    conn.execute(
        """
        UPDATE users
        SET account_status = 'ACTIVE',
            active = 1
        WHERE account_status = 'EMAIL_PENDING'
          AND role_id IN (SELECT id FROM roles WHERE code = 'STUDENT')
        """
    )

    conn.execute(
        """
        UPDATE users
        SET account_status = 'PENDING_APPROVAL',
            active = 0
        WHERE account_status = 'EMAIL_PENDING'
          AND role_id IN (SELECT id FROM roles WHERE code IN ('ADMIN', 'EMPLOYEE'))
        """
    )

    # Cria perfil básico para funcionários já existentes sem apagar dados.
    conn.execute(
        """
        INSERT OR IGNORE INTO employee_profiles (
            user_id,
            hire_date,
            weekly_hours,
            employment_type
        )
        SELECT
            users.id,
            DATE(users.created_at),
            44,
            'CLT'
        FROM users
        JOIN roles ON roles.id = users.role_id
        WHERE roles.code IN ('ADMIN', 'EMPLOYEE')
        """
    )


def init_db():
    conn = get_db()

    with open(SCHEMA_PATH, "r", encoding="utf-8") as file:
        conn.executescript(file.read())

    _migrate_existing_database(conn)

    conn.commit()
    conn.close()
