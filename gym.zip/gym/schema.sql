PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS roles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    prontuario TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    name TEXT NOT NULL,
    role_id INTEGER NOT NULL,

    employee_type TEXT CHECK (
        employee_type IS NULL OR employee_type IN (
            'PERSONAL',
            'CLEANING',
            'SECURITY',
            'RECEPTION',
            'HR'
        )
    ),

    active INTEGER NOT NULL DEFAULT 1,

    email TEXT,

    profile_image_filename TEXT,
    theme TEXT NOT NULL DEFAULT 'LIGHT'
    CHECK (theme IN ('LIGHT', 'DARK_YELLOW')),
    ui_density TEXT NOT NULL DEFAULT 'COMFORTABLE'
    CHECK (ui_density IN ('COMFORTABLE', 'COMPACT')),
    motion_enabled INTEGER NOT NULL DEFAULT 1,

    account_status TEXT NOT NULL DEFAULT 'ACTIVE'
    CHECK (
        account_status IN (
            'INVITED',
            'EMAIL_PENDING',
            'PENDING_APPROVAL',
            'ACTIVE',
            'INACTIVE',
            'REJECTED'
        )
    ),

    onboarding_code_hash TEXT,
    onboarding_expires_at TEXT,
    onboarding_completed_at TEXT,
    approved_at TEXT,
    approved_by INTEGER,
    rejected_at TEXT,
    rejection_reason TEXT,

    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (role_id)
        REFERENCES roles(id)
);

CREATE TABLE IF NOT EXISTS student_profiles (
    user_id INTEGER PRIMARY KEY,

    email TEXT,
    phone TEXT,
    birth_date TEXT,
    emergency_contact TEXT,

    FOREIGN KEY (user_id)
        REFERENCES users(id)
        ON DELETE CASCADE
);


CREATE TABLE IF NOT EXISTS employee_profiles (
    user_id INTEGER PRIMARY KEY,

    cpf TEXT UNIQUE,
    email TEXT,
    phone TEXT,
    birth_date TEXT,

    education_level TEXT CHECK (
        education_level IS NULL OR education_level IN (
            'BASIC',
            'HIGH_SCHOOL',
            'TECHNICAL',
            'SUPERIOR_IN_PROGRESS',
            'SUPERIOR_COMPLETE',
            'POSTGRADUATE'
        )
    ),
    education_course TEXT,
    education_institution TEXT,

    zip_code TEXT,
    address TEXT,
    address_number TEXT,
    complement TEXT,
    neighborhood TEXT,
    city TEXT,
    state TEXT,

    emergency_contact TEXT,
    emergency_phone TEXT,

    hire_date TEXT,
    base_salary_cents INTEGER NOT NULL DEFAULT 0,
    weekly_hours REAL NOT NULL DEFAULT 44,
    employment_type TEXT NOT NULL DEFAULT 'CLT'
    CHECK (
        employment_type IN (
            'CLT',
            'TEMPORARY',
            'INTERN',
            'SERVICE_PROVIDER'
        )
    ),
    dependents_count INTEGER NOT NULL DEFAULT 0,
    professional_title TEXT,
    specialties TEXT,
    professional_bio TEXT,
    notes TEXT,
    profile_completed_at TEXT,

    FOREIGN KEY (user_id)
        REFERENCES users(id)
        ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_employee_profiles_cpf
ON employee_profiles(cpf);

CREATE TABLE IF NOT EXISTS plans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    name TEXT NOT NULL,
    description TEXT,

    duration_months INTEGER NOT NULL,
    duration_days INTEGER NOT NULL DEFAULT 0,

    price_cents INTEGER NOT NULL,

    cancellation_fee_percent REAL NOT NULL DEFAULT 0,
    discount_percent REAL NOT NULL DEFAULT 0,
    discount_start TEXT,
    discount_end TEXT,

    active INTEGER NOT NULL DEFAULT 1,
    updated_at TEXT
);

CREATE TABLE IF NOT EXISTS subscriptions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    student_id INTEGER NOT NULL,
    plan_id INTEGER NOT NULL,

    start_date TEXT NOT NULL,
    end_date TEXT NOT NULL,

    status TEXT NOT NULL DEFAULT 'ACTIVE'
    CHECK (
        status IN (
            'ACTIVE',
            'CANCELED',
            'EXPIRED',
            'PENDING'
        )
    ),

    contracted_channel TEXT NOT NULL DEFAULT 'PRESENTIAL'
    CHECK (
        contracted_channel IN (
            'PRESENTIAL',
            'ONLINE'
        )
    ),

    canceled_at TEXT,
    cancellation_reason TEXT,

    refund_cents INTEGER NOT NULL DEFAULT 0,

    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (student_id)
        REFERENCES users(id),

    FOREIGN KEY (plan_id)
        REFERENCES plans(id)
);

CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    student_id INTEGER NOT NULL,
    subscription_id INTEGER NOT NULL,

    amount_cents INTEGER NOT NULL,

    due_date TEXT NOT NULL,

    paid_at TEXT,

    status TEXT NOT NULL DEFAULT 'PENDING'
    CHECK (
        status IN (
            'PENDING',
            'PAID',
            'OVERDUE',
            'CANCELED',
            'REFUNDED'
        )
    ),

    payment_method TEXT CHECK (
        payment_method IS NULL OR payment_method IN (
            'SIMULATED_DIGITAL',
            'CASH',
            'PIX',
            'CARD',
            'OTHER'
        )
    ),

    payment_origin TEXT CHECK (
        payment_origin IS NULL OR payment_origin IN (
            'STUDENT',
            'ADMIN',
            'RECEPTION'
        )
    ),

    registered_by INTEGER,

    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (student_id)
        REFERENCES users(id),

    FOREIGN KEY (subscription_id)
        REFERENCES subscriptions(id),

    FOREIGN KEY (registered_by)
        REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS exercises (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    muscle_group TEXT NOT NULL,
    image_filename TEXT,
    instructions TEXT,
    active INTEGER NOT NULL DEFAULT 1,
    created_by INTEGER,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT,
    deleted_at TEXT,
    deleted_by INTEGER,
    deletion_reason TEXT,

    FOREIGN KEY (created_by)
        REFERENCES users(id),

    FOREIGN KEY (deleted_by)
        REFERENCES users(id)
);

CREATE INDEX IF NOT EXISTS idx_exercises_active_name
ON exercises(active, name);

CREATE TABLE IF NOT EXISTS exercise_audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    exercise_id INTEGER NOT NULL,
    action TEXT NOT NULL CHECK (
        action IN ('CREATED', 'UPDATED', 'DELETED', 'RESTORED')
    ),
    performed_by INTEGER,
    details TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (exercise_id) REFERENCES exercises(id),
    FOREIGN KEY (performed_by) REFERENCES users(id)
);

CREATE INDEX IF NOT EXISTS idx_exercise_audit_exercise
ON exercise_audit_log(exercise_id, created_at);

CREATE TABLE IF NOT EXISTS workout_plans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL,
    personal_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    objective TEXT,
    notes TEXT,
    status TEXT NOT NULL DEFAULT 'ACTIVE'
    CHECK (status IN ('ACTIVE', 'ARCHIVED')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    assigned_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (student_id)
        REFERENCES users(id)
        ON DELETE CASCADE,

    FOREIGN KEY (personal_id)
        REFERENCES users(id)
);

CREATE INDEX IF NOT EXISTS idx_workout_plans_student_status
ON workout_plans(student_id, status);

CREATE TABLE IF NOT EXISTS workout_days (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    workout_plan_id INTEGER NOT NULL,
    day_name TEXT NOT NULL,
    position INTEGER NOT NULL DEFAULT 0,

    FOREIGN KEY (workout_plan_id)
        REFERENCES workout_plans(id)
        ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS workout_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    workout_day_id INTEGER NOT NULL,
    exercise_id INTEGER NOT NULL,
    sets INTEGER,
    reps TEXT,
    load_text TEXT,
    rest_seconds INTEGER,
    notes TEXT,
    position INTEGER NOT NULL DEFAULT 0,

    FOREIGN KEY (workout_day_id)
        REFERENCES workout_days(id)
        ON DELETE CASCADE,

    FOREIGN KEY (exercise_id)
        REFERENCES exercises(id)
);

CREATE TABLE IF NOT EXISTS workout_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    workout_day_id INTEGER NOT NULL,
    student_id INTEGER NOT NULL,
    session_date TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'IN_PROGRESS'
    CHECK (status IN ('IN_PROGRESS', 'COMPLETED')),
    started_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    finished_at TEXT,

    UNIQUE (workout_day_id, student_id, session_date),

    FOREIGN KEY (workout_day_id)
        REFERENCES workout_days(id)
        ON DELETE CASCADE,

    FOREIGN KEY (student_id)
        REFERENCES users(id)
        ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS workout_item_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL,
    workout_item_id INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'PENDING'
    CHECK (status IN ('PENDING', 'DONE', 'SKIPPED')),
    completed_at TEXT,

    UNIQUE (session_id, workout_item_id),

    FOREIGN KEY (session_id)
        REFERENCES workout_sessions(id)
        ON DELETE CASCADE,

    FOREIGN KEY (workout_item_id)
        REFERENCES workout_items(id)
        ON DELETE CASCADE
);

-- Mantida apenas para compatibilidade com versões antigas. Novas fichas usam
-- workout_plans/workout_days/workout_items.
CREATE TABLE IF NOT EXISTS workout_files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    student_id INTEGER NOT NULL,
    personal_id INTEGER NOT NULL,

    original_filename TEXT NOT NULL,
    stored_filename TEXT NOT NULL,
    file_path TEXT NOT NULL,

    uploaded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (student_id)
        REFERENCES users(id),

    FOREIGN KEY (personal_id)
        REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS warnings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    student_id INTEGER NOT NULL,
    personal_id INTEGER NOT NULL,

    message TEXT NOT NULL,

    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (student_id)
        REFERENCES users(id),

    FOREIGN KEY (personal_id)
        REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS work_schedules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    employee_id INTEGER NOT NULL,

    work_date TEXT NOT NULL,

    shift_start TEXT,
    shift_end TEXT,
    break_start TEXT,
    break_end TEXT,

    shift_model TEXT NOT NULL DEFAULT 'STANDARD'
    CHECK (
        shift_model IN (
            'STANDARD',
            'TWELVE_BY_THIRTY_SIX'
        )
    ),

    schedule_type TEXT NOT NULL DEFAULT 'WORK'
    CHECK (
        schedule_type IN (
            'WORK',
            'DAY_OFF',
            'VACATION',
            'LEAVE'
        )
    ),

    notes TEXT,

    created_by INTEGER NOT NULL,

    FOREIGN KEY (employee_id)
        REFERENCES users(id),

    FOREIGN KEY (created_by)
        REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS cleaning_tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    title TEXT NOT NULL,

    description TEXT,

    assigned_to INTEGER NOT NULL,

    created_by INTEGER NOT NULL,

    due_date TEXT,

    status TEXT NOT NULL DEFAULT 'PENDING'
    CHECK (
        status IN (
            'PENDING',
            'IN_PROGRESS',
            'COMPLETED'
        )
    ),

    completed_at TEXT,

    FOREIGN KEY (assigned_to)
        REFERENCES users(id),

    FOREIGN KEY (created_by)
        REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS hr_reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    reporter_id INTEGER NOT NULL,
    category TEXT NOT NULL CHECK (
        category IN (
            'CONFLICT', 'CONDUCT', 'WORK_CONDITION', 'SCHEDULE',
            'HARASSMENT', 'REQUEST', 'SUGGESTION', 'OTHER'
        )
    ),
    subject TEXT NOT NULL,
    description TEXT NOT NULL,
    involved_user_id INTEGER,
    confidential INTEGER NOT NULL DEFAULT 1,
    status TEXT NOT NULL DEFAULT 'OPEN' CHECK (
        status IN ('OPEN', 'IN_REVIEW', 'RESOLVED', 'DISMISSED')
    ),
    hr_notes TEXT,
    handled_by INTEGER,
    handled_at TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (reporter_id) REFERENCES users(id),
    FOREIGN KEY (involved_user_id) REFERENCES users(id),
    FOREIGN KEY (handled_by) REFERENCES users(id)
);

CREATE INDEX IF NOT EXISTS idx_hr_reports_status_created
ON hr_reports(status, created_at);

CREATE TABLE IF NOT EXISTS security_reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    security_id INTEGER NOT NULL,

    subject TEXT NOT NULL,

    description TEXT NOT NULL,

    severity TEXT NOT NULL DEFAULT 'LOW'
    CHECK (
        severity IN (
            'LOW',
            'MEDIUM',
            'HIGH',
            'CRITICAL'
        )
    ),

    status TEXT NOT NULL DEFAULT 'OPEN'
    CHECK (
        status IN (
            'OPEN',
            'REVIEWING',
            'RESOLVED'
        )
    ),

    reviewed_by INTEGER,

    reviewed_at TEXT,

    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (security_id)
        REFERENCES users(id),

    FOREIGN KEY (reviewed_by)
        REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS security_report_involved (
    report_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,

    PRIMARY KEY (report_id, user_id),

    FOREIGN KEY (report_id)
        REFERENCES security_reports(id)
        ON DELETE CASCADE,

    FOREIGN KEY (user_id)
        REFERENCES users(id)
        ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_security_report_involved_user
ON security_report_involved(user_id);

CREATE TABLE IF NOT EXISTS reception_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    sender_id INTEGER NOT NULL,

    message TEXT NOT NULL,

    status TEXT NOT NULL DEFAULT 'PENDING'
    CHECK (
        status IN (
            'PENDING',
            'SENT'
        )
    ),

    classification TEXT CHECK (
        classification IS NULL OR classification IN (
            'IMPORTANT',
            'SECONDARY'
        )
    ),

    forwarded_by INTEGER,
    forwarded_at TEXT,

    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (sender_id)
        REFERENCES users(id),

    FOREIGN KEY (forwarded_by)
        REFERENCES users(id)
);

CREATE INDEX IF NOT EXISTS idx_reception_messages_status
ON reception_messages(status);


CREATE TABLE IF NOT EXISTS system_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sender_id INTEGER NOT NULL,
    target_group TEXT NOT NULL CHECK (
        target_group IN ('ADMIN', 'RECEPTION', 'HR')
    ),
    subject TEXT NOT NULL,
    message TEXT NOT NULL,
    priority TEXT NOT NULL DEFAULT 'NORMAL' CHECK (
        priority IN ('NORMAL', 'HIGH')
    ),
    delivery_mode TEXT NOT NULL DEFAULT 'LEGACY' CHECK (
        delivery_mode IN ('LEGACY', 'SPECIFIC', 'ALL')
    ),
    legacy_reception_message_id INTEGER,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (sender_id) REFERENCES users(id)
);

CREATE INDEX IF NOT EXISTS idx_system_messages_target_created
ON system_messages(target_group, created_at);

CREATE TABLE IF NOT EXISTS system_message_recipients (
    message_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (message_id, user_id),
    FOREIGN KEY (message_id) REFERENCES system_messages(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_system_message_recipients_user
ON system_message_recipients(user_id, message_id);

CREATE TABLE IF NOT EXISTS system_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_type TEXT NOT NULL,
    actor_id INTEGER,
    target_user_id INTEGER,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (actor_id) REFERENCES users(id),
    FOREIGN KEY (target_user_id) REFERENCES users(id)
);

CREATE INDEX IF NOT EXISTS idx_system_events_type_created
ON system_events(event_type, created_at);

CREATE TABLE IF NOT EXISTS cleaning_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    requester_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    location TEXT,
    description TEXT,
    priority TEXT NOT NULL DEFAULT 'NORMAL' CHECK (
        priority IN ('NORMAL', 'HIGH')
    ),
    status TEXT NOT NULL DEFAULT 'PENDING' CHECK (
        status IN ('PENDING', 'IN_PROGRESS', 'COMPLETED', 'CANCELED')
    ),
    assigned_to INTEGER,
    assigned_at TEXT,
    completed_at TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (requester_id) REFERENCES users(id),
    FOREIGN KEY (assigned_to) REFERENCES users(id)
);

CREATE INDEX IF NOT EXISTS idx_cleaning_requests_status_created
ON cleaning_requests(status, created_at);

CREATE TABLE IF NOT EXISTS notification_reads (
    user_id INTEGER NOT NULL,
    source_type TEXT NOT NULL,
    source_id INTEGER NOT NULL,
    read_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (user_id, source_type, source_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS time_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER NOT NULL,
    work_date TEXT NOT NULL,

    clock_in TEXT,
    break_out TEXT,
    break_in TEXT,
    clock_out TEXT,

    worked_minutes INTEGER NOT NULL DEFAULT 0,
    expected_minutes INTEGER NOT NULL DEFAULT 0,
    overtime_minutes INTEGER NOT NULL DEFAULT 0,
    shortfall_minutes INTEGER NOT NULL DEFAULT 0,

    status TEXT NOT NULL DEFAULT 'OPEN'
    CHECK (
        status IN (
            'OPEN',
            'PENDING',
            'APPROVED',
            'ADJUSTED'
        )
    ),

    notes TEXT,
    approved_by INTEGER,
    approved_at TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    UNIQUE (employee_id, work_date),

    FOREIGN KEY (employee_id)
        REFERENCES users(id)
        ON DELETE CASCADE,

    FOREIGN KEY (approved_by)
        REFERENCES users(id)
);

CREATE INDEX IF NOT EXISTS idx_time_entries_employee_date
ON time_entries(employee_id, work_date);

CREATE TABLE IF NOT EXISTS leave_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER NOT NULL,

    leave_type TEXT NOT NULL
    CHECK (
        leave_type IN (
            'VACATION',
            'MEDICAL',
            'PERSONAL',
            'OTHER'
        )
    ),

    start_date TEXT NOT NULL,
    end_date TEXT NOT NULL,
    total_days INTEGER NOT NULL,
    reason TEXT,

    status TEXT NOT NULL DEFAULT 'PENDING'
    CHECK (
        status IN (
            'PENDING',
            'APPROVED',
            'REJECTED',
            'CANCELED'
        )
    ),

    admin_notes TEXT,
    reviewed_by INTEGER,
    reviewed_at TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (employee_id)
        REFERENCES users(id)
        ON DELETE CASCADE,

    FOREIGN KEY (reviewed_by)
        REFERENCES users(id)
);

CREATE INDEX IF NOT EXISTS idx_leave_requests_status
ON leave_requests(status);

CREATE TABLE IF NOT EXISTS payrolls (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER NOT NULL,
    reference_month TEXT NOT NULL,

    payroll_type TEXT NOT NULL DEFAULT 'MONTHLY'
    CHECK (
        payroll_type IN (
            'MONTHLY'
        )
    ),

    base_salary_cents INTEGER NOT NULL DEFAULT 0,
    monthly_hours REAL NOT NULL DEFAULT 220,

    overtime_minutes INTEGER NOT NULL DEFAULT 0,
    overtime_percent REAL NOT NULL DEFAULT 50,
    overtime_cents INTEGER NOT NULL DEFAULT 0,

    shortfall_minutes INTEGER NOT NULL DEFAULT 0,
    absence_discount_cents INTEGER NOT NULL DEFAULT 0,

    bonus_cents INTEGER NOT NULL DEFAULT 0,
    other_earnings_cents INTEGER NOT NULL DEFAULT 0,
    other_deductions_cents INTEGER NOT NULL DEFAULT 0,

    gross_cents INTEGER NOT NULL DEFAULT 0,
    inss_cents INTEGER NOT NULL DEFAULT 0,
    irrf_cents INTEGER NOT NULL DEFAULT 0,
    fgts_cents INTEGER NOT NULL DEFAULT 0,
    net_cents INTEGER NOT NULL DEFAULT 0,

    status TEXT NOT NULL DEFAULT 'CLOSED'
    CHECK (
        status IN (
            'DRAFT',
            'CLOSED',
            'PAID'
        )
    ),

    created_by INTEGER NOT NULL,
    paid_at TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    UNIQUE (employee_id, reference_month, payroll_type),

    FOREIGN KEY (employee_id)
        REFERENCES users(id)
        ON DELETE CASCADE,

    FOREIGN KEY (created_by)
        REFERENCES users(id)
);

CREATE INDEX IF NOT EXISTS idx_payrolls_reference_month
ON payrolls(reference_month);



-- STUDENT_ACTIVITY_GROUPS_V1
-- Grupos esportivos criados e utilizados somente por alunos pela camada da aplicação.
CREATE TABLE IF NOT EXISTS activity_groups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    group_type TEXT NOT NULL
    CHECK (group_type IN ('RUNNING', 'SWIMMING', 'CYCLING')),
    description TEXT,
    created_by INTEGER NOT NULL,
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (created_by)
        REFERENCES users(id)
        ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_activity_groups_type_active
ON activity_groups(group_type, active, created_at);

CREATE TABLE IF NOT EXISTS activity_group_members (
    group_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    member_role TEXT NOT NULL DEFAULT 'MEMBER'
    CHECK (member_role IN ('ADMIN', 'MEMBER')),
    joined_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (group_id, user_id),

    FOREIGN KEY (group_id)
        REFERENCES activity_groups(id)
        ON DELETE CASCADE,

    FOREIGN KEY (user_id)
        REFERENCES users(id)
        ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_activity_group_members_user
ON activity_group_members(user_id, joined_at);

CREATE TABLE IF NOT EXISTS activity_group_activities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    activity_date TEXT NOT NULL,
    distance_km REAL NOT NULL CHECK (distance_km > 0),
    duration_minutes INTEGER NOT NULL CHECK (duration_minutes > 0),
    notes TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (group_id)
        REFERENCES activity_groups(id)
        ON DELETE CASCADE,

    FOREIGN KEY (user_id)
        REFERENCES users(id)
        ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_activity_group_activities_week
ON activity_group_activities(group_id, activity_date, user_id);

CREATE TABLE IF NOT EXISTS activity_group_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id INTEGER NOT NULL,
    sender_id INTEGER NOT NULL,
    message TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (group_id)
        REFERENCES activity_groups(id)
        ON DELETE CASCADE,

    FOREIGN KEY (sender_id)
        REFERENCES users(id)
        ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_activity_group_messages_group
ON activity_group_messages(group_id, created_at, id);
