# Bases do módulo de RH

Este módulo foi construído para fins escolares e simula rotinas de RH usando regras gerais brasileiras. Ele não substitui folha contábil, eSocial, orientação jurídica ou convenção/acordo coletivo.

## Regras gerais refletidas

- Jornada normal: até 8 horas diárias e 44 horas semanais.
- Hora extra: adicional mínimo de 50% sobre a hora normal.
- Jornada padrão: o sistema bloqueia mais de 10 horas trabalhadas no dia; 12x36 é tratada separadamente.
- Descanso entre jornadas: referência de 11 horas consecutivas.
- Controle de ponto: a legislação obriga marcação em estabelecimentos com mais de 20 trabalhadores; o projeto permite usar ponto independentemente do tamanho da academia.
- Férias: período aquisitivo inicial de 12 meses; regra geral de 30 dias, com fracionamento em até três períodos mediante condições legais (um período >=14 dias e demais >=5 dias).
- FGTS: 8% da remuneração para empregado comum; aparece como encargo do empregador e não como desconto do salário líquido.
- INSS 2026: cálculo progressivo com faixas oficiais vigentes desde janeiro/2026.
- IRRF 2026: tabela mensal e redução mensal vigentes em 2026.

## Fontes oficiais consultadas

- CLT compilada: https://www.planalto.gov.br/ccivil_03/decreto-lei/del5452compilado.htm
- Ministério do Trabalho e Emprego - Perguntas Frequentes: https://www.gov.br/trabalho-e-emprego/pt-br/acesso-a-informacao/perguntas-frequentes
- INSS - Tabela de contribuição mensal: https://www.gov.br/inss/pt-br/direitos-e-deveres/inscricao-e-contribuicao/tabela-de-contribuicao-mensal
- Receita Federal - Tributação de 2026: https://www.gov.br/receitafederal/pt-br/assuntos/meu-imposto-de-renda/tabelas/2026
- MTE - FGTS: https://www.gov.br/trabalho-e-emprego/pt-br/assuntos/inspecao-do-trabalho/areas-de-atuacao/fgts-fundo-de-garantia-do-tempo-de-servico
- eSocial - Manual WEB Geral: https://www.gov.br/esocial/pt-br/empresas/manual-web-geral


## Perfil de Recursos Humanos (RH)

- Tipo de funcionário no sistema: `HR` — Analista de Recursos Humanos.
- Referência ocupacional: CBO 2524-05 (Profissionais de Recursos Humanos / Analista de Recursos Humanos). A descrição oficial abrange administração de pessoal, cargos e salários, recrutamento e seleção, treinamento, benefícios, relações de trabalho e avaliação de desempenho.
- Formação: a referência CBO informa ensino superior para o exercício da ocupação. O projeto, portanto, exige `SUPERIOR_COMPLETE` ou `POSTGRADUATE` no primeiro acesso de contas HR.
- Salário-base sugerido no projeto: R$ 4.400,00. A referência consultada em 03/09/2026 indicava média nacional de R$ 4.416,46/mês (Portal Salário, dados CAGED 08/2025–07/2026). É apenas valor inicial e não piso obrigatório.
- Permissões: admitir e aprovar funcionários EMPLOYEE, gerir escalas, ponto, férias/afastamentos e preparar folha.
- Restrições: não administra OWNER/ADMIN, não acessa alunos/financeiro de alunos, treinos, limpeza ou ocorrências de segurança; não confirma pagamento de folha; não administra a própria conta/escala/ponto/folha pelas telas gerenciais.

Fontes específicas do perfil RH:
- MTE / CBO 2524-05: https://www.gov.br/trabalho-e-emprego/pt-br/assuntos/cbo/servicos/downloads/livro-1-portal-cbo.pdf
- eSocial / Manual Web Geral: https://www.gov.br/esocial/pt-br/empresas/manual-web-geral
- Portal Salário / Analista de RH (consulta de 03/09/2026): https://www.salario.com.br/profissao/analista-de-recursos-humanos-cbo-252405/
