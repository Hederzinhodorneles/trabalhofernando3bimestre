(() => {
    document.querySelectorAll('[data-directory]').forEach((toolbar) => {
        const scope = toolbar.parentElement;
        const search = toolbar.querySelector('[data-directory-search]');
        const filters = [...toolbar.querySelectorAll('[data-directory-filter]')];
        const rows = [...scope.querySelectorAll('[data-directory-row]')];
        const empty = scope.querySelector('[data-directory-empty]');

        const apply = () => {
            const query = (search?.value || '').trim().toLowerCase();
            let visible = 0;

            rows.forEach((row) => {
                const matchesSearch = !query || (row.dataset.search || '').includes(query);
                const matchesFilters = filters.every((control) => {
                    const value = control.value;
                    if (!value) return true;
                    const key = control.dataset.directoryFilter;
                    return (row.dataset[key] || '') === value;
                });
                const show = matchesSearch && matchesFilters;
                row.hidden = !show;
                if (show) visible += 1;
            });

            if (empty) empty.hidden = visible !== 0;
        };

        search?.addEventListener('input', apply);
        filters.forEach((control) => control.addEventListener('change', apply));
        apply();
    });
})();
