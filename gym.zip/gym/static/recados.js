document.addEventListener('DOMContentLoaded', () => {
    const picker = document.querySelector('[data-recipient-picker]');
    if (!picker) return;

    const search = picker.querySelector('[data-recipient-search]');
    const all = picker.querySelector('[data-recipient-all]');
    const items = [...picker.querySelectorAll('[data-recipient-item]')];
    const boxes = [...picker.querySelectorAll('[data-recipient-checkbox]')];

    const syncAll = () => {
        const active = all.checked;
        boxes.forEach((box) => {
            box.checked = active;
            box.disabled = active;
        });
        picker.classList.toggle('all-selected', active);
    };

    all.addEventListener('change', syncAll);

    search.addEventListener('input', () => {
        const term = search.value.trim().toLowerCase();
        items.forEach((item) => {
            item.hidden = term && !item.dataset.search.includes(term);
        });
    });

    syncAll();
});
