(() => {
    const search = document.getElementById('studentSearch');
    const filter = document.getElementById('studentPlanFilter');
    const rows = [...document.querySelectorAll('.student-list-row')];
    const empty = document.getElementById('studentFilterEmpty');
    function apply() {
        const q = (search?.value || '').trim().toLowerCase();
        const plan = filter?.value || '';
        let visible = 0;
        rows.forEach(row => {
            const matchesText = !q || row.dataset.name.includes(q) || row.dataset.prontuario.includes(q);
            const matchesPlan = !plan || row.dataset.plan === plan;
            const show = matchesText && matchesPlan;
            row.hidden = !show;
            if (show) visible++;
        });
        if (empty) empty.hidden = visible !== 0 || rows.length === 0;
    }
    search?.addEventListener('input', apply);
    filter?.addEventListener('change', apply);
})();
