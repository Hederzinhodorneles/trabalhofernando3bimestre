(() => {
    const form = document.getElementById('interface-settings-form');
    if (!form) return;

    const body = document.body;
    const state = document.getElementById('settings-state');
    const themeLabel = document.getElementById('theme-current-label');
    const initial = new FormData(form);
    const originalTheme = initial.get('theme');
    const originalDensity = initial.get('ui_density');
    const originalMotion = initial.get('motion_enabled') === '1';

    const markChanged = () => {
        if (state) state.classList.add('is-visible');
    };

    const updateTheme = () => {
        const selected = form.querySelector('input[name="theme"]:checked');
        if (!selected) return;
        const dark = selected.value === 'DARK_YELLOW';
        body.classList.toggle('theme-dark-yellow', dark);
        document.querySelectorAll('.theme-choice').forEach((choice) => {
            choice.classList.toggle('is-selected', choice.contains(selected));
        });
        if (themeLabel) themeLabel.textContent = dark ? 'Grafite e dourado' : 'Claro';
    };

    const updateDensity = () => {
        const selected = form.querySelector('input[name="ui_density"]:checked');
        if (!selected) return;
        body.classList.toggle('ui-density-compact', selected.value === 'COMPACT');
        form.querySelectorAll('[data-segmented] label').forEach((label) => {
            const radio = label.querySelector('input');
            label.classList.toggle('active', radio && radio.checked);
        });
    };

    const updateMotion = () => {
        const enabled = form.querySelector('input[name="motion_enabled"]');
        body.classList.toggle('ui-no-motion', enabled && !enabled.checked);
    };

    form.querySelectorAll('input[name="theme"]').forEach((input) => input.addEventListener('change', () => {
        updateTheme();
        markChanged();
    }));

    form.querySelectorAll('input[name="ui_density"]').forEach((input) => input.addEventListener('change', () => {
        updateDensity();
        markChanged();
    }));

    const motion = form.querySelector('input[name="motion_enabled"]');
    if (motion) motion.addEventListener('change', () => {
        updateMotion();
        markChanged();
    });

    window.addEventListener('beforeunload', () => {
        const currentTheme = form.querySelector('input[name="theme"]:checked')?.value;
        const currentDensity = form.querySelector('input[name="ui_density"]:checked')?.value;
        const currentMotion = !!form.querySelector('input[name="motion_enabled"]')?.checked;
        if (!form.dataset.submitting && (currentTheme !== originalTheme || currentDensity !== originalDensity || currentMotion !== originalMotion)) {
            body.classList.toggle('theme-dark-yellow', originalTheme === 'DARK_YELLOW');
            body.classList.toggle('ui-density-compact', originalDensity === 'COMPACT');
            body.classList.toggle('ui-no-motion', !originalMotion);
        }
    });

    form.addEventListener('submit', () => {
        form.dataset.submitting = '1';
    });
})();
