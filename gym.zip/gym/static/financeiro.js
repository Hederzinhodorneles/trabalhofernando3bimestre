(() => {
    const dataNode = document.getElementById('financeData');
    if (!dataNode) return;

    const data = JSON.parse(dataNode.textContent || '{}');
    const css = getComputedStyle(document.body);
    const dark = document.body.classList.contains('theme-dark-yellow');
    const palette = dark
        ? ['#f4c400', '#f0f0f0', '#818893', '#b55a5a', '#6f7782', '#c69c00']
        : ['#242a31', '#68707a', '#a7adb5', '#b24b4b', '#d6d9de', '#8b6c00'];
    const grid = dark ? '#34373c' : '#e7e9ed';
    const text = dark ? '#e8e8e8' : '#4f5660';

    function money(value) {
        return new Intl.NumberFormat('pt-BR', {style: 'currency', currency: 'BRL'}).format(value || 0);
    }

    function setupCanvas(canvas, height = 260) {
        if (!canvas) return null;
        const ratio = window.devicePixelRatio || 1;
        const width = Math.max(canvas.clientWidth, 280);
        canvas.width = width * ratio;
        canvas.height = height * ratio;
        const ctx = canvas.getContext('2d');
        ctx.scale(ratio, ratio);
        return {ctx, width, height};
    }

    function emptyState(ctx, width, height) {
        ctx.fillStyle = text;
        ctx.font = '14px system-ui';
        ctx.textAlign = 'center';
        ctx.fillText('Sem dados no período', width / 2, height / 2);
    }

    function drawLine(canvas, labels, values) {
        const state = setupCanvas(canvas, 280);
        if (!state) return;
        const {ctx, width, height} = state;
        if (!values.length || values.every(v => !v)) return emptyState(ctx, width, height);
        const pad = {left: 58, right: 20, top: 24, bottom: 48};
        const innerW = width - pad.left - pad.right;
        const innerH = height - pad.top - pad.bottom;
        const max = Math.max(...values, 1) * 1.12;
        ctx.font = '12px system-ui';
        ctx.strokeStyle = grid;
        ctx.fillStyle = text;
        ctx.textAlign = 'right';
        for (let i = 0; i <= 4; i++) {
            const y = pad.top + (innerH * i / 4);
            const v = max * (1 - i / 4);
            ctx.beginPath(); ctx.moveTo(pad.left, y); ctx.lineTo(width - pad.right, y); ctx.stroke();
            ctx.fillText(money(v).replace(',00', ''), pad.left - 8, y + 4);
        }
        const step = labels.length > 1 ? innerW / (labels.length - 1) : innerW;
        const points = values.map((v, i) => ({x: pad.left + (labels.length > 1 ? i * step : innerW / 2), y: pad.top + innerH - (v / max) * innerH}));
        const grad = ctx.createLinearGradient(0, pad.top, 0, pad.top + innerH);
        grad.addColorStop(0, dark ? 'rgba(244,196,0,.28)' : 'rgba(36,42,49,.18)');
        grad.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.beginPath();
        ctx.moveTo(points[0].x, pad.top + innerH);
        points.forEach((p, i) => i ? ctx.lineTo(p.x, p.y) : ctx.lineTo(p.x, p.y));
        ctx.lineTo(points[points.length - 1].x, pad.top + innerH);
        ctx.closePath(); ctx.fillStyle = grad; ctx.fill();
        ctx.beginPath();
        points.forEach((p, i) => i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y));
        ctx.strokeStyle = palette[0]; ctx.lineWidth = 3; ctx.stroke();
        points.forEach(p => {ctx.beginPath(); ctx.arc(p.x, p.y, 4, 0, Math.PI * 2); ctx.fillStyle = palette[0]; ctx.fill();});
        ctx.fillStyle = text; ctx.textAlign = 'center';
        const labelEvery = labels.length > 8 ? 2 : 1;
        labels.forEach((label, i) => {if (i % labelEvery === 0 || i === labels.length - 1) ctx.fillText(label, points[i].x, height - 18);});
    }

    function drawDonut(canvas, labels, values, legend) {
        const state = setupCanvas(canvas, 220);
        if (!state) return;
        const {ctx, width, height} = state;
        const total = values.reduce((a, b) => a + b, 0);
        if (!total) return emptyState(ctx, width, height);
        const cx = width / 2, cy = height / 2, radius = Math.min(width, height) * .34;
        let start = -Math.PI / 2;
        values.forEach((value, i) => {
            const angle = (value / total) * Math.PI * 2;
            ctx.beginPath(); ctx.arc(cx, cy, radius, start, start + angle); ctx.arc(cx, cy, radius * .58, start + angle, start, true); ctx.closePath();
            ctx.fillStyle = palette[i % palette.length]; ctx.fill(); start += angle;
        });
        ctx.fillStyle = text; ctx.textAlign = 'center'; ctx.font = '700 16px system-ui'; ctx.fillText(money(total), cx, cy + 3);
        ctx.font = '12px system-ui'; ctx.fillText('total', cx, cy + 22);
        if (legend) {
            legend.innerHTML = labels.map((label, i) => `<span><i style="background:${palette[i % palette.length]}"></i>${label}<strong>${money(values[i])}</strong></span>`).join('');
        }
    }

    function drawBars(canvas, labels, values) {
        const state = setupCanvas(canvas, 230);
        if (!state) return;
        const {ctx, width, height} = state;
        if (!values.length || values.every(v => !v)) return emptyState(ctx, width, height);
        const pad = {left: 16, right: 16, top: 20, bottom: 56};
        const innerW = width - pad.left - pad.right;
        const innerH = height - pad.top - pad.bottom;
        const max = Math.max(...values, 1);
        const slot = innerW / values.length;
        const barW = Math.min(54, slot * .62);
        values.forEach((value, i) => {
            const h = (value / max) * innerH;
            const x = pad.left + slot * i + (slot - barW) / 2;
            const y = pad.top + innerH - h;
            ctx.fillStyle = palette[i % palette.length];
            ctx.fillRect(x, y, barW, h);
            ctx.fillStyle = text; ctx.font = '11px system-ui'; ctx.textAlign = 'center';
            ctx.fillText(money(value).replace(',00', ''), x + barW / 2, Math.max(12, y - 7));
            const label = labels[i].length > 12 ? labels[i].slice(0, 11) + '…' : labels[i];
            ctx.fillText(label, x + barW / 2, height - 24);
        });
    }

    const monthly = document.getElementById('monthlyRevenueChart');
    const status = document.getElementById('paymentStatusChart');
    const methods = document.getElementById('paymentMethodChart');
    const plans = document.getElementById('planRevenueChart');
    const legend = document.getElementById('paymentStatusLegend');
    let monthlySeries = 'received';

    function render() {
        drawLine(monthly, data.monthly?.labels || [], data.monthly?.[monthlySeries] || []);
        drawDonut(status, data.status?.labels || [], data.status?.values || [], legend);
        drawBars(methods, data.methods?.labels || [], data.methods?.values || []);
        drawBars(plans, data.plans?.labels || [], data.plans?.values || []);
    }

    document.querySelectorAll('[data-chart-switch="monthly"] button').forEach(button => {
        button.addEventListener('click', () => {
            monthlySeries = button.dataset.series;
            document.querySelectorAll('[data-chart-switch="monthly"] button').forEach(b => b.classList.toggle('active', b === button));
            drawLine(monthly, data.monthly?.labels || [], data.monthly?.[monthlySeries] || []);
        });
    });

    let resizeTimer;
    window.addEventListener('resize', () => {clearTimeout(resizeTimer); resizeTimer = setTimeout(render, 120);});
    render();

    const search = document.getElementById('paymentSearch');
    const statusFilter = document.getElementById('paymentStatusFilter');
    const rows = [...document.querySelectorAll('#paymentsTable tbody tr[data-name]')];
    const empty = document.getElementById('paymentFilterEmpty');
    function filterPayments() {
        const q = (search?.value || '').trim().toLowerCase();
        const s = statusFilter?.value || '';
        let visible = 0;
        rows.forEach(row => {
            const matchText = !q || row.dataset.name.includes(q) || row.dataset.prontuario.includes(q);
            const matchStatus = !s || row.dataset.status === s;
            const show = matchText && matchStatus;
            row.hidden = !show;
            if (show) visible++;
        });
        if (empty) empty.hidden = visible !== 0 || rows.length === 0;
    }
    search?.addEventListener('input', filterPayments);
    statusFilter?.addEventListener('change', filterPayments);
})();
