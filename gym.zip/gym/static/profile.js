(() => {
    document.querySelectorAll('.avatar-upload-form input[type="file"]').forEach((input) => {
        input.addEventListener('change', () => {
            if (!input.files || !input.files.length) return;
            const form = input.closest('form');
            const pencil = form?.querySelector('.avatar-pencil');
            if (pencil) pencil.classList.add('is-loading');
            if (form) form.submit();
        });
    });
})();
